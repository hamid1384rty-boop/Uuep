package com.example.brainchart

import android.annotation.SuppressLint
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private val handler = Handler(Looper.getMainLooper())
    private val pageUrl = "http://127.0.0.1:5000/"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // راه‌اندازی Python و سرور Flask داخل همین برنامه
        if (!Python.isStarted()) {
            Python.start(AndroidPlatform(this))
        }
        Python.getInstance().getModule("main").callAttr("start")

        webView = findViewById(R.id.webView)
        webView.settings.javaScriptEnabled = true
        // localStorage فعال است تا تنظیمات بهینه‌شده بعد از بستن برنامه هم بماند
        webView.settings.domStorageEnabled = true
        webView.webViewClient = object : WebViewClient() {
            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: WebResourceError
            ) {
                // اگر سرور هنوز بالا نیامده، چند بار دیگر تلاش کن
                if (request.isForMainFrame) {
                    handler.postDelayed({ view.loadUrl(pageUrl) }, 1000)
                }
            }
        }
        webView.loadUrl(pageUrl)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
