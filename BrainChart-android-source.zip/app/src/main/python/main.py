import threading

import bi2_app

_started = False


def start():
    """از MainActivity صدا زده می‌شود: سرور Flask را روی 127.0.0.1:5000 بالا می‌آورد."""
    global _started
    if _started:
        return
    _started = True
    bi2_app.start_server()
    threading.Thread(target=_preload_symbols, daemon=True).start()


def _preload_symbols():
    try:
        bi2_app.get_all_symbols()
    except Exception as e:
        print("preload symbols failed:", e)
