#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Alpha Ribbon Chart - نسخه سبک
فقط شامل: سرور UI روی 127.0.0.1 - دریافت دیتا از Cloudflare Worker (بدون تغییر آدرس) - نمودار - اندیکاتور Ribbon
پشتیبانی از تمام ارزهای USDT - دریافت لیست ارزها از Worker
"""

import json
import sys
import subprocess
import urllib.request
import urllib.error
import urllib.parse
import time

# ==================== نصب خودکار کتابخانه‌ها ====================
required_packages = ['flask', 'requests']
for pkg in required_packages:
    try:
        __import__(pkg)
    except ImportError:
        print(f"📦 {pkg} نصب نیست. در حال نصب...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", pkg, "-q"])

from flask import Flask, jsonify, request

app = Flask(__name__)

HOST = "127.0.0.1"
PORT = 5000
TIMEOUT = 15

# ==================== تنظیمات Cloudflare Worker ====================
# همه‌ی درخواست‌های دیتا اول به Worker فرستاده می‌شوند.
# فقط اگر Worker اصلاً جواب ندهد (قطع/تایم‌اوت/خطای سرور) یا خودش نتواند به هیچ صرافی وصل شود،
# برنامه مستقیم به صرافی‌ها وصل می‌شود.
CLOUDFLARE_WORKER_URL = "https://cold-mud-d19f.hamid1384rty.workers.dev"
CLOUDFLARE_COUNTRY = "DE"
WORKER_API_KEY = ""            # اگر در Worker متغیر API_KEY تعریف کردی، همان مقدار را اینجا بنویس
WORKER_TIMEOUT = 30            # ثانیه (Worker ممکن است چند صفحه را پشت سر هم بگیرد)
WORKER_MAX_PER_CALL = 5000     # Worker v2 تا 5000 کندل را در یک درخواست صفحه‌بندی می‌کند
WORKER_RETRY_AFTER = 60        # اگر Worker جواب نداد، تا چند ثانیه مستقیم وصل شو و بعد دوباره Worker را امتحان کن
ALLOW_DIRECT_FALLBACK = True   # False = هرگز مستقیم به صرافی وصل نشو

# ==================== اتصال مستقیم به صرافی‌ها (فقط پشتیبان) ====================
EXCHANGE_TF = {
    'Binance': {'1m':'1m','5m':'5m','15m':'15m','30m':'30m','1h':'1h','4h':'4h','1d':'1d','1w':'1w'},
    'Bybit':   {'1m':'1','5m':'5','15m':'15','30m':'30','1h':'60','4h':'240','1d':'D','1w':'W'},
    'OKX':     {'1m':'1m','5m':'5m','15m':'15m','30m':'30m','1h':'1H','4h':'4H','1d':'1Dutc','1w':'1Wutc'},
    'KuCoin':  {'1m':'1min','5m':'5min','15m':'15min','30m':'30min','1h':'1hour','4h':'4hour','1d':'1day','1w':'1week'},
}
TF_SECONDS = {'1m':60,'5m':300,'15m':900,'30m':1800,'1h':3600,'4h':14400,'1d':86400,'1w':604800}
DIRECT_ORDER = ['Binance', 'Bybit', 'OKX', 'KuCoin']

# لیست پیش‌فرض (فقط برای fallback اگر همه چیز ناموفق بود)
DEFAULT_SYMBOLS = ['BTCUSDT','ETHUSDT','BNBUSDT','XRPUSDT','ADAUSDT','SOLUSDT','DOTUSDT','DOGEUSDT','AVAXUSDT','MATICUSDT']

# ==================== لیست ۲۰۰ ارز آماده داخل کد (بدون نیاز به درخواست از سرور/Worker در بارگذاری اولیه) ====================
PRELOADED_SYMBOLS_200 = sorted(set([
    'BTCUSDT','ETHUSDT','BNBUSDT','XRPUSDT','ADAUSDT','SOLUSDT','DOTUSDT','DOGEUSDT','AVAXUSDT','MATICUSDT',
    'LTCUSDT','LINKUSDT','TRXUSDT','ATOMUSDT','ETCUSDT','XLMUSDT','NEARUSDT','ALGOUSDT','VETUSDT','FILUSDT',
    'ICPUSDT','APTUSDT','ARBUSDT','OPUSDT','SUIUSDT','SEIUSDT','INJUSDT','TIAUSDT','RUNEUSDT','FTMUSDT',
    'SANDUSDT','MANAUSDT','AXSUSDT','GALAUSDT','CHZUSDT','ENJUSDT','THETAUSDT','EOSUSDT','XTZUSDT','AAVEUSDT',
    'UNIUSDT','SUSHIUSDT','CRVUSDT','COMPUSDT','MKRUSDT','SNXUSDT','YFIUSDT','1INCHUSDT','ZRXUSDT','BALUSDT',
    'GRTUSDT','ENSUSDT','LDOUSDT','RPLUSDT','FXSUSDT','CVXUSDT','DYDXUSDT','GMXUSDT','BLURUSDT','PENDLEUSDT',
    'SHIBUSDT','PEPEUSDT','FLOKIUSDT','BONKUSDT','WIFUSDT','MEWUSDT','BOMEUSDT','ORDIUSDT','1000SATSUSDT','MEMEUSDT',
    'ARUSDT','RENDERUSDT','FETUSDT','AGIXUSDT','OCEANUSDT','RLCUSDT','WLDUSDT','TAOUSDT','AKTUSDT','NMRUSDT',
    'IMXUSDT','GMTUSDT','APEUSDT','LRCUSDT','CELOUSDT','KAVAUSDT','ROSEUSDT','ONEUSDT','ZILUSDT','IOSTUSDT',
    'HBARUSDT','QNTUSDT','EGLDUSDT','FLOWUSDT','KSMUSDT','MINAUSDT','ASTRUSDT','GLMRUSDT','MOVRUSDT','ACAUSDT',
    'CFXUSDT','KLAYUSDT','WAVESUSDT','ZENUSDT','SCUSDT','DGBUSDT','RVNUSDT','ANKRUSDT','STORJUSDT','SKLUSDT',
    'CTSIUSDT','OGNUSDT','BANDUSDT','API3USDT','UMAUSDT','ALPHAUSDT','SFPUSDT','C98USDT','HOOKUSDT','HIGHUSDT',
    'ACHUSDT','SSVUSDT','IDUSDT','JOEUSDT','MAGICUSDT','STGUSDT','RDNTUSDT','WOOUSDT','PERPUSDT','BICOUSDT',
    'TRUUSDT','POLYXUSDT','MASKUSDT','LPTUSDT','POWRUSDT','DUSKUSDT','JASMYUSDT','IOTAUSDT','ONTUSDT','QTUMUSDT',
    'ZECUSDT','DASHUSDT','XMRUSDT','BATUSDT','NEOUSDT','WAXPUSDT','CHRUSDT','COTIUSDT','STMXUSDT','ARDRUSDT',
    'ARPAUSDT','CELRUSDT','DENTUSDT','HOTUSDT','KEYUSDT','MTLUSDT','NKNUSDT','OMGUSDT','ORNUSDT','REEFUSDT',
    'RSRUSDT','SNTUSDT','STPTUSDT','TLMUSDT','TOMOUSDT','TRBUSDT','VITEUSDT','WANUSDT','XVGUSDT','YFIIUSDT',
    'BEAMXUSDT','PYTHUSDT','JUPUSDT','STRKUSDT','MANTAUSDT','ALTUSDT','DYMUSDT','PIXELUSDT','PORTALUSDT','AXLUSDT',
    'AEVOUSDT','ETHFIUSDT','ENAUSDT','WUSDT','SAGAUSDT','OMNIUSDT','REZUSDT','NOTUSDT','IOUSDT','ZKUSDT',
    'LISTAUSDT','BBUSDT','TNSRUSDT','AIUSDT','XAIUSDT','METISUSDT','TURBOUSDT','BSVUSDT','ILVUSDT','SUPERUSDT',
]))


# کش لیست ارزها
_symbols_cache = {"data": None, "timestamp": 0, "ttl": 3600}  # کش 1 ساعته

TIMEFRAMES = ['1m', '5m', '15m', '30m', '1h', '4h', '1d']

# ==================== لایه‌ی دریافت دیتا ====================
MAX_PER_REQUEST = 1000        # سقف هر درخواست مستقیم به صرافی
MAX_TOTAL_CANDLES = 10000     # برای بک‌تست دوره‌های طولانی

_worker_state = {"down_until": 0.0, "last_error": None, "last_ok": 0.0}
_last_source = {"source": "-", "time": 0}


class WorkerUnreachable(Exception):
    """Worker اصلاً جواب درست نداد (قطع، تایم‌اوت، خطای سرور، پاسخ غیر JSON، کلید اشتباه)"""


def http_get_json(url, timeout=TIMEOUT, headers=None):
    """خروجی: (status, json یا None). خطای شبکه/تایم‌اوت را raise می‌کند."""
    h = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36', 'Accept': 'application/json'}
    if headers:
        h.update(headers)
    req = urllib.request.Request(url, headers=h)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read().decode('utf-8', 'replace')
            status = resp.status
    except urllib.error.HTTPError as e:
        body = e.read().decode('utf-8', 'replace') if e.fp else ''
        status = e.code
    try:
        return status, json.loads(body)
    except ValueError:
        return status, None


def fetch_url(url, timeout=TIMEOUT):
    """سازگاری با کدهای قبلی: فقط JSON یا None"""
    try:
        status, data = http_get_json(url, timeout)
        return data if 200 <= status < 300 else None
    except Exception as e:
        print(f"⚠️ خطا در دریافت {url}: {e}")
        return None


def worker_available():
    return time.time() >= _worker_state["down_until"]


def _mark_worker_down(reason):
    _worker_state["down_until"] = time.time() + WORKER_RETRY_AFTER
    if _worker_state["last_error"] != reason:
        print(f"☁️❌ Worker جواب نداد ({reason}) → تا {WORKER_RETRY_AFTER} ثانیه اتصال مستقیم به صرافی‌ها")
    _worker_state["last_error"] = reason


def worker_get(path, params):
    """درخواست به Worker. اگر Worker اصلاً جواب درست ندهد WorkerUnreachable می‌دهد."""
    if not worker_available():
        raise WorkerUnreachable(_worker_state["last_error"] or "cooldown")
    params = dict(params)
    params.setdefault('country', CLOUDFLARE_COUNTRY)
    headers = {'X-API-Key': WORKER_API_KEY} if WORKER_API_KEY else None
    url = f"{CLOUDFLARE_WORKER_URL}{path}?{urllib.parse.urlencode(params)}"
    try:
        status, data = http_get_json(url, WORKER_TIMEOUT, headers)
    except Exception as e:
        _mark_worker_down(f"شبکه: {e}")
        raise WorkerUnreachable(str(e))
    if status == 401:
        _mark_worker_down("کلید API اشتباه است (WORKER_API_KEY)")
        raise WorkerUnreachable("unauthorized")
    if not isinstance(data, dict) or 'success' not in data:
        _mark_worker_down(f"پاسخ نامعتبر (HTTP {status})")
        raise WorkerUnreachable(f"invalid response {status}")
    if status >= 500 and data.get('code') not in ('UPSTREAM_FAILED',):
        _mark_worker_down(f"خطای سرور Worker (HTTP {status})")
        raise WorkerUnreachable(f"server error {status}")
    if _worker_state["last_error"]:
        print("☁️✅ Worker دوباره در دسترس است")
    _worker_state["last_error"] = None
    _worker_state["last_ok"] = time.time()
    return status, data


def _clean_rows(rows, end_sec=None):
    out = {}
    for c in rows or []:
        try:
            k = {'time': int(c['time']), 'open': float(c['open']), 'high': float(c['high']),
                 'low': float(c['low']), 'close': float(c['close']), 'volume': float(c.get('volume') or 0)}
        except (KeyError, TypeError, ValueError):
            continue
        if k['time'] <= 0 or min(k['open'], k['high'], k['low'], k['close']) <= 0:
            continue
        if any(v != v for v in k.values()):  # NaN
            continue
        if end_sec is not None and k['time'] > end_sec:
            continue
        out[k['time']] = k
    return [out[t] for t in sorted(out)]


# ---------- اتصال مستقیم (پشتیبان) ----------
def _direct_url(ex, symbol, timeframe, limit, end_ms=None, host_idx=0):
    tf = EXCHANGE_TF[ex].get(timeframe)
    if not tf:
        return None
    if ex == 'Binance':
        host = ['https://api.binance.com', 'https://data-api.binance.vision'][host_idx]
        return f"{host}/api/v3/klines?symbol={symbol}&interval={tf}&limit={min(limit, 1000)}" + (f"&endTime={end_ms}" if end_ms else "")
    if ex == 'Bybit':
        return f"https://api.bybit.com/v5/market/kline?category=spot&symbol={symbol}&interval={tf}&limit={min(limit, 1000)}" + (f"&end={end_ms}" if end_ms else "")
    if ex == 'OKX':
        inst = symbol[:-4] + '-USDT'
        return f"https://www.okx.com/api/v5/market/history-candles?instId={inst}&bar={tf}&limit={min(limit, 100)}" + (f"&after={end_ms + 1}" if end_ms else "")
    if ex == 'KuCoin':
        end_at = int((end_ms or time.time() * 1000) // 1000)
        start_at = end_at - min(limit, 1500) * TF_SECONDS[timeframe]
        return f"https://api.kucoin.com/api/v1/market/candles?symbol={symbol[:-4]}-USDT&type={tf}&startAt={start_at}&endAt={end_at}"
    return None


def parse_klines(exchange_name, data):
    candles = []
    try:
        if exchange_name == 'Binance' and isinstance(data, list):
            for d in data:
                candles.append({'time': int(d[0]) // 1000, 'open': d[1], 'high': d[2], 'low': d[3], 'close': d[4], 'volume': d[5]})
        elif exchange_name == 'Bybit' and isinstance(data, dict) and data.get('retCode') == 0:
            for d in data.get('result', {}).get('list', []):
                candles.append({'time': int(d[0]) // 1000, 'open': d[1], 'high': d[2], 'low': d[3], 'close': d[4], 'volume': d[5]})
        elif exchange_name == 'OKX' and isinstance(data, dict) and data.get('code') == '0':
            for d in data.get('data', []):
                candles.append({'time': int(d[0]) // 1000, 'open': d[1], 'high': d[2], 'low': d[3], 'close': d[4], 'volume': d[5]})
        elif exchange_name == 'KuCoin' and isinstance(data, dict) and data.get('code') == '200000':
            # KuCoin: [time(ثانیه), open, close, high, low, volume, turnover]
            for d in data.get('data', []):
                candles.append({'time': int(d[0]), 'open': d[1], 'close': d[2], 'high': d[3], 'low': d[4], 'volume': d[5]})
    except (IndexError, TypeError, ValueError):
        return []
    return _clean_rows(candles)


def direct_chunk(symbol, timeframe, limit, end_ms=None, order=None):
    """یک تکه کندل مستقیم از صرافی‌ها (بدون Worker). خروجی: (rows, exchange)"""
    end_sec = end_ms // 1000 if end_ms else None
    for ex in (order or DIRECT_ORDER):
        for host_idx in ([0, 1] if ex == 'Binance' else [0]):
            url = _direct_url(ex, symbol, timeframe, limit, end_ms, host_idx)
            if not url:
                break
            try:
                status, data = http_get_json(url, TIMEOUT)
            except Exception:
                continue
            if status in (403, 451) or status >= 500:
                continue                      # بلاک/خطا → میزبان یا صرافی بعدی
            rows = _clean_rows(parse_klines(ex, data), end_sec)
            if rows:
                return rows, ex
            break                             # جواب داد ولی دیتا نداشت → صرافی بعدی
    return [], None


def fetch_chunk(symbol, timeframe, limit, end_ms=None):
    """یک تکه کندل. ترتیب: ۱) مستقیم از بایننس  ۲) Worker (با ترجیح بایننس)  ۳) بقیه‌ی صرافی‌ها مستقیم.
    خروجی: (rows, exchange, source, error_code)"""
    end_sec = end_ms // 1000 if end_ms else None
    lim = min(limit, MAX_PER_REQUEST)
    # ۱) بایننس مستقیم
    rows, ex = direct_chunk(symbol, timeframe, lim, end_ms, order=['Binance'])
    if rows:
        return rows, ex, 'direct', None
    # ۲) Worker، با درخواست صرافی بایننس
    try:
        params = {'symbol': symbol, 'timeframe': timeframe, 'limit': min(limit, WORKER_MAX_PER_CALL), 'exchange': 'binance'}
        if end_ms:
            params['endTime'] = int(end_ms)
        _, data = worker_get('/candles', params)
        if data.get('success'):
            return _clean_rows(data.get('data'), end_sec), data.get('exchange', 'Worker'), 'worker', None
        code = data.get('code') or 'UNKNOWN'
        if code != 'UPSTREAM_FAILED':
            return [], None, 'worker', code        # مثلا ارز پیدا نشد: صرافی‌های دیگر هم فایده ندارند
        print("☁️⚠️ Worker جواب داد ولی به هیچ صرافی‌ای دسترسی نداشت → تلاش مستقیم")
    except WorkerUnreachable:
        pass
    # ۳) بقیه‌ی صرافی‌ها مستقیم
    if not ALLOW_DIRECT_FALLBACK:
        return [], None, 'none', 'WORKER_UNREACHABLE'
    rows, ex = direct_chunk(symbol, timeframe, lim, end_ms, order=[e for e in DIRECT_ORDER if e != 'Binance'])
    return rows, ex, 'direct', (None if rows else 'ALL_FAILED')


def get_candles(symbol="BTCUSDT", timeframe="5m", limit=300):
    symbol = (symbol or 'BTCUSDT').upper().replace('-', '').replace('/', '')
    try:
        limit = max(10, min(int(limit), MAX_TOTAL_CANDLES))
    except (TypeError, ValueError):
        limit = 300
    candles, exchanges, sources = [], [], []
    end_ms, last_err, tries = None, None, 0
    # صفحه‌بندی به عقب تا رسیدن به تعداد درخواستی
    while len(candles) < limit and tries < 60:
        tries += 1
        rows, ex, src, err = fetch_chunk(symbol, timeframe, limit - len(candles), end_ms)
        if not rows:
            last_err = err
            break
        known = {c['time'] for c in candles}
        rows = [c for c in rows if c['time'] not in known]
        if not rows:
            break
        candles = sorted(rows + candles, key=lambda c: c['time'])
        if ex and ex not in exchanges:
            exchanges.append(ex)
        if src not in sources:
            sources.append(src)
        end_ms = candles[0]['time'] * 1000 - 1
    if not candles:
        msg = {'SYMBOL_NOT_FOUND': 'این ارز/تایم‌فریم در هیچ صرافی پیدا نشد',
               'WORKER_UNREACHABLE': 'Worker جواب نداد و اتصال مستقیم خاموش است'}.get(last_err, 'داده‌ای از هیچ منبعی دریافت نشد')
        return {'success': False, 'error': msg, 'code': last_err, 'exchange': 'NONE', 'data': []}
    candles = candles[-limit:]
    source = '+'.join(sources)
    _last_source.update(source=source, time=time.time())
    out = {'success': True, 'exchange': ('☁️ ' if 'worker' in sources else '🔌 ') + '/'.join(exchanges),
           'symbol': symbol, 'timeframe': timeframe, 'data': candles, 'count': len(candles), 'source': source}
    notes = []
    if 'direct' in sources:
        notes.append('Worker در دسترس نبود، اتصال مستقیم استفاده شد')
    if len(candles) < limit:
        notes.append(f'فقط {len(candles)} کندل از {limit} در دسترس بود')
    if notes:
        out['note'] = ' | '.join(notes)
    return out


# ==================== دریافت لیست ارزها ====================
def _normalize_symbols(symbols):
    out = set()
    for s in symbols or []:
        if isinstance(s, dict):
            s = s.get('symbol') or s.get('instId') or ''
        if not isinstance(s, str):
            continue
        s = s.upper().strip().replace('-', '').replace('/', '').replace('_', '')
        if s.endswith('USDT') and 4 < len(s) <= 24:
            out.add(s)
    return sorted(out)


def fetch_symbols_from_worker():
    """لیست ارزها از Worker. None یعنی Worker جواب نداد."""
    try:
        _, data = worker_get('/symbols', {})
    except WorkerUnreachable:
        return None
    if data.get('success'):
        syms = _normalize_symbols(data.get('symbols'))
        print(f"✅ {len(syms)} ارز از Worker دریافت شد (منبع: {data.get('source', '-')})")
        return syms
    return []


def fetch_binance_symbols():
    for host in ('https://api.binance.com', 'https://data-api.binance.vision'):
        data = fetch_url(f"{host}/api/v3/ticker/price", timeout=20)
        if isinstance(data, list):
            return _normalize_symbols([d.get('symbol') for d in data])
    return []

def fetch_bybit_symbols():
    data = fetch_url("https://api.bybit.com/v5/market/instruments-info?category=spot&limit=1000", timeout=20)
    if not isinstance(data, dict):
        return []
    return _normalize_symbols([s['symbol'] for s in data.get('result', {}).get('list', []) if s.get('status') == 'Trading'])

def fetch_okx_symbols():
    data = fetch_url("https://www.okx.com/api/v5/public/instruments?instType=SPOT", timeout=20)
    if not isinstance(data, dict):
        return []
    return _normalize_symbols([s['instId'] for s in data.get('data', []) if s.get('state') == 'live'])

def fetch_kucoin_symbols():
    data = fetch_url("https://api.kucoin.com/api/v2/symbols", timeout=20)
    if not isinstance(data, dict):
        return []
    return _normalize_symbols([s['symbol'] for s in data.get('data', []) if s.get('enableTrading')])


def get_all_symbols():
    """لیست ارزها: اول Worker؛ اتصال مستقیم فقط اگر Worker جواب نداد یا به صرافی‌ها دسترسی نداشت"""
    now = time.time()
    if _symbols_cache["data"] and (now - _symbols_cache["timestamp"]) < _symbols_cache["ttl"]:
        return _symbols_cache["data"]
    print("🔄 در حال دریافت لیست کامل ارزها...")
    result = fetch_symbols_from_worker() or []
    if len(result) < 50 and ALLOW_DIRECT_FALLBACK:
        print("🔌 Worker لیست را نداد → اتصال مستقیم به صرافی‌ها")
        for fn in (fetch_binance_symbols, fetch_bybit_symbols, fetch_okx_symbols, fetch_kucoin_symbols):
            syms = fn()
            if len(syms) >= 50:
                result = syms
                break
    if len(result) < 10:
        result = PRELOADED_SYMBOLS_200 or DEFAULT_SYMBOLS
    _symbols_cache["data"] = result
    _symbols_cache["timestamp"] = now
    print(f"📊 مجموع: {len(result)} ارز")
    return result

# ==================== روت‌ها ====================
@app.route("/")
def index():
    # لیست ۲۰۰ ارز آماده مستقیماً داخل صفحه تزریق می‌شود؛ نیازی به فراخوانی شبکه در بارگذاری اولیه نیست
    return HTML_PAGE.replace("__SYMBOLS_200_JSON__", json.dumps(PRELOADED_SYMBOLS_200))

@app.route("/api/candles")
def api_candles():
    symbol = request.args.get('symbol', 'BTCUSDT')
    timeframe = request.args.get('timeframe', '5m')
    limit = int(request.args.get('limit', 300))
    result = get_candles(symbol, timeframe, limit)
    return jsonify(result)

@app.route("/api/source")
def api_source():
    """وضعیت منبع دیتا: Worker یا اتصال مستقیم"""
    return jsonify({'worker_url': CLOUDFLARE_WORKER_URL, 'worker_available': worker_available(),
                    'worker_last_error': _worker_state['last_error'], 'last_source': _last_source['source'],
                    'direct_fallback': ALLOW_DIRECT_FALLBACK})

@app.route("/api/symbols")
def api_symbols():
    """این روت فقط برای بروزرسانی دستی (دکمه 🔄) استفاده می‌شود؛ بارگذاری اولیه از لیست آماده داخل کد استفاده می‌کند"""
    refresh = request.args.get('refresh')
    if not refresh:
        return jsonify({'success': True, 'count': len(PRELOADED_SYMBOLS_200), 'symbols': PRELOADED_SYMBOLS_200})
    try:
        symbols = get_all_symbols()
        return jsonify({
            'success': True,
            'count': len(symbols),
            'symbols': symbols
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'symbols': PRELOADED_SYMBOLS_200
        })

# ==================== HTML/JS ====================
HTML_PAGE = """
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Alpha Ribbon Chart</title>
<style>
*{box-sizing:border-box;margin:0;padding:0;font-family:Tahoma,Arial,sans-serif;}
body{background:#050810;color:#cfe3ee;}
.topbar{display:flex;flex-wrap:wrap;gap:6px;align-items:center;padding:10px;background:#0b1220;border-bottom:1px solid #1a2a3a;}
select,button,input[type=text]{background:#101a2a;color:#cfe3ee;border:1px solid #1a2a3a;border-radius:6px;padding:6px 10px;font-size:12px;cursor:pointer;}
input[type=text]{cursor:text;}
button.active,.tf-btn.active{background:#00c853;color:#000;border-color:#00c853;font-weight:bold;}
#indicatorBar{position:relative;display:flex;justify-content:center;padding:12px;background:#0b1220;border-bottom:2px solid #ff9800;}
#btnIndicatorMenu{background:#ff9800;color:#000;border:2px solid #ff9800;font-weight:bold;font-size:15px;padding:12px 30px;border-radius:10px;cursor:pointer;box-shadow:0 0 15px rgba(255,152,0,0.6);transition:all 0.2s;}
#btnIndicatorMenu.active{background:#1565c0;border-color:#1565c0;color:#fff;box-shadow:0 0 15px rgba(21,101,192,0.7);}
#indicatorMenu{display:none;flex-direction:column;gap:8px;position:absolute;top:100%;left:50%;transform:translateX(-50%);background:#0b1220;border:1px solid #1a2a3a;border-radius:12px;padding:12px;z-index:600;min-width:260px;box-shadow:0 12px 32px rgba(0,0,0,0.65);margin-top:8px;}
#indicatorMenu.open{display:flex;}
#lzGroup{border:1px solid #1a2a3a;border-radius:10px;padding:8px;display:flex;flex-direction:column;gap:6px;background:#0e1626;}
#lzGroup .lzTitle{color:#ff9800;font-weight:bold;font-size:12px;text-align:center;border-bottom:1px solid #ff9800;padding-bottom:4px;}
#lzGroup .lzRow{display:flex;align-items:center;gap:6px;}
#lzGroup .lzName{width:34px;font-weight:bold;color:#cfe3ee;font-size:13px;text-align:center;}
#indicatorMenu #lzGroup .lzRun{flex:1;width:auto;}
#indicatorMenu #lzGroup .lzW{flex:1;width:auto;}
#indicatorMenu #lzGroup .lzAll{background:#1b5e20;color:#fff;}
#indicatorMenu button{width:100%;margin:0 !important;text-align:center;}
#btnIndicator{background:#ff9800;color:#000;border:2px solid #ff9800;font-weight:bold;font-size:15px;padding:12px 30px;border-radius:10px;cursor:pointer;box-shadow:0 0 15px rgba(255,152,0,0.6);transition:all 0.2s;}
#btnIndicator.active{background:#ff1744;color:#fff;border-color:#ff1744;box-shadow:0 0 15px rgba(255,23,68,0.8);}
#chartDiv{width:100%;height:70vh;}
.legend{display:flex;gap:14px;padding:6px 10px;font-size:11px;color:#889;flex-wrap:wrap;}
.dot{display:inline-block;width:9px;height:9px;border-radius:50%;margin-left:4px;}
#statusBar{padding:6px 10px;font-size:10px;color:#667788;border-top:1px solid #1a2a3a;}
#btnSettings{background:#2196f3;color:#fff;border:2px solid #2196f3;font-weight:bold;font-size:14px;padding:12px 22px;border-radius:10px;cursor:pointer;box-shadow:0 0 10px rgba(33,150,243,0.5);margin-right:10px;}
#btnSettings.active{background:#1565c0;border-color:#1565c0;}
#btnMultiLayer{background:#00e5ff;color:#000;border:2px solid #00e5ff;font-weight:bold;font-size:15px;padding:12px 30px;border-radius:10px;cursor:pointer;box-shadow:0 0 15px rgba(0,229,255,0.6);transition:all 0.2s;margin-right:10px;}
#btnMultiLayer.active{background:#aa00ff;color:#fff;border-color:#aa00ff;box-shadow:0 0 15px rgba(170,0,255,0.8);}
#btnZones{background:#8bc34a;color:#000;border:2px solid #8bc34a;font-weight:bold;font-size:15px;padding:12px 30px;border-radius:10px;cursor:pointer;box-shadow:0 0 15px rgba(139,195,74,0.6);transition:all 0.2s;margin-right:10px;}
#btnZones.active{background:#33691e;color:#fff;border-color:#33691e;box-shadow:0 0 15px rgba(51,105,30,0.8);}
#btnSignalFilter{background:#ffa726;color:#000;border:2px solid #ffa726;font-weight:bold;font-size:15px;padding:12px 30px;border-radius:10px;cursor:pointer;box-shadow:0 0 15px rgba(255,167,38,0.6);transition:all 0.2s;margin-right:10px;}
#btnSignalFilter.active{background:#e65100;color:#fff;border-color:#e65100;box-shadow:0 0 15px rgba(230,81,0,0.8);}
#btnStructure{background:#2962ff;color:#fff;border:2px solid #2962ff;font-weight:bold;font-size:15px;padding:12px 30px;border-radius:10px;cursor:pointer;box-shadow:0 0 15px rgba(41,98,255,0.6);transition:all 0.2s;margin-right:10px;}
#btnStructure.active{background:#e91e63;color:#fff;border-color:#e91e63;box-shadow:0 0 15px rgba(233,30,99,0.8);}
#btnFanProjection{background:#f5f5f5;color:#000;border:2px solid #f5f5f5;font-weight:bold;font-size:15px;padding:12px 30px;border-radius:10px;cursor:pointer;box-shadow:0 0 15px rgba(245,245,245,0.5);transition:all 0.2s;margin-right:10px;}
#btnFanProjection.active{background:#616161;color:#fff;border-color:#616161;box-shadow:0 0 15px rgba(97,97,97,0.8);}
html,body{overflow-x:hidden;}
#btnAiPath{background:#ffd700;color:#000;border:2px solid #ffd700;font-weight:bold;font-size:15px;padding:12px 30px;border-radius:10px;cursor:pointer;box-shadow:0 0 15px rgba(255,215,0,0.6);transition:all 0.2s;margin-right:10px;}
#btnAiPath.active{background:#7b1fa2;color:#fff;border-color:#7b1fa2;box-shadow:0 0 15px rgba(123,31,162,0.8);}
#btnPf{background:#00e5a0;color:#000;border:2px solid #00e5a0;font-weight:bold;font-size:15px;padding:12px 30px;border-radius:10px;cursor:pointer;box-shadow:0 0 15px rgba(0,229,160,0.6);transition:all 0.2s;margin-right:10px;}
#btnPf.active{background:#ff6d00;color:#fff;border-color:#ff6d00;box-shadow:0 0 15px rgba(255,109,0,0.8);}
#pfCard{position:absolute;top:8px;right:72px;max-width:235px;background:rgba(11,18,32,0.92);border:1px solid #00e5a0;border-radius:10px;padding:8px 12px;font-size:10.5px;color:#cfe3ee;z-index:500;box-shadow:0 6px 20px rgba(0,0,0,0.5);display:none;direction:rtl;}
#pfCard.show{display:block;}
#pfCard .pfTitle{color:#00e5a0;font-weight:bold;font-size:11px;border-bottom:1px solid #1a2a3a;padding-bottom:4px;margin-bottom:5px;cursor:pointer;}
#pfCard.mini .pfBody{display:none;}
#pfCard.mini .pfTitle{border-bottom:none;margin-bottom:0;padding-bottom:0;}
#pfCard .pfRow{display:flex;justify-content:space-between;gap:10px;margin-bottom:3px;}
#pfCard .pfWin{text-align:center;margin-bottom:6px;padding:6px 4px;border-radius:8px;background:rgba(0,229,160,0.08);border:1px solid rgba(0,229,160,0.35);}
#pfCard .pfWinBig{font-size:26px;font-weight:bold;line-height:1.1;}
#pfCard .pfWinSub{font-size:10px;color:#9fb6c4;margin-top:2px;}
#pfCard .pfFilt{margin-top:5px;padding-top:4px;border-top:1px dashed #1a2a3a;font-size:9.5px;color:#7f93a1;}
#pfCard .pfOpen{margin-bottom:5px;padding-bottom:4px;border-bottom:1px dashed #1a2a3a;}
#pfCard .pfBuy{color:#00e676;font-weight:bold;}
#pfCard .pfSell{color:#ff5252;font-weight:bold;}
#aiTradeCard{position:absolute;bottom:14px;right:14px;max-height:85%;overflow-y:auto;background:rgba(11,18,32,0.92);border:1px solid #ffd700;border-radius:10px;padding:10px 14px;font-size:11px;color:#cfe3ee;z-index:500;min-width:170px;box-shadow:0 6px 20px rgba(0,0,0,0.5);display:none;}
#aiTradeCard.show{display:block;}
#aiTradeCard .aiRow{display:flex;justify-content:space-between;gap:10px;margin-bottom:3px;}
#aiTradeCard .aiTitle{color:#ffd700;font-weight:bold;font-size:12px;margin-bottom:6px;border-bottom:1px solid #1a2a3a;padding-bottom:4px;}
#aiTradeCard .aiBuy{color:#00c853;font-weight:bold;}
#aiTradeCard .aiSell{color:#ff1744;font-weight:bold;}
#aiTradeCard .aiTp{color:#4caf50;}
#aiTradeCard .aiSl{color:#ff5252;}
#mbCard{position:absolute;bottom:14px;left:14px;max-width:230px;background:rgba(11,18,32,0.92);border:1px solid #00e676;border-radius:10px;padding:8px 12px;font-size:10.5px;color:#cfe3ee;z-index:500;box-shadow:0 6px 20px rgba(0,0,0,0.5);display:none;direction:rtl;}
#mbCard.show{display:block;}
#mbCard .aiRow{display:flex;justify-content:space-between;gap:10px;margin-bottom:3px;}
#mbCard .mbTitle{color:#00e676;font-weight:bold;font-size:11px;border-bottom:1px solid #1a2a3a;padding-bottom:4px;margin-bottom:5px;cursor:pointer;}
#mbCard.mini .mbBody{display:none;}
#mbCard.mini .mbTitle{border-bottom:none;margin-bottom:0;padding-bottom:0;}
#mbCard .mbPos{color:#00e676;font-weight:bold;}
#mbCard .mbNeg{color:#ff5252;font-weight:bold;}
#mbCard .mbLink{margin-top:6px;text-align:center;color:#00e5ff;cursor:pointer;font-weight:bold;padding:4px 0;border-top:1px solid #1a2a3a;}
#mbTradesModal{display:none;position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:3100;align-items:flex-end;justify-content:center;}
#mbTradesModal.open{display:flex;}
#mbTradesBox{background:#0b1220;border:1px solid #00e676;border-radius:14px 14px 0 0;width:100%;max-width:720px;max-height:75vh;display:flex;flex-direction:column;color:#cfe3ee;direction:rtl;box-shadow:0 -10px 30px rgba(0,0,0,0.6);}
#mbTradesBox .mbtHead{display:flex;justify-content:space-between;align-items:center;padding:10px 14px;font-size:13px;font-weight:bold;color:#00e676;border-bottom:1px solid #1a2a3a;}
#mbTradesBox .mbtClose{cursor:pointer;background:#1a2a3a;border-radius:6px;padding:2px 10px;color:#cfe3ee;}
#mbTradesBody{overflow:auto;padding:0 6px 10px 6px;font-size:11px;}
#mbTradesBody table{width:100%;border-collapse:collapse;}
#mbTradesBody th{position:sticky;top:0;background:#0b1220;color:#8fa6b8;font-weight:normal;padding:6px 4px;border-bottom:1px solid #1a2a3a;}
#mbTradesBody td{text-align:center;padding:6px 4px;border-bottom:1px solid #121e2e;white-space:nowrap;}
#mbTradesBody tr{cursor:pointer;}
#mbTradesBody .mbPos{color:#00e676;font-weight:bold;}
#mbTradesBody .mbNeg{color:#ff5252;font-weight:bold;}
#btnBacktest{background:#26c6da;color:#000;border:2px solid #26c6da;font-weight:bold;font-size:15px;padding:12px 30px;border-radius:10px;cursor:pointer;box-shadow:0 0 15px rgba(38,198,218,0.6);}
#btModal{display:none;position:fixed;inset:0;background:rgba(0,0,0,0.65);z-index:3000;align-items:flex-start;justify-content:center;overflow-y:auto;padding:30px 10px;}
#btModal.open{display:flex;}
#btBox{background:#0b1220;border:1px solid #26c6da;border-radius:14px;width:100%;max-width:980px;padding:16px;color:#cfe3ee;box-shadow:0 20px 50px rgba(0,0,0,0.7);direction:rtl;}
#btBox .btHead{display:flex;justify-content:space-between;align-items:center;font-size:16px;font-weight:bold;color:#26c6da;border-bottom:1px solid #1a2a3a;padding-bottom:10px;margin-bottom:12px;}
#btBox .btClose{cursor:pointer;background:#1a2a3a;border-radius:6px;padding:2px 10px;color:#cfe3ee;}
#btBox .btForm{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:10px;margin-bottom:12px;}
#btBox .btForm label{display:flex;flex-direction:column;gap:4px;font-size:11px;color:#8899aa;}
#btBox .btForm label.chk{flex-direction:row;align-items:center;gap:6px;color:#cfe3ee;}
#btBox .btForm select,#btBox .btForm input{width:100%;background:#101a2a;color:#cfe3ee;border:1px solid #1a2a3a;border-radius:6px;padding:7px 8px;font-size:12px;}
#btBox .btForm input[type=checkbox]{width:16px;height:16px;}
#btRun{background:#00c853;color:#000;font-weight:bold;border:none;padding:11px 28px;border-radius:8px;cursor:pointer;font-size:14px;}
#btRun:disabled{opacity:0.5;cursor:wait;}
#btStatus{font-size:11px;color:#ff9800;margin:10px 0;min-height:14px;}
#btResult .btGrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:8px;margin-bottom:12px;}
#btResult .btCard{background:#0f1826;border:1px solid #1a2a3a;border-radius:8px;padding:8px 10px;}
#btResult .btCard .k{font-size:10px;color:#8899aa;margin-bottom:3px;}
#btResult .btCard .v{font-size:15px;font-weight:bold;}
#btResult .pos{color:#00c853;} #btResult .neg{color:#ff5252;}
#btResult .btVerdict{padding:10px;border-radius:8px;margin-bottom:12px;font-weight:bold;font-size:13px;background:#0f1826;border:1px solid #1a2a3a;}
#btResult .btNote{font-size:10.5px;color:#8899aa;margin-bottom:10px;line-height:1.7;}
#btResult canvas{width:100%;height:180px;background:#0f1826;border:1px solid #1a2a3a;border-radius:8px;margin-bottom:12px;}
#btResult table{width:100%;border-collapse:collapse;font-size:11px;}
#btResult th,#btResult td{padding:5px 6px;border-bottom:1px solid #1a2a3a;text-align:center;}
#btResult th{color:#26c6da;position:sticky;top:0;background:#0b1220;}
#btResult .btTableWrap{max-height:320px;overflow-y:auto;border:1px solid #1a2a3a;border-radius:8px;}
#settingsPanel{display:none;background:#0b1220;border-bottom:1px solid #1a2a3a;padding:14px;}
#settingsPanel.open{display:block;}
.settingsGrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:10px;}
.settingsGroup{background:#0f1826;border:1px solid #1a2a3a;border-radius:8px;padding:10px;}
.settingsGroup h4{font-size:11px;color:#ff9800;margin-bottom:8px;border-bottom:1px solid #1a2a3a;padding-bottom:4px;}
.settingsField{display:flex;justify-content:space-between;align-items:center;gap:6px;margin-bottom:6px;font-size:11px;}
.settingsField input[type=number]{width:60px;background:#101a2a;color:#cfe3ee;border:1px solid #1a2a3a;border-radius:4px;padding:3px 5px;font-size:11px;}
.settingsField input[type=checkbox]{width:16px;height:16px;cursor:pointer;}
.settingsField select{background:#101a2a;color:#cfe3ee;border:1px solid #1a2a3a;border-radius:4px;padding:3px;font-size:11px;}
#settingsPanel button{background:#00c853;color:#000;font-weight:bold;border:none;padding:10px 24px;border-radius:8px;cursor:pointer;}
#colorModeBar{display:flex;justify-content:center;align-items:center;gap:8px;padding:10px;background:#0b1220;border-bottom:1px solid #1a2a3a;flex-wrap:wrap;}
.colorModeLabel{color:#8899aa;font-size:12px;}
.colorModeBtn{background:#101a2a;color:#cfe3ee;border:2px solid #1a2a3a;font-weight:bold;font-size:12px;padding:8px 16px;border-radius:8px;cursor:pointer;}
.colorModeBtn.active{background:#ff9800;color:#000;border-color:#ff9800;}
#chartWrap{position:relative;}
#dashboard{position:absolute;top:8px;left:8px;z-index:5;background:rgba(11,18,32,0.80);border:1px solid #1a2a3a;border-radius:8px;padding:8px 10px;font-size:10.5px;width:165px;display:none;pointer-events:none;max-height:80%;overflow-y:auto;transition:opacity 0.15s;}
#dashboard.show{display:block;}
#dashboard.pos-right{left:auto;right:8px;}
#dashboard.collapsed{opacity:0.55;}
#dashboard.collapsed #dashboardBody{display:none;}
#dashboard .dRow{display:flex;justify-content:space-between;gap:8px;padding:2px 0;border-bottom:1px solid rgba(26,42,58,0.5);}
#dashboard .dTitle{color:#ff9800;font-weight:bold;font-size:11px;margin-bottom:4px;text-align:center;border-bottom:1px solid #ff9800;padding-bottom:4px;display:flex;justify-content:space-between;align-items:center;pointer-events:auto;}
#dashboard .dTitle span.dCollapseBtn{cursor:pointer;background:#1a2a3a;color:#cfe3ee;border-radius:4px;padding:1px 7px;font-size:12px;pointer-events:auto;}
#dashboard .mtfRow{display:flex;justify-content:space-between;padding:1px 0;}
#dashboard .mtfDot{width:8px;height:8px;border-radius:50%;display:inline-block;margin-left:5px;}
.symbolSearch{position:relative;display:inline-block;}
.symbolSearch input{width:140px;}
.symbolDropdown{position:absolute;top:100%;left:0;right:0;max-height:300px;overflow-y:auto;background:#101a2a;border:1px solid #1a2a3a;border-radius:6px;z-index:1000;display:none;margin-top:2px;}
.symbolDropdown.show{display:block;}
.symbolDropdown .symItem{padding:6px 10px;font-size:12px;cursor:pointer;border-bottom:1px solid #1a2a3a;}
.symbolDropdown .symItem:hover{background:#1a2a3a;color:#00c853;}
.symbolDropdown .symItem.active{background:#00c853;color:#000;font-weight:bold;}
#symbolInfo{padding:4px 10px;font-size:10px;color:#00c853;}
#indicatorMenu #lzGroup .lzRun,#indicatorMenu #lzGroup .lzRun.active{background:#00838f !important;color:#fff !important;border-color:#00838f !important;}
#indicatorMenu #lzGroup .lzWIn{flex:0 0 58px;width:58px;background:#101a2a;color:#cfe3ee;border:1px solid #1a2a3a;border-radius:6px;padding:6px;text-align:center;font-size:12px;}
#indicatorMenu #lzGroup .lzGear{flex:0 0 auto;width:auto;background:#37474f;color:#fff;border:none;border-radius:6px;padding:6px 10px;cursor:pointer;}
#indicatorMenu #lzGroup .lzTfLbl{flex:0 0 auto;font-size:11px;color:#ffd54f;font-weight:bold;white-space:nowrap;}
#indicatorMenu #lzGroup .lzTfSel{flex:1;width:auto;min-width:0;background:#101a2a;color:#ffd54f;border:1px solid #00838f;border-radius:6px;padding:6px 8px;font-size:12px;cursor:pointer;font-weight:bold;text-align:center;}
</style>
</head>
<body>
<div class="topbar">
<div class="symbolSearch">
<input type="text" id="symbolSearch" placeholder="🔍 جستجوی ارز (مثلاً BTC)" autocomplete="off">
<div class="symbolDropdown" id="symbolDropdown"></div>
</div>
<select id="symbolSelect" style="min-width:130px;"></select>
<button id="btnRefreshSymbols" onclick="loadSymbols(true)" title="بروزرسانی لیست ارزها">🔄</button>
<button class="tf-btn" data-tf="1m">1m</button>
<button class="tf-btn" data-tf="5m">5m</button>
<button class="tf-btn" data-tf="15m">15m</button>
<button class="tf-btn" data-tf="30m">30m</button>
<button class="tf-btn active" data-tf="1h">1h</button>
<button class="tf-btn" data-tf="4h">4h</button>
<button class="tf-btn" data-tf="1d">1d</button>
<select id="limitSelect">
<option value="150">150</option>
<option value="300" selected>300</option>
<option value="500">500</option>
<option value="1000">1000</option>
<option value="1500">1500</option>
<option value="2000">2000</option>
</select>
<button onclick="loadChart()">🔄 بروزرسانی</button>
</div>
<div id="symbolInfo">در حال بارگذاری لیست ارزها از Cloudflare Worker...</div>
<div id="indicatorBar">
<button id="btnIndicatorMenu" onclick="toggleIndicatorMenu()">📚 منوی اندیکاتورها ▾</button>
<div id="indicatorMenu">
<button id="btnIndicator" onclick="toggleIndicator()">📊 اعمال اندیکاتور Alpha</button>
<button id="btnMultiLayer" onclick="toggleMultiLayer()">🧩 اعمال اندیکاتور Multi-Layer</button>
<button id="btnZones" onclick="toggleZonesIndicator()">📐 اعمال اندیکاتور Zones/Zigzag</button>
<button id="btnSignalFilter" onclick="toggleSignalFilter()">📏 اعمال فیلتر تایید سیگنال</button>
<button id="btnStructure" onclick="toggleMarketStructure()">🏗️ اعمال اندیکاتور ساختار بازار</button>
<button id="btnFanProjection" onclick="toggleFanProjection()">🔱 اعمال اندیکاتور Fan Projection</button>
<button id="btnAiPath" onclick="toggleAiPricePath()">🤖 اعمال اندیکاتور AI Price Path</button>
<div id="lzGroup">
<div class="lzTitle">🧠 Lorentzian</div>
<div class="lzRow" id="lzRow1">
<span class="lzName">P1</span>
<button id="btnLzRun1" class="lzRun" onclick="lzRunSingle(1)">▶ اجرا</button>
<input type="number" class="lzWIn" id="lzW1" value="1" step="0.1" min="0" title="ضریب" onchange="lzSetWeight(1)"><button class="lzGear" title="تنظیمات" onclick="lzOpenSettings(1)">⚙️</button>
</div>
<div class="lzRow" id="lzRow2">
<span class="lzName">P2</span>
<button id="btnLzRun2" class="lzRun" onclick="lzRunSingle(2)">▶ اجرا</button>
<input type="number" class="lzWIn" id="lzW2" value="1" step="0.1" min="0" title="ضریب" onchange="lzSetWeight(2)"><button class="lzGear" title="تنظیمات" onclick="lzOpenSettings(2)">⚙️</button>
</div>
<div class="lzRow" id="lzRow3">
<span class="lzName">P3</span>
<button id="btnLzRun3" class="lzRun" onclick="lzRunSingle(3)">▶ اجرا</button>
<input type="number" class="lzWIn" id="lzW3" value="1" step="0.1" min="0" title="ضریب" onchange="lzSetWeight(3)"><button class="lzGear" title="تنظیمات" onclick="lzOpenSettings(3)">⚙️</button>
</div>
<div class="lzRow" id="lzRow4">
<span class="lzName">P4</span>
<button id="btnPf" class="lzRun" onclick="toggleProF()">▶ اجرا</button>
<input type="number" class="lzWIn" id="lzW4" value="1" step="0.1" min="0" title="ضریب" onchange="lzSetWeight(4)"><button class="lzGear" title="تنظیمات" onclick="lzOpenSettings(4)">⚙️</button>
</div>
<div class="lzRow" id="lzRow5">
<span class="lzName">P5</span>
<button id="btnLzRun5" class="lzRun" onclick="lzRunSingle(5)">▶ اجرا</button>
<input type="number" class="lzWIn" id="lzW5" value="1" step="0.1" min="0" title="ضریب" onchange="lzSetWeight(5)"><button class="lzGear" title="تنظیمات" onclick="lzOpenSettings(5)">⚙️</button>
</div>
<div class="lzRow" id="lzRow6">
<span class="lzName">P6</span>
<button id="btnLzRun6" class="lzRun" onclick="lzRunSingle(6)">▶ اجرا</button>
<input type="number" class="lzWIn" id="lzW6" value="1" step="0.1" min="0" title="ضریب" onchange="lzSetWeight(6)"><button class="lzGear" title="تنظیمات" onclick="lzOpenSettings(6)">⚙️</button>
</div>
<div class="lzRow" id="lzRow7">
<span class="lzName">P7</span>
<button id="btnLzRun7" class="lzRun" onclick="lzRunSingle(7)">▶ اجرا</button>
<input type="number" class="lzWIn" id="lzW7" value="1" step="0.1" min="0" title="ضریب" onchange="lzSetWeight(7)"><button class="lzGear" title="تنظیمات" onclick="lzOpenSettings(7)">⚙️</button>
</div>
<button id="btnLzAll" class="lzAll" onclick="lzRunAll()">🚀 اجرای همه ۷ اندیکاتور (پس‌زمینه)</button>
<div class="lzRow" title="تمرکز: «همه» = ۵m/۱۵m/۱h/۴h/۱d. یک تایم‌فریم (مثلاً 5m) = تأییدکننده؛ تنظیم از بقیه یاد گرفته و روی این تایم‌فریم سنجیده می‌شود">
<span class="lzTfLbl">🕒 تمرکز روی</span>
<select id="lzTuneTfSelect" class="lzTfSel" onchange="lzTuneTfChanged()">
<option value="all" selected>همه تایم‌فریم‌ها</option>
<option value="5m">5m</option>
<option value="15m">15m</option>
<option value="30m">30m</option>
<option value="1h">1h</option>
<option value="4h">4h</option>
<option value="1d">1d</option>
<option value="1w">1w</option>
</select>
</div>
<button id="btnLzTune" class="lzAll" onclick="lzSmartTune()">🎯 تنظیم ضریب هوشمند</button>
<button id="btnLzResetTune" class="lzAll" onclick="lzResetWeights()">♻️ ریست ضریب</button>
<button id="btnLzWinF" class="lzAll" onclick="lzWinFilter()">🎯 فیلتر وینریت (A و B)</button>
<button id="btnLzOptAll" class="lzAll" onclick="lzOptimizeAll()">🎯 بهینه‌سازی همه‌ی تنظیمات</button>
<button id="btnLzResetOpt" class="lzAll" onclick="lzResetParams()">♻️ ریست بهینه‌سازی</button>
<button id="btnCrossConfirm" onclick="toggleCrossConfirm()" style="background:#ff6d00;color:#fff;border:2px solid #ff6d00;font-weight:bold;font-size:15px;padding:12px 30px;border-radius:10px;cursor:pointer;box-shadow:0 0 15px rgba(255,109,0,0.6);transition:all 0.2s;margin-top:8px;">🔗 اعمال تأیید متقابل (سیگنال‌های خیلی قوی)</button>
<button id="btnCrossConfirmSettings" onclick="lzOpenCrossConfirmSettings()" style="background:#37474f;color:#fff;border:none;border-radius:6px;padding:8px 12px;cursor:pointer;margin-top:4px;font-size:12px;">⚙️ تنظیمات تأیید متقابل</button>
</div>
<button id="btnMyBot" onclick="toggleMyBot()">🧠 اعمال اندیکاتور MyBot (سیگنال ربات MT5)</button>
<button id="btnBacktest" onclick="toggleBacktestPanel()">🧪 بک‌تست اندیکاتورها</button>
<button id="btnSettings" onclick="toggleSettings()">⚙️ تنظیمات کامل اندیکاتور</button>
</div>
</div>
<div id="colorModeBar">
<span class="colorModeLabel">🎨 مدل رنگ ربان:</span>
<button id="btnModeA" class="colorModeBtn active" onclick="setColorMode('A')">مدل A (سه‌رنگ)</button>
<button id="btnModeB" class="colorModeBtn" onclick="setColorMode('B')">مدل B (دو‌رنگ)</button>
</div>
<div id="settingsPanel">
<div class="settingsGrid">

<div class="settingsGroup">
<h4>EMA Ribbon</h4>
<div class="settingsField"><span>EMA 1</span><input type="number" id="setEma1" value="8"></div>
<div class="settingsField"><span>EMA 2</span><input type="number" id="setEma2" value="13"></div>
<div class="settingsField"><span>EMA 3</span><input type="number" id="setEma3" value="21"></div>
<div class="settingsField"><span>EMA 4</span><input type="number" id="setEma4" value="34"></div>
<div class="settingsField"><span>EMA 5</span><input type="number" id="setEma5" value="55"></div>
<div class="settingsField"><span>EMA 6</span><input type="number" id="setEma6" value="89"></div>
<div class="settingsField"><span>نمایش EMA 50/200</span><input type="checkbox" id="setEma50200"></div>
</div>

<div class="settingsGroup">
<h4>RSI</h4>
<div class="settingsField"><span>طول RSI</span><input type="number" id="setRsiLen" value="14"></div>
<div class="settingsField"><span>سطح اشباع خرید</span><input type="number" id="setRsiOB" value="70"></div>
<div class="settingsField"><span>سطح اشباع فروش</span><input type="number" id="setRsiOS" value="30"></div>
</div>

<div class="settingsGroup">
<h4>MACD</h4>
<div class="settingsField"><span>Fast</span><input type="number" id="setMacdFast" value="12"></div>
<div class="settingsField"><span>Slow</span><input type="number" id="setMacdSlow" value="26"></div>
<div class="settingsField"><span>Signal</span><input type="number" id="setMacdSig" value="9"></div>
</div>

<div class="settingsGroup">
<h4>ATR / SL / TP</h4>
<div class="settingsField"><span>طول ATR</span><input type="number" id="setAtrLen" value="14"></div>
<div class="settingsField"><span>ضریب استاپ (ATR×)</span><input type="number" step="0.1" id="setAtrStopMult" value="1.5"></div>
<div class="settingsField"><span>گام تارگت دستی (ATR×) — فقط اگر خودکار خاموش باشه</span><input type="number" step="0.1" id="setAtrTargetStep" value="1"></div>
<div class="settingsField"><span>تعداد تارگت</span><input type="number" id="setTargetCount" value="4"></div>
<div class="settingsField"><span>ریسک به ریوارد خودکار (بر اساس قدرت روند)</span><input type="checkbox" id="setAutoRR" checked></div>
<div class="settingsField"><span>حداقل R:R (ایمن)</span><input type="number" step="0.1" id="setMinRR" value="1.5"></div>
<div class="settingsField"><span>حداکثر R:R (روند قوی)</span><input type="number" step="0.1" id="setMaxRR" value="3"></div>
</div>

<div class="settingsGroup">
<h4>Signal Engine</h4>
<div class="settingsField"><span>Confirm on Bar Close</span><input type="checkbox" id="setConfirmClose" checked></div>
<div class="settingsField"><span>تعداد کندل تایید</span><input type="number" id="setConfirmBars" value="2"></div>
</div>

<div class="settingsGroup">
<h4>🧩 Multi-Layer Confirmation</h4>
<div class="settingsField"><span>طول ATR (لایه نوسان)</span><input type="number" id="setMlAtrLen" value="14"></div>
<div class="settingsField"><span>ضریب حداقل نوسان</span><input type="number" step="0.1" id="setMlVolMult" value="1.0"></div>
<div class="settingsField"><span>طول RSI (لایه مومنتوم)</span><input type="number" id="setMlRsiLen" value="14"></div>
<div class="settingsField"><span>خط میانی RSI</span><input type="number" id="setMlRsiMid" value="50"></div>
<div class="settingsField"><span>EMA سریع (لایه روند)</span><input type="number" id="setMlEmaFast" value="9"></div>
<div class="settingsField"><span>EMA کند (لایه روند)</span><input type="number" id="setMlEmaSlow" value="21"></div>
<div class="settingsField"><span>حداقل بدنه کندل (٪ از رنج)</span><input type="number" id="setMlBodyPct" value="40"></div>
<div class="settingsField"><span>ضریب استاپ (ATR×)</span><input type="number" step="0.1" id="setMlAtrStopMult" value="1.5"></div>
<div class="settingsField"><span>گام تارگت دستی (ATR×) — فقط اگر خودکار خاموش باشه</span><input type="number" step="0.1" id="setMlAtrTargetStep" value="1"></div>
<div class="settingsField"><span>تعداد تارگت</span><input type="number" id="setMlTargetCount" value="4"></div>
<div class="settingsField"><span>ریسک به ریوارد خودکار (بر اساس قدرت روند)</span><input type="checkbox" id="setMlAutoRR" checked></div>
<div class="settingsField"><span>حداقل R:R (ایمن)</span><input type="number" step="0.1" id="setMlMinRR" value="1.5"></div>
<div class="settingsField"><span>حداکثر R:R (روند قوی)</span><input type="number" step="0.1" id="setMlMaxRR" value="3"></div>
</div>

<div class="settingsGroup">
<h4>📏 Signal Confirmation Filter</h4>
<div class="settingsField"><span>طول EMA کند (خط روند اصلی)</span><input type="number" id="setSfLen" value="100"></div>
<div class="settingsField"><span>طول EMA تند (تاییدیه دوم)</span><input type="number" id="setSfFastLen" value="34"></div>
<div class="settingsField"><span>تعداد کندل سنجش شیب</span><input type="number" id="setSfSlopeLookback" value="14"></div>
<div class="settingsField"><span>طول ATR (منطقه خنثی)</span><input type="number" id="setSfAtrLen" value="14"></div>
<div class="settingsField"><span>ضریب بافر ATR</span><input type="number" step="0.05" id="setSfBufferMult" value="0.25"></div>
<div class="settingsField"><span>حداقل امتیاز تایید قوی (✅✅)</span><input type="number" id="setSfStrongScore" value="2"></div>
<div class="settingsField"><span>حداقل امتیاز تایید ضعیف (✅)</span><input type="number" id="setSfWeakScore" value="1"></div>
<div class="settingsField"><span>نمایش خطوط EMA روی چارت</span><input type="checkbox" id="setSfShowLines" checked></div>
</div>

<div class="settingsGroup">
<h4>🔱 Fan Projection (مثلث سوئینگ + بادبزن + پیش‌بینی)</h4>
<div class="settingsField"><span>پیوت چپ</span><input type="number" id="setFpPivotLeft" value="5"></div>
<div class="settingsField"><span>پیوت راست</span><input type="number" id="setFpPivotRight" value="5"></div>
<div class="settingsField"><span>تعداد خطوط بادبزن</span><input type="number" id="setFpFanRays" value="4"></div>
<div class="settingsField"><span>طول رگرسیون پیش‌بینی</span><input type="number" id="setFpRegLen" value="20"></div>
<div class="settingsField"><span>تعداد کندل پیش‌بینی</span><input type="number" id="setFpProjBars" value="10"></div>
</div>

<div class="settingsGroup">
<h4>🤖 AI Price Path (زیگزاگ هارمونیک + مسیر پیش‌بینی + اهداف فیبوناچی)</h4>
<div class="settingsField"><span>پیوت چپ</span><input type="number" id="setAiPivotLeft" value="5"></div>
<div class="settingsField"><span>پیوت راست</span><input type="number" id="setAiPivotRight" value="5"></div>
<div class="settingsField"><span>تعداد کندل پیش‌بینی مسیر</span><input type="number" id="setAiProjBars" value="40"></div>
<div class="settingsField"><span>افق بک‌تست (کندل)</span><input type="number" id="setAiBtHorizon" value="10"></div>
<div class="settingsField"><span>ضریب دامنه مسیر پیش‌بینی</span><input type="number" step="0.1" id="setAiVolMult" value="1.0"></div>
<div class="settingsField"><span>ضریب حد ضرر (ATR×)</span><input type="number" step="0.1" id="setAiAtrStopMult" value="1.5"></div>
<div class="settingsField"><span>سطوح فیبوناچی اهداف (٪، جدا با کاما)</span><input type="text" id="setAiFibLevels" value="127.2,161.8,200,261.8,423.6,600"></div>
</div>


<div class="settingsGroup" id="grpP1">
<h4>🟩 P1 - FVG Order Blocks [BigBeluga]</h4>
<div class="settingsField"><span>Filter Gaps by %</span><input type="number" step="0.1" min="0" max="100" id="setFvgMinPct" value="0.8" onchange="fvgRedraw()"></div>
<div class="settingsField"><span>Fair Value Gaps (باکس خاکستری گپ)</span><input type="checkbox" id="setFvgShowGap" checked onchange="fvgRedraw()"></div>
<div class="settingsField"><span>Blocks Amount</span><input type="number" step="1" min="1" max="50" id="setFvgCount" value="4" onchange="fvgRedraw()"></div>
<div class="settingsField"><span>Broken Blocks</span><input type="checkbox" id="setFvgBroken" onchange="fvgRedraw()"></div>
<div class="settingsField"><span>Order Blocks Signals</span><input type="checkbox" id="setFvgSignals" onchange="fvgRedraw()"></div>
<div class="settingsField"><span>Color +</span><input type="color" id="setFvgBullCol" value="#14be94" onchange="fvgRedraw()"></div>
<div class="settingsField"><span>Color -</span><input type="color" id="setFvgBearCol" value="#c21919" onchange="fvgRedraw()"></div>
</div>

<div class="settingsGroup" id="grpP3">
<h4>🤖 P3 - ML Adaptive SuperTrend [AlgoAlpha]</h4>
<div class="settingsField"><span>ATR Length</span><input type="number" step="1" min="1" id="setMlStAtr" value="10" onchange="mlstRedraw()"></div>
<div class="settingsField"><span>SuperTrend Factor</span><input type="number" step="0.1" id="setMlStFact" value="3.5" onchange="mlstRedraw()"></div>
<div class="settingsField"><span>Training Data Length</span><input type="number" step="1" min="10" id="setMlStTrain" value="100" onchange="mlstRedraw()"></div>
<div class="settingsField"><span>High volatility percentile</span><input type="number" step="0.05" max="1" id="setMlStHigh" value="0.75" onchange="mlstRedraw()"></div>
<div class="settingsField"><span>Medium volatility percentile</span><input type="number" step="0.05" max="1" id="setMlStMid" value="0.5" onchange="mlstRedraw()"></div>
<div class="settingsField"><span>Low volatility percentile</span><input type="number" step="0.05" max="1" id="setMlStLow" value="0.25" onchange="mlstRedraw()"></div>
<div class="settingsField"><span>Transparency 1</span><input type="number" step="1" min="0" max="100" id="setMlStT1" value="70" onchange="mlstRedraw()"></div>
<div class="settingsField"><span>Transparency 2</span><input type="number" step="1" min="0" max="100" id="setMlStT2" value="95" onchange="mlstRedraw()"></div>
<div class="settingsField"><span>Bullish Color</span><input type="color" id="setMlStGreen" value="#00ffbb" onchange="mlstRedraw()"></div>
<div class="settingsField"><span>Bearish Color</span><input type="color" id="setMlStRed" value="#ff1100" onchange="mlstRedraw()"></div>
<div class="settingsField"><span>جدول کلاستر (Table)</span><input type="checkbox" id="setMlStTable" onchange="mlstRedraw()"></div>
</div>

<div class="settingsGroup" id="grpP6">
<h4>📦 P6 - Smart Money Breakout Channels [AlgoAlpha]</h4>
<div class="settingsField"><span>Nested Channels</span><input type="checkbox" id="setBrOverlap" onchange="brRedraw()"></div>
<div class="settingsField"><span>Strong Closes Only</span><input type="checkbox" id="setBrStrong" checked onchange="brRedraw()"></div>
<div class="settingsField"><span>Normalization Length</span><input type="number" step="1" min="2" id="setBrNormLen" value="100" onchange="brRedraw()"></div>
<div class="settingsField"><span>Box Detection Length</span><input type="number" step="1" min="1" id="setBrLen" value="18" onchange="brRedraw()"></div>
<div class="settingsField"><span>Show Volume Analysis</span><input type="checkbox" id="setBrShowVol" checked onchange="brRedraw()"></div>
<div class="settingsField"><span>Volume Display Mode</span><select id="setBrMode" onchange="brRedraw()"><option value="Volume">Volume</option><option value="Comparison" selected>Comparison</option><option value="Delta">Delta</option></select></div>
<div class="settingsField"><span>Volume Scale</span><input type="number" step="0.1" min="0.1" max="2" id="setBrScale" value="0.5" onchange="brRedraw()"></div>
<div class="settingsField"><span>Volume Text Size</span><select id="setBrTextSize" onchange="brRedraw()"><option value="Tiny" selected>Tiny</option><option value="Small">Small</option><option value="Medium">Medium</option><option value="Large">Large</option></select></div>
<div class="settingsField"><span>Bullish Colour</span><input type="color" id="setBrGreen" value="#00ffbb" onchange="brRedraw()"></div>
<div class="settingsField"><span>Bearish Colour</span><input type="color" id="setBrRed" value="#ff1100" onchange="brRedraw()"></div>
</div>

<div class="settingsGroup" id="grpP2">
<h4>🔥 P2 - Impulse Heatmap (بازسازی از روی توضیحات)</h4>
<div class="settingsField"><span>Period</span><input type="number" step="1" min="30" id="setIhPeriod" value="120" onchange="ihRedraw()"></div>
<div class="settingsField"><span>POC Smooth</span><input type="number" step="1" min="1" id="setIhSmooth" value="10" onchange="ihRedraw()"></div>
<div class="settingsField"><span>Heatmap Opacity (٪)</span><input type="number" step="5" min="5" max="100" id="setIhOpacity" value="60" onchange="ihRedraw()"></div>
<div class="settingsField"><span>High Heat Color</span><input type="color" id="setIhHeat" value="#ff1100" onchange="ihRedraw()"></div>
<div class="settingsField"><span>Show POC Line</span><input type="checkbox" id="setIhPoc" checked onchange="ihRedraw()"></div>
<div class="settingsField"><span>POC Color</span><input type="color" id="setIhPocCol" value="#ff1100" onchange="ihRedraw()"></div>
<div class="settingsField"><span>Show Volume (حجم داخل زون‌های داغ)</span><input type="checkbox" id="setIhVol" onchange="ihRedraw()"></div>
<div class="settingsField"><span>Volume Label Color</span><input type="color" id="setIhVolCol" value="#ffffff" onchange="ihRedraw()"></div>
<div class="settingsField"><span>Trend EMA Length</span><input type="number" step="1" min="2" id="setIhEma" value="50" onchange="ihRedraw()"></div>
<div class="settingsField"><span>Trend Filter روی سیگنال‌ها</span><input type="checkbox" id="setIhTrend" checked onchange="ihRedraw()"></div>
<div class="settingsField"><span>Retest Labels</span><input type="checkbox" id="setIhRetest" checked onchange="ihRedraw()"></div>
<div class="settingsField"><span>Retest Bounce UP Color</span><input type="color" id="setIhRtUp" value="#00e676" onchange="ihRedraw()"></div>
<div class="settingsField"><span>Retest Reject DOWN Color</span><input type="color" id="setIhRtDn" value="#ff1744" onchange="ihRedraw()"></div>
<div class="settingsField"><span>Buy / Sell Signals</span><input type="checkbox" id="setIhSig" checked onchange="ihRedraw()"></div>
<div class="settingsField"><span>Buy Color</span><input type="color" id="setIhBuy" value="#00c853" onchange="ihRedraw()"></div>
<div class="settingsField"><span>Sell Color</span><input type="color" id="setIhSell" value="#ff1744" onchange="ihRedraw()"></div>
</div>

<div class="settingsGroup" id="grpP4" style="grid-column:1/-1;">
<h4>🧠 Lorentzian ML (جایگزین Pro F)</h4>
<div class="settingsField"><span>پیش‌تنظیم</span><select id="setPfPreset" onchange="pfPresetChanged(this.value)"><option value="power" selected>💪 قدرتی (بدون محدودیت - پیشنهادی)</option><option value="strict">دقیق‌تر (سیگنال کمتر)</option><option value="balanced">متعادل (قدیمی)</option><option value="more">سیگنال بیشتر</option></select></div>
<div class="settingsField"><span>موتور سیگنال</span><select id="setPfSetup"><option value="lorentzian" selected>🧠 Lorentzian Classification (ML)</option><option value="trend">روندی (Supertrend)</option><option value="revert">بازگشت به میانگین (RSI + Bollinger)</option></select></div>
<h4 style="grid-column:1/-1;margin:8px 0 2px;">🧠 Lorentzian Classification (Machine Learning)</h4>
<div class="settingsField"><span>تعداد همسایه‌ها (Neighbors Count)</span><input type="number" step="1" id="setLzK" value="12"></div>
<div class="settingsField"><span>حداکثر کندل مرجع (Max Bars Back)</span><input type="number" step="1" id="setLzMaxBars" value="2000"></div>
<div class="settingsField"><span>تعداد فیچرها (Feature Count)</span><select id="setLzFc"><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5" selected>5</option></select></div>
<div class="settingsField"><span>فیچر 1</span><select id="setLzF1t"><option value="RSI" selected>RSI</option><option value="WT">WT</option><option value="CCI">CCI</option><option value="ADX">ADX</option></select></div>
<div class="settingsField"><span>فیچر 1 - پارامتر A</span><input type="number" step="1" id="setLzF1a" value="14"></div>
<div class="settingsField"><span>فیچر 1 - پارامتر B</span><input type="number" step="1" id="setLzF1b" value="1"></div>
<div class="settingsField"><span>فیچر 2</span><select id="setLzF2t"><option value="RSI">RSI</option><option value="WT" selected>WT</option><option value="CCI">CCI</option><option value="ADX">ADX</option></select></div>
<div class="settingsField"><span>فیچر 2 - پارامتر A</span><input type="number" step="1" id="setLzF2a" value="10"></div>
<div class="settingsField"><span>فیچر 2 - پارامتر B</span><input type="number" step="1" id="setLzF2b" value="11"></div>
<div class="settingsField"><span>فیچر 3</span><select id="setLzF3t"><option value="RSI">RSI</option><option value="WT">WT</option><option value="CCI" selected>CCI</option><option value="ADX">ADX</option></select></div>
<div class="settingsField"><span>فیچر 3 - پارامتر A</span><input type="number" step="1" id="setLzF3a" value="20"></div>
<div class="settingsField"><span>فیچر 3 - پارامتر B</span><input type="number" step="1" id="setLzF3b" value="1"></div>
<div class="settingsField"><span>فیچر 4</span><select id="setLzF4t"><option value="RSI">RSI</option><option value="WT">WT</option><option value="CCI">CCI</option><option value="ADX" selected>ADX</option></select></div>
<div class="settingsField"><span>فیچر 4 - پارامتر A</span><input type="number" step="1" id="setLzF4a" value="20"></div>
<div class="settingsField"><span>فیچر 4 - پارامتر B</span><input type="number" step="1" id="setLzF4b" value="2"></div>
<div class="settingsField"><span>فیچر 5</span><select id="setLzF5t"><option value="RSI" selected>RSI</option><option value="WT">WT</option><option value="CCI">CCI</option><option value="ADX">ADX</option></select></div>
<div class="settingsField"><span>فیچر 5 - پارامتر A</span><input type="number" step="1" id="setLzF5a" value="9"></div>
<div class="settingsField"><span>فیچر 5 - پارامتر B</span><input type="number" step="1" id="setLzF5b" value="1"></div>
<div class="settingsField"><span>فیلتر نوسان (Volatility)</span><input type="checkbox" id="setLzVol" checked></div>
<div class="settingsField"><span>فیلتر رژیم (Regime)</span><input type="checkbox" id="setLzRegime" checked></div>
<div class="settingsField"><span>فیلتر ADX</span><input type="checkbox" id="setLzAdx" checked></div>
<div class="settingsField"><span>آستانه رژیم (Regime Threshold)</span><input type="number" step="any" id="setLzRegimeThr" value="-0.1"></div>
<div class="settingsField"><span>آستانه ADX</span><input type="number" step="1" id="setLzAdxThr" value="22"></div>
<div class="settingsField"><span>فیلتر EMA</span><input type="checkbox" id="setLzEma"></div>
<div class="settingsField"><span>دوره EMA</span><input type="number" step="1" id="setLzEmaP" value="200"></div>
<div class="settingsField"><span>فیلتر SMA</span><input type="checkbox" id="setLzSma"></div>
<div class="settingsField"><span>دوره SMA</span><input type="number" step="1" id="setLzSmaP" value="200"></div>
<div class="settingsField"><span>معامله با کرنل (Trade with Kernel)</span><input type="checkbox" id="setLzKernel" checked></div>
<div class="settingsField"><span>نمایش خط کرنل (Kernel Estimate)</span><input type="checkbox" id="setLzKernelShow" checked></div>
<div class="settingsField"><span>هموارسازی کرنل (Kernel Smoothing)</span><input type="checkbox" id="setLzKernelSmooth"></div>
<div class="settingsField"><span>Lookback Window</span><input type="number" step="1" id="setLzH" value="8"></div>
<div class="settingsField"><span>Relative Weighting</span><input type="number" step="any" id="setLzR" value="8"></div>
<div class="settingsField"><span>Start Regression at Bar</span><input type="number" step="1" id="setLzX" value="25"></div>
<div class="settingsField"><span>Lag (هموارسازی)</span><input type="number" step="1" id="setLzLag" value="2"></div>
<div class="settingsField"><span>خروج داینامیک (Use Dynamic Exits)</span><input type="checkbox" id="setLzDyn"></div>
<div class="settingsField"><span>نمایش خروج‌ها (Show Exits)</span><input type="checkbox" id="setLzShowExits"></div>
<div class="settingsField"><span>استفاده از کل تاریخچه برای همسایه‌ها (Include Full History)</span><input type="checkbox" id="setLzFullHist"></div>
<div class="settingsField"><span>برچسب آموزش</span><select id="setLzLabel"><option value="literal" selected>مثل کد اصلی اندیکاتور</option><option value="forward">جهت واقعی ۴ کندل بعد (آزمایشی)</option></select></div>
<div class="settingsField"><span>نمایش عدد پیش‌بینی روی ۱۵۰ کندل آخر</span><input type="checkbox" id="setLzShowPred"></div>
<h4 style="grid-column:1/-1;margin:10px 0 2px;">⚙️ تنظیمات موتور قدیمی Pro F (فقط وقتی موتور روندی/بازگشتی انتخاب شود)</h4>
<div class="settingsField"><span>نوع ورود</span><select id="setPfEntryMode"><option value="all" selected>همه: برگشت + پولبک + شکست (BRK)</option><option value="breakout">فقط شکست سقف/کف (BRK)</option><option value="both">برگشت روند + پولبک</option><option value="flip">فقط برگشت روند (FLIP)</option><option value="pullback">فقط پولبک (PB)</option></select></div>
<div class="settingsField"><span>جهت معاملات</span><select id="setPfDir"><option value="both" selected>هر دو</option><option value="long">فقط خرید</option><option value="short">فقط فروش</option></select></div>
<div class="settingsField"><span>تایید تایم‌فریم بالاتر</span><select id="setPfHtfMode"><option value="strict">سخت‌گیرانه (هم‌جهت باشد)</option><option value="soft">ملایم (مخالف نباشد)</option><option value="off" selected>خاموش</option></select></div>
<div class="settingsField"><span>تایم‌فریم تایید ۱</span><select id="setPfHtf1"><option value="auto" selected>خودکار (تایم‌فریم بالاتر)</option><option value="off">خاموش</option><option value="5m">5m</option><option value="15m">15m</option><option value="30m">30m</option><option value="1h">1h</option><option value="4h">4h</option><option value="1d">1d</option><option value="1w">1w</option></select></div>
<div class="settingsField"><span>تایم‌فریم تایید ۲ (اختیاری)</span><select id="setPfHtf2"><option value="off" selected>خاموش</option><option value="auto">خودکار (تایم‌فریم بالاتر)</option><option value="5m">5m</option><option value="15m">15m</option><option value="30m">30m</option><option value="1h">1h</option><option value="4h">4h</option><option value="1d">1d</option><option value="1w">1w</option></select></div>
<div class="settingsField"><span>سیگنال فقط روی کندل بسته‌شده (بدون ریپینت)</span><input type="checkbox" id="setPfClosedOnly" checked></div>
<div class="settingsField"><span>دوره اندیکاتورها متناسب با تایم‌فریم</span><input type="checkbox" id="setPfTfAdaptive" checked></div>
<div class="settingsField"><span>حداقل امتیاز کیفیت (۰ تا ۱۰)</span><input type="number" step="any" id="setPfMinScore" value="0"></div>
<div class="settingsField"><span>فیلتر رژیم بازار (ADX + Hurst)</span><input type="checkbox" id="setPfRegime"></div>
<div class="settingsField"><span>سقف ADX برای بازار رنج</span><input type="number" step="any" id="setPfRegimeAdx" value="25"></div>
<div class="settingsField"><span>حداقل Hurst (زیر آن رنج است)</span><input type="number" step="any" id="setPfHurstMin" value="0.55"></div>
<div class="settingsField"><span>حداقل نوسان ATR٪</span><input type="number" step="any" id="setPfMinAtrPct" value="0"></div>
<div class="settingsField"><span>حداکثر نوسان ATR٪ (۰=خاموش)</span><input type="number" step="any" id="setPfMaxAtrPct" value="0"></div>
<div class="settingsField"><span>ضریب Supertrend</span><input type="number" step="any" id="setPfStMult" value="3"></div>
<div class="settingsField"><span>طول ATR</span><input type="number" step="any" id="setPfAtrLen" value="14"></div>
<div class="settingsField"><span>EMA سریع</span><input type="number" step="any" id="setPfEmaFast" value="21"></div>
<div class="settingsField"><span>EMA کند</span><input type="number" step="any" id="setPfEmaSlow" value="55"></div>
<div class="settingsField"><span>EMA روند اصلی</span><input type="number" step="any" id="setPfEmaTrend" value="200"></div>
<div class="settingsField"><span>حداقل ADX (قدرت روند)</span><input type="number" step="any" id="setPfAdxMin" value="18"></div>
<div class="settingsField"><span>حداقل بدنه کندل (٪)</span><input type="number" step="any" id="setPfBody" value="40"></div>
<div class="settingsField"><span>حداقل حجم نسبت به میانگین (۰=خاموش)</span><input type="number" step="any" id="setPfVol" value="0"></div>
<div class="settingsField"><span>فاصله دو سیگنال هم‌جهت (کندل)</span><input type="number" step="any" id="setPfCooldown" value="0"></div>
<div class="settingsField"><span>حالت حد ضرر</span><select id="setPfSlMode"><option value="swing" selected>سوئینگ (کف/سقف اخیر)</option><option value="atr">ATR ثابت</option></select></div>
<div class="settingsField"><span>ضریب ATR حد ضرر</span><input type="number" step="any" id="setPfSlAtr" value="1.5"></div>
<div class="settingsField"><span>طول سوئینگ حد ضرر (کندل)</span><input type="number" step="any" id="setPfSwing" value="8"></div>
<div class="settingsField"><span>ریسک به ریوارد TP1 (R)</span><input type="number" step="any" id="setPfRR1" value="1.2"></div>
<div class="settingsField"><span>ریسک به ریوارد TP2 (R)</span><input type="number" step="any" id="setPfRR2" value="10"></div>
<div class="settingsField"><span>RR تطبیقی (بر اساس نوسان و ADX)</span><input type="checkbox" id="setPfAdaptRR"></div>
<div class="settingsField"><span>درصد بسته‌شدن در TP1</span><input type="number" step="any" id="setPfTp1Pct" value="30"></div>
<div class="settingsField"><span>انتقال حد ضرر به ورود بعد از TP1</span><input type="checkbox" id="setPfBE" checked></div>
<div class="settingsField"><span>تریلینگ با Supertrend بعد از TP1</span><input type="checkbox" id="setPfTrail" checked></div>
<div class="settingsField"><span>استفاده از پروفایل بهینه هر تایم‌فریم (اگر ذخیره شده باشد)</span><input type="checkbox" id="setPfUseProfile" checked></div>
<div class="settingsField"><span>تریلینگ شاندلیر (از +R فعال می‌شود)</span><input type="checkbox" id="setPfChTrail" checked></div>
<div class="settingsField"><span>ضریب ATR تریلینگ شاندلیر</span><input type="number" step="any" id="setPfChMult" value="2.5"></div>
<div class="settingsField"><span>شروع تریلینگ از چند R</span><input type="number" step="any" id="setPfTrailStartR" value="1"></div>
<div class="settingsField"><span>طول شکست سقف/کف BRK (کندل)</span><input type="number" step="any" id="setPfBrkLen" value="20"></div>
<div class="settingsField"><span>حداکثر نگهداری معامله (کندل)</span><input type="number" step="any" id="setPfMaxHold" value="1000"></div>
<div class="settingsField"><span>اندازه فلش‌های ورود (۱ تا ۵)</span><input type="number" step="any" id="setPfArrow" value="2"></div>
<div class="settingsField"><span>نمایش خط Supertrend</span><input type="checkbox" id="setPfShowLine" checked></div>
<div class="settingsField"><span>نمایش خطوط ورود/SL/TP معاملات</span><input type="checkbox" id="setPfShowLevels" checked></div>
<div class="settingsField"><span>نمایش کارت آمار و وین‌ریت</span><input type="checkbox" id="setPfShowCard" checked></div>
</div>

<div class="settingsGroup" id="grpP5">
<h4>⚡ P5 - Pro Scalper (تقریبی)</h4>
<div class="settingsField"><span>Kalman Q (نویز فرایند)</span><input type="number" step="any" id="setPsQ" value="0.01" onchange="psRedraw()"></div>
<div class="settingsField"><span>Kalman R (نویز اندازه‌گیری)</span><input type="number" step="any" id="setPsR" value="0.5" onchange="psRedraw()"></div>
<div class="settingsField"><span>طول ATR</span><input type="number" step="1" id="setPsAtrLen" value="10" onchange="psRedraw()"></div>
<div class="settingsField"><span>ضریب سوپرترند</span><input type="number" step="0.1" id="setPsMult" value="3.5" onchange="psRedraw()"></div>
<div class="settingsField"><span>طول VWMA</span><input type="number" step="1" id="setPsVLen" value="20" onchange="psRedraw()"></div>
<div class="settingsField"><span>ضریب باند (ATR×)</span><input type="number" step="0.1" id="setPsBandMult" value="1.5" onchange="psRedraw()"></div>
<div class="settingsField"><span>نمایش باندهای VWMA</span><input type="checkbox" id="setPsBands" checked onchange="psRedraw()"></div>
<div class="settingsField"><span>نمایش R (بازگشت)</span><input type="checkbox" id="setPsShowR" checked onchange="psRedraw()"></div>
<div class="settingsField"><span>نمایش X (تیک پروفیت)</span><input type="checkbox" id="setPsShowX" checked onchange="psRedraw()"></div>
</div>
<div class="settingsGroup" id="grpP7">
<h4>🟡 P7 - Swift Algo X (تقریبی)</h4>
<div class="settingsField"><span>طول فشار (Pressure)</span><input type="number" step="1" id="setSxPressLen" value="5" onchange="sxRedraw()"></div>
<div class="settingsField"><span>EMA سریع فشار</span><input type="number" step="1" id="setSxFast" value="5" onchange="sxRedraw()"></div>
<div class="settingsField"><span>EMA کند فشار</span><input type="number" step="1" id="setSxSlow" value="20" onchange="sxRedraw()"></div>
<div class="settingsField"><span>طول انحراف معیار</span><input type="number" step="1" id="setSxSd" value="50" onchange="sxRedraw()"></div>
<div class="settingsField"><span>طول ATR</span><input type="number" step="1" id="setSxAtr" value="14" onchange="sxRedraw()"></div>
<div class="settingsField"><span>EMA مرجع</span><input type="number" step="1" id="setSxRef" value="21" onchange="sxRedraw()"></div>
<div class="settingsField"><span>ضریب باند (ATR×)</span><input type="number" step="0.1" id="setSxMult" value="2" onchange="sxRedraw()"></div>
<div class="settingsField"><span>طول ساختار SL (کندل)</span><input type="number" step="1" id="setSxStruct" value="10" onchange="sxRedraw()"></div>
<div class="settingsField"><span>ریسک به ریوارد (RR)</span><input type="number" step="0.1" id="setSxRR" value="1.5" onchange="sxRedraw()"></div>
<div class="settingsField"><span>حداکثر فاصله SL (٪، ۰=خاموش)</span><input type="number" step="0.1" id="setSxMaxSl" value="0" onchange="sxRedraw()"></div>
<div class="settingsField"><span>فیلتر EMA روند</span><input type="checkbox" id="setSxUseTrend" checked onchange="sxRedraw()"></div>
<div class="settingsField"><span>طول EMA روند</span><input type="number" step="1" id="setSxTrendLen" value="150" onchange="sxRedraw()"></div>
</div>

<div class="settingsGroup" id="grpCrossConfirm">
<h4>🔗 تأیید متقابل (Cross-Confirmation)</h4>
<div class="settingsField"><span>حداقل تعداد اندیکاتور هم‌جهت</span><input type="number" id="setCrossMinInd" value="2" min="2" max="7"></div>
<div class="settingsField"><span>نمایش جزئیات در کنسول</span><input type="checkbox" id="setCrossDebug"></div>
</div>
<div class="settingsGroup" id="grpLzAll">
<h4>Σ اجرای همه P1..P7 (امتیاز وزنی)</h4>
<div class="settingsField"><span>بازه‌ی هر سیگنال (کندل)</span><input type="number" step="1" id="setLzAllAge" value="10"></div>
<div class="settingsField"><span>حداقل امتیاز وزنی برای سیگنال</span><input type="number" step="0.1" id="setLzAllThr" value="4"></div>
<div class="settingsField"><span>فقط وقتی همه هم‌جهت باشند</span><input type="checkbox" id="setLzAllStrict"></div>
<div class="settingsField"><span>ریوارد (RR) برای فیلتر وینریت</span><input type="number" step="0.1" id="setLzAllRR" value="1.5"></div>
<div class="settingsField"><span>حد ضرر با ATR (۰ = ساختار کندل)</span><input type="number" step="0.1" id="setLzAllSlAtr" value="0"></div>
</div>
<div class="settingsGroup">
<h4>Exit Signals</h4>
<div class="settingsField"><span>فعال‌سازی کلی خروج</span><input type="checkbox" id="setExitMaster" checked></div>
<div class="settingsField"><span>خروج RSI</span><input type="checkbox" id="setExitRSI" checked></div>
<div class="settingsField"><span>خروج MACD</span><input type="checkbox" id="setExitMACD" checked></div>
<div class="settingsField"><span>خروج کراس EMA</span><input type="checkbox" id="setExitEMA" checked></div>
<div class="settingsField"><span>خروج ساختاری روبان</span><input type="checkbox" id="setExitStruct" checked></div>
</div>

<div class="settingsGroup">
<h4>Display</h4>
<div class="settingsField"><span>مدل رنگ ربان</span>
<select id="setColorMode"><option value="A" selected>مدل A (سه‌رنگ: صعودی/نزولی/گذار)</option><option value="B">مدل B (دو‌رنگ: فقط سبز/قرمز)</option></select>
</div>
<div class="settingsField"><span>نمایش داشبورد</span><input type="checkbox" id="setShowDash" checked></div>
<div class="settingsField"><span>حالت داشبورد</span>
<select id="setDashMode"><option value="compact">فشرده</option><option value="detailed" selected>کامل</option></select>
</div>
<div class="settingsField"><span>پنل چند‌تایم‌فریم</span><input type="checkbox" id="setShowMTF" checked></div>
<div class="settingsField"><span>موقعیت داشبورد</span>
<select id="setDashPos"><option value="left" selected>چپ‌بالا</option><option value="right">راست‌بالا</option></select>
</div>
<div class="settingsField"><span>رنگ‌آمیزی کندل بر اساس روبان</span><input type="checkbox" id="setCandleColor"></div>
<div class="settingsField"><span>لیبل Golden/Death Cross</span><input type="checkbox" id="setShowCross" checked></div>
</div>

</div>
<div style="text-align:center;margin-top:10px;">
<button onclick="applySettings()">✅ اعمال تنظیمات و رسم مجدد</button>
</div>
</div>
<div class="legend">
<span><span class="dot" style="background:#00c853;"></span>روبان صعودی / خرید</span>
<span><span class="dot" style="background:#ff1744;"></span>روبان نزولی / فروش</span>
<span><span class="dot" style="background:#888899;"></span>حالت گذار (بدون سیگنال)</span>
<span><span class="dot" style="background:#ff9800;"></span>اندیکاتور فعال</span>
<span><span class="dot" style="background:#ffd700;"></span>Golden Cross</span>
<span><span class="dot" style="background:#9c27b0;"></span>Death Cross</span>
<span><span class="dot" style="background:#00e5ff;"></span>سیگنال Multi-Layer خرید</span>
<span><span class="dot" style="background:#aa00ff;"></span>سیگنال Multi-Layer فروش</span>
<span><span class="dot" style="background:#ffffff;"></span>مثلث سوئینگ Fan Projection</span>
<span><span class="dot" style="background:#2196f3;"></span>پیش‌بینی رگرسیون صعودی</span>
<span><span class="dot" style="background:#ff1744;"></span>پیش‌بینی رگرسیون نزولی</span>
<span><span class="dot" style="background:#ffd700;"></span>مسیر پیش‌بینی AI Price Path</span>
<span><span class="dot" style="background:#2962ff;"></span>زیگزاگ هارمونیک X-A-B-C-D</span>
<span><span class="dot" style="background:#4caf50;"></span>اهداف فیبوناچی (TP)</span>
<span><span class="dot" style="background:#00e676;"></span>Lorentzian: ورود خرید / کرنل صعودی</span>
<span><span class="dot" style="background:#ff1744;"></span>Lorentzian: ورود فروش / کرنل نزولی</span>
<span><span class="dot" style="background:#ffd54f;"></span>Lorentzian: خروج ۴ کندلی / فلیپ سیگنال</span>
</div>
<div id="chartWrap">
<div id="chartDiv"></div>
<div id="dashboard"><div class="dTitle"><span>📊 Alpha Algo Dashboard</span><span class="dCollapseBtn" id="dashCollapseBtn" onclick="toggleDashboardCollapse()">▲</span></div><div id="dashboardBody"></div></div>
<div id="aiTradeCard"></div>
<div id="pfCard"></div>
<div id="mbCard"></div>
<div id="mbTradesModal" onclick="if(event.target===this)mbCloseTrades()"><div id="mbTradesBox"><div class="mbtHead"><span>📋 معامله‌های MyBot (شبیه‌سازی)</span><span class="mbtClose" onclick="mbCloseTrades()">✕</span></div><div id="mbTradesBody"></div></div></div>
<div id="btModal"><div id="btBox">
<div class="btHead"><span>🧪 بک‌تست اندیکاتور</span><span class="btClose" onclick="toggleBacktestPanel()">✕</span></div>
<div class="btForm">
<label>اندیکاتور<select id="btIndicator">
<option value="alpha">📊 Alpha Ribbon</option>
<option value="multilayer">🧩 Multi-Layer</option>
<option value="zones">📐 Zones/Zigzag</option>
<option value="signalfilter">📏 فیلتر تایید سیگنال</option>
<option value="structure">🏗️ ساختار بازار (BOS)</option>
<option value="fan">🔱 Fan Projection</option>
<option value="aipath">🤖 AI Price Path</option>
<option value="pf">🧠 Lorentzian ML (ورود/خروج)</option>
<option value="mybot">🧠 MyBot (سیگنال + هج، دلاری)</option>
<option value="p1">🟩 P1 FVG Order Blocks</option>
<option value="p2">🔥 P2 Impulse Heatmap</option>
<option value="p3">🤖 P3 ML Adaptive SuperTrend</option>
<option value="p4">🧠 P4 Lorentzian (ورودی‌های ML)</option>
<option value="p5">⚡ P5 Pro Scalper</option>
<option value="p6">📦 P6 Breakout Channels</option>
<option value="p7">🚀 P7 Swift Algo X</option>
<option value="pall">Σ ترکیب وزنی P1 تا P7 (اجرای همه)</option>
</select></label>
<label>ارز<input type="text" id="btSymbol" list="btSymbolList" autocomplete="off"><datalist id="btSymbolList"></datalist></label>
<label>تایم‌فریم<select id="btTimeframe">
<option value="5m">5m</option><option value="15m">15m</option><option value="30m">30m</option>
<option value="1h" selected>1h</option><option value="4h">4h</option><option value="1d">1d</option><option value="1m">1m</option>
</select></label>
<label>بازه گذشته<select id="btPeriod">
<option value="7">۱ هفته</option><option value="14">۲ هفته</option><option value="30">۱ ماه</option>
<option value="90" selected>۳ ماه</option><option value="180">۶ ماه</option><option value="365">۱ سال</option><option value="730">۲ سال</option><option value="1825">۵ سال</option>
</select></label>
<label>کارمزد هر طرف (٪)<input type="number" id="btFee" step="0.01" value="0.1"></label>
<label>حد ضرر ٪ (0 = خاموش)<input type="number" id="btSl" step="0.1" value="0"></label>
<label>حد سود ٪ (0 = خاموش)<input type="number" id="btTp" step="0.1" value="0"></label>
<label>افق هر معامله AI (کندل)<input type="number" id="btAiH" value="10"></label>
<label>خروج زمانی بعد از N کندل (0 = خاموش)<input type="number" id="btHold" step="1" min="0" value="0"></label>
<label class="chk"><input type="checkbox" id="btLongOnly"> فقط خرید (بدون Short)</label>
</div>
<button id="btRun" onclick="runIndicatorBacktest()">▶️ اجرای بک‌تست</button>
<button id="btScanPf" onclick="runPfTfScan()" style="margin-top:6px">🔬 مقایسه Pro F روی همه تایم‌فریم‌ها (5m تا 1d) - قدرتی در برابر قدیمی</button>
<button id="btOptPf" onclick="runPfTfOptimize()" style="margin-top:6px">🧬 بهینه‌ساز Walk-Forward: بهترین تنظیم هر تایم‌فریم + تست دیده‌نشده</button>
<button id="btCmpP" onclick="runLzCompareBacktest()" style="margin-top:6px">📊 بک‌تست و مقایسه‌ی هر ۷ اندیکاتور + ترکیب وزنی (همراه تست خارج از نمونه)</button>
<div id="btStatus"></div>
<div id="btResult"></div>
</div></div>
</div>
<div id="statusBar">در حال بارگذاری...</div>

<script>
// ==================== ۲۰۰ ارز آماده - مستقیماً از سمت سرور تزریق شده، بدون هیچ درخواست شبکه‌ای در بارگذاری اولیه ====================
const SYMBOLS_200 = __SYMBOLS_200_JSON__;

(function loadLib(urls){
    if(!urls.length){
        document.getElementById('statusBar').textContent='❌ کتابخانه نمودار از هیچ منبعی بارگذاری نشد - اتصال اینترنت را چک کن';
        return;
    }
    const s=document.createElement('script');
    s.src=urls[0];
    s.onerror=function(){ s.remove(); loadLib(urls.slice(1)); };
    document.head.appendChild(s);
})([
    'https://cdn.jsdelivr.net/npm/lightweight-charts@4.1.3/dist/lightweight-charts.standalone.production.js',
    'https://cdnjs.cloudflare.com/ajax/libs/lightweight-charts/4.1.3/lightweight-charts.standalone.production.min.js',
    'https://unpkg.com/lightweight-charts@4.1.3/dist/lightweight-charts.standalone.production.js'
]);

let chart=null, candleSeries=null, ribbonSeries=[], ribbonPriceLines=[];
let currentSymbol='BTCUSDT', currentTimeframe='1h';
let indicatorEnabled=false;
let currentCandles=[];
let isDrawing=false;
let ribbonResult=null;
let allSymbolsList=[];
let filteredSymbols=[];

// ==================== وضعیت و تنظیمات اندیکاتور Multi-Layer Confirmation ====================
let multiLayerEnabled=false;
let multiLayerResult=null;
let multiLayerPriceLines=[];
let multiLayerSettings={
    atrLen:14, volMult:1.0,
    rsiLen:14, rsiMid:50,
    emaFast:9, emaSlow:21,
    bodyPct:40,
    atrStopMult:1.5, atrTargetStep:1, targetCount:4,
    autoRR:true, minRR:1.5, maxRR:3
};

// ==================== وضعیت اندیکاتور Zones/Zigzag (بر اساس تصویر ارسالی کاربر) ====================
let zonesEnabled=false;
let zonesResult=null;
let zonesLineSeriesList=[];
let zonesZigzagSeries=null;
let zonesPriceLines=[];
let zonesSettings={slowLen:200, fastLen:50, pivotLeft:5, pivotRight:5, zoneCount:6};

// ==================== وضعیت خط فیلتر تایید سیگنال (تایید ورود Multi-Layer) ====================
let signalFilterEnabled=false;
let signalFilterLineSeries=null;
let signalFilterFastLineSeries=null;
let signalFilterData=null;
// len: طول EMA کند (خط اصلی روند) | fastLen: طول EMA تند (تاییدیه دوم) | slopeLookback: چند کندل قبل برای سنجش شیب
// atrLen/bufferMult: منطقه خنثی حول خط بر اساس ATR، تا نوسانات کوچک نزدیک خط باعث تشخیص اشتباه نشوند
// strongScore/weakScore: آستانه امتیاز برای تایید قوی/ضعیف | showLines: نمایش خطوط EMA روی چارت
let signalFilterSettings={len:100, fastLen:34, slopeLookback:14, atrLen:14, bufferMult:0.25, strongScore:2, weakScore:1, showLines:true};

// ==================== وضعیت اندیکاتور ساختار بازار (Market Structure: HH/HL/LH/LL) ====================
let structureEnabled=false;
let structureResult=null;
let structureLineSeries=null;
let structureBoxSeries=[];

// ==================== وضعیت اندیکاتور Fan Projection (بر اساس تصاویر ارسالی کاربر: مثلث‌های سفید روی پیوت‌های سوئینگ +
// خطوط بادبزنی سفید کشیده‌شده از آخرین سوئینگ اصلی به سوئینگ‌های بعدی + نقاط/خط نقطه‌چین پیش‌بینی رگرسیونی جلوی آخرین کندل) ====================
let fanEnabled=false;
let fanResult=null;
let fanLineSeriesList=[];
let fanProjectionSeries=null;
let fanSettings={pivotLeft:5, pivotRight:5, fanRays:4, regressionLen:20, projectionBars:10};

// ==================== وضعیت اندیکاتور AI Price Path (بر اساس تصاویر دوم ارسالی کاربر: زیگزاگ هارمونیک آبی X-A-B-C-D +
// مسیر موج‌دار زرد پیش‌بینی آینده قیمت + خطوط افقی سبز اهداف فیبوناچی با برچسب درصد (مثل 180%، 600%) + باکس سفارش خرید/فروش
// با TP1/TP2/TP3 و SL، دقیقاً مشابه پنل «Crypto User» گوشه پایین‌راست تصویر) ====================
let aiPathEnabled=false;
let aiPathResult=null;
let aiPathZigzagSeriesList=[];
let aiPathForecastSeries=null;
let aiPathPriceLines=[];
let aiPathSettings={backtestHorizon:10, backtestMaxTests:80, analogK:7, pivotLeft:5, pivotRight:5, projectionBars:40, volMult:1.0, atrStopMult:1.5, fibLevels:[127.2,161.8,200,261.8,423.6,600]};

// ==================== وضعیت هشدار صوتی سیگنال جدید Multi-Layer ====================
let alertAudioCtx=null;
let alertAudioTimer=null;
let alertLastSignalKey=(function(){try{return JSON.parse(localStorage.getItem('mlAlertLastSignal')||'{}');}catch(e){return {};}})();

// ==================== تنظیمات کامل اندیکاتور Alpha Algo Trading ====================
let alphaSettings={
    emaLens:[8,13,21,34,55,89],
    ema50200:false,
    rsiLen:14,rsiOB:70,rsiOS:30,
    macdFast:12,macdSlow:26,macdSignal:9,
    atrLen:14,atrStopMult:1.5,atrTargetStep:1,targetCount:4,
    autoRR:true,minRR:1.5,maxRR:3,
    confirmClose:true,confirmBars:2,
    exitMaster:true,exitRSI:true,exitMACD:true,exitEMA:true,exitStruct:true,
    showDash:true,dashMode:'detailed',showMTF:true,candleColor:false,showCross:true,dashPos:'left',colorMode:'A'
};
let dashCollapsed=false;

function toggleDashboardCollapse(){
    dashCollapsed=!dashCollapsed;
    const dash=document.getElementById('dashboard');
    const btn=document.getElementById('dashCollapseBtn');
    if(dashCollapsed){dash.classList.add('collapsed');btn.textContent='▼';}
    else{dash.classList.remove('collapsed');btn.textContent='▲';}
}

const MTF_LIST=[{key:'1h',label:'1H'},{key:'4h',label:'4H'},{key:'1d',label:'1D'},{key:'1w',label:'1W'},{key:'1M',label:'1M'}];
let mtfCache={};

function toggleSettings(){
    const p=document.getElementById('settingsPanel');
    const b=document.getElementById('btnSettings');
    p.classList.toggle('open');
    b.classList.toggle('active');
}

// ==================== منوی کشویی اندیکاتورها (همه دکمه‌های اندیکاتور داخل یک منو) ====================
function toggleIndicatorMenu(){
    document.getElementById('indicatorMenu').classList.toggle('open');
    document.getElementById('btnIndicatorMenu').classList.toggle('active');
}
document.addEventListener('click', function(e){
    const menu=document.getElementById('indicatorMenu');
    const trigger=document.getElementById('btnIndicatorMenu');
    if(!menu||!trigger)return;
    if(menu.classList.contains('open') && !menu.contains(e.target) && e.target!==trigger){
        menu.classList.remove('open');
        trigger.classList.remove('active');
    }
});

function setColorMode(mode){
    alphaSettings.colorMode=mode;
    const selEl=document.getElementById('setColorMode');
    if(selEl)selEl.value=mode;
    document.getElementById('btnModeA').classList.toggle('active',mode==='A');
    document.getElementById('btnModeB').classList.toggle('active',mode==='B');
    if(indicatorEnabled&&currentCandles.length>0){
        const rb=drawRibbon(currentCandles);
        updateStatus(rb);
    }
}

function readSettingsFromUI(){
    alphaSettings.emaLens=[1,2,3,4,5,6].map(i=>parseInt(document.getElementById('setEma'+i).value)||alphaSettings.emaLens[i-1]);
    alphaSettings.ema50200=document.getElementById('setEma50200').checked;
    alphaSettings.rsiLen=parseInt(document.getElementById('setRsiLen').value)||14;
    alphaSettings.rsiOB=parseFloat(document.getElementById('setRsiOB').value)||70;
    alphaSettings.rsiOS=parseFloat(document.getElementById('setRsiOS').value)||30;
    alphaSettings.macdFast=parseInt(document.getElementById('setMacdFast').value)||12;
    alphaSettings.macdSlow=parseInt(document.getElementById('setMacdSlow').value)||26;
    alphaSettings.macdSignal=parseInt(document.getElementById('setMacdSig').value)||9;
    alphaSettings.atrLen=parseInt(document.getElementById('setAtrLen').value)||14;
    alphaSettings.atrStopMult=parseFloat(document.getElementById('setAtrStopMult').value)||1.5;
    alphaSettings.atrTargetStep=parseFloat(document.getElementById('setAtrTargetStep').value)||1;
    alphaSettings.targetCount=parseInt(document.getElementById('setTargetCount').value)||4;
    alphaSettings.autoRR=document.getElementById('setAutoRR').checked;
    alphaSettings.minRR=parseFloat(document.getElementById('setMinRR').value)||1.5;
    alphaSettings.maxRR=parseFloat(document.getElementById('setMaxRR').value)||3;
    alphaSettings.confirmClose=document.getElementById('setConfirmClose').checked;
    alphaSettings.confirmBars=parseInt(document.getElementById('setConfirmBars').value)||2;
    alphaSettings.exitMaster=document.getElementById('setExitMaster').checked;
    alphaSettings.exitRSI=document.getElementById('setExitRSI').checked;
    alphaSettings.exitMACD=document.getElementById('setExitMACD').checked;
    alphaSettings.exitEMA=document.getElementById('setExitEMA').checked;
    alphaSettings.exitStruct=document.getElementById('setExitStruct').checked;
    alphaSettings.showDash=document.getElementById('setShowDash').checked;
    alphaSettings.colorMode=document.getElementById('setColorMode').value;
    document.getElementById('btnModeA').classList.toggle('active',alphaSettings.colorMode==='A');
    document.getElementById('btnModeB').classList.toggle('active',alphaSettings.colorMode==='B');
    alphaSettings.dashMode=document.getElementById('setDashMode').value;
    alphaSettings.showMTF=document.getElementById('setShowMTF').checked;
    alphaSettings.dashPos=document.getElementById('setDashPos').value;
    alphaSettings.candleColor=document.getElementById('setCandleColor').checked;
    alphaSettings.showCross=document.getElementById('setShowCross').checked;

    multiLayerSettings.atrLen=parseInt(document.getElementById('setMlAtrLen').value)||14;
    multiLayerSettings.volMult=parseFloat(document.getElementById('setMlVolMult').value)||1.0;
    multiLayerSettings.rsiLen=parseInt(document.getElementById('setMlRsiLen').value)||14;
    multiLayerSettings.rsiMid=parseFloat(document.getElementById('setMlRsiMid').value)||50;
    multiLayerSettings.emaFast=parseInt(document.getElementById('setMlEmaFast').value)||9;
    multiLayerSettings.emaSlow=parseInt(document.getElementById('setMlEmaSlow').value)||21;
    multiLayerSettings.bodyPct=parseFloat(document.getElementById('setMlBodyPct').value)||40;
    multiLayerSettings.atrStopMult=parseFloat(document.getElementById('setMlAtrStopMult').value)||1.5;
    multiLayerSettings.atrTargetStep=parseFloat(document.getElementById('setMlAtrTargetStep').value)||1;
    multiLayerSettings.targetCount=parseInt(document.getElementById('setMlTargetCount').value)||3;
    multiLayerSettings.autoRR=document.getElementById('setMlAutoRR').checked;
    multiLayerSettings.minRR=parseFloat(document.getElementById('setMlMinRR').value)||1.5;
    multiLayerSettings.maxRR=parseFloat(document.getElementById('setMlMaxRR').value)||3;

    // Signal Filter settings
    signalFilterSettings.len=parseInt(document.getElementById('setSfLen').value)||100;
    signalFilterSettings.fastLen=parseInt(document.getElementById('setSfFastLen').value)||34;
    signalFilterSettings.slopeLookback=parseInt(document.getElementById('setSfSlopeLookback').value)||14;
    signalFilterSettings.atrLen=parseInt(document.getElementById('setSfAtrLen').value)||14;
    signalFilterSettings.bufferMult=parseFloat(document.getElementById('setSfBufferMult').value)||0.25;
    signalFilterSettings.strongScore=parseInt(document.getElementById('setSfStrongScore').value)||2;
    signalFilterSettings.weakScore=parseInt(document.getElementById('setSfWeakScore').value)||1;
    signalFilterSettings.showLines=document.getElementById('setSfShowLines').checked;

    // Fan Projection settings
    fanSettings.pivotLeft=parseInt(document.getElementById('setFpPivotLeft').value)||5;
    fanSettings.pivotRight=parseInt(document.getElementById('setFpPivotRight').value)||5;
    fanSettings.fanRays=parseInt(document.getElementById('setFpFanRays').value)||4;
    fanSettings.regressionLen=parseInt(document.getElementById('setFpRegLen').value)||20;
    fanSettings.projectionBars=parseInt(document.getElementById('setFpProjBars').value)||10;

    // AI Price Path settings
    aiPathSettings.pivotLeft=parseInt(document.getElementById('setAiPivotLeft').value)||5;
    aiPathSettings.pivotRight=parseInt(document.getElementById('setAiPivotRight').value)||5;
    aiPathSettings.projectionBars=parseInt(document.getElementById('setAiProjBars').value)||40;
    aiPathSettings.backtestHorizon=parseInt(document.getElementById('setAiBtHorizon').value)||10;
    aiPathSettings.volMult=parseFloat(document.getElementById('setAiVolMult').value)||1.0;
    aiPathSettings.atrStopMult=parseFloat(document.getElementById('setAiAtrStopMult').value)||1.5;
    const fibRaw=(document.getElementById('setAiFibLevels').value||'').split(',').map(s=>parseFloat(s.trim())).filter(n=>!isNaN(n)&&n>0);
    aiPathSettings.fibLevels=fibRaw.length?fibRaw:[127.2,161.8,200,261.8,423.6,600];

    // Pro F settings
    pfReadSettingsFromUI();
}

function applySettings(){
    readSettingsFromUI();
    if(indicatorEnabled&&currentCandles.length>0){
        const rb=drawRibbon(currentCandles);
        updateStatus(rb);
        if(alphaSettings.showMTF)loadMTFPanel(); else updateDashboardPanel(rb);
    }else{
        updateDashboardPanel(null);
    }
    if(multiLayerEnabled&&currentCandles.length>0){
        drawMultiLayer(currentCandles);
    }
    if(signalFilterEnabled&&currentCandles.length>0){
        drawSignalFilter(currentCandles);
    }
    if(fanEnabled&&currentCandles.length>0){
        drawFanProjection(currentCandles);
    }
    if(aiPathEnabled&&currentCandles.length>0){
        drawAiPricePath(currentCandles);
    }
    if(pfEnabled&&currentCandles.length>0){
        drawProF(currentCandles);
    }
}

async function loadMTFPanel(){
    if(!alphaSettings.showMTF||!indicatorEnabled)return;
    for(const tf of MTF_LIST){
        try{
            const res=await fetch(`/api/candles?symbol=${currentSymbol}&timeframe=${tf.key}&limit=120`);
            const data=await res.json();
            if(data.success&&data.data&&data.data.length>60){
                const fast=calcEMA(data.data,20),slow=calcEMA(data.data,50);
                const fV=fast.length?fast[fast.length-1].value:null;
                const sV=slow.length?slow[slow.length-1].value:null;
                mtfCache[tf.key]=(fV!==null&&sV!==null)?(fV>sV?'up':'down'):'na';
            }else{
                mtfCache[tf.key]='na';
            }
        }catch(e){mtfCache[tf.key]='na';}
    }
    updateDashboardPanel();
}

function updateDashboardPanel(rb){
    const dash=document.getElementById('dashboard');
    const body=document.getElementById('dashboardBody');
    if(!dash||!body)return;
    if(!alphaSettings.showDash||!indicatorEnabled){dash.classList.remove('show');return;}
    if(!rb){try{rb=calcAlphaRibbon(currentCandles,alphaSettings);}catch(e){dash.classList.remove('show');return;}}
    if(!currentCandles.length){dash.classList.remove('show');return;}
    dash.classList.add('show');
    dash.classList.toggle('pos-right', alphaSettings.dashPos==='right');
    const stateFa=rb.finalState==='up'?'صعودی 🟢':(rb.finalState==='down'?'نزولی 🔴':'گذار ⚪');
    const tradeFa=rb.activePosition?(rb.activePosition.dir==='long'?'خرید باز':'فروش باز'):'بدون پوزیشن';
    let distToStop='-';
    if(rb.activePosition&&rb.activePosition.stop&&currentCandles.length){
        const lastClose=currentCandles[currentCandles.length-1].close;
        distToStop=(Math.abs(lastClose-rb.activePosition.stop)/lastClose*100).toFixed(2)+'%';
    }
    const atrPct=(rb.atrPercent!==null&&rb.atrPercent!==undefined)?rb.atrPercent.toFixed(2)+'%':'-';
    const lastSig=rb.lastSignal?(rb.lastSignal.type+' @ '+Number(rb.lastSignal.price).toFixed(4)):'-';

    let html='';
    html+='<div class="dRow"><span>سیگنال آخر</span><b>'+lastSig+'</b></div>';
    html+='<div class="dRow"><span>وضعیت روبان</span><b>'+stateFa+'</b></div>';
    if(alphaSettings.dashMode==='detailed'){
        html+='<div class="dRow"><span>حالت پوزیشن</span><b>'+tradeFa+'</b></div>';
        html+='<div class="dRow"><span>فاصله تا استاپ</span><b>'+distToStop+'</b></div>';
        html+='<div class="dRow"><span>نوسان ATR%</span><b>'+atrPct+'</b></div>';
    }
    if(alphaSettings.showMTF){
        html+='<div style="margin-top:6px;font-size:10px;color:#ff9800;">چندتایم‌فریم:</div>';
        MTF_LIST.forEach(tf=>{
            const st=mtfCache[tf.key]||'na';
            const col=st==='up'?'#00c853':(st==='down'?'#ff1744':'#667788');
            const stFa=st==='up'?'صعودی':(st==='down'?'نزولی':'—');
            html+='<div class="mtfRow"><span>'+tf.label+'</span><span><span class="mtfDot" style="background:'+col+';"></span>'+stFa+'</span></div>';
        });
    }
    body.innerHTML=html;
}

// ==================== مدیریت لیست ارزها ====================
function fillSymbolSelect(list, sourceLabel){
    const info=document.getElementById('symbolInfo');
    const sel=document.getElementById('symbolSelect');
    allSymbolsList=list;
    sel.innerHTML='';
    allSymbolsList.forEach(s=>{
        const o=document.createElement('option');
        o.value=s;o.textContent=s;
        sel.appendChild(o);
    });
    if(allSymbolsList.indexOf(currentSymbol)===-1){
        currentSymbol=allSymbolsList[0];
    }
    sel.value=currentSymbol;
    info.textContent=`✅ ${allSymbolsList.length} ارز آماده (${sourceLabel}) | ارز فعلی: ${currentSymbol}`;
}

async function loadSymbols(forceRefresh){
    const info=document.getElementById('symbolInfo');
    // حالت پیش‌فرض: استفاده مستقیم از ۲۰۰ ارز آماده داخل کد - بدون هیچ درخواست شبکه‌ای
    if(!forceRefresh){
        fillSymbolSelect(SYMBOLS_200, 'لیست آماده داخل کد');
        console.log('لیست ارزها از لیست آماده داخل کد بارگذاری شد:',SYMBOLS_200.length,'ارز');
        return;
    }
    // فقط با فشردن دکمه 🔄 بروزرسانی، لیست زنده از Worker/صرافی‌ها گرفته می‌شود
    info.textContent='🔄 در حال دریافت لیست بروز ارزها از Cloudflare Worker...';
    try{
        const res=await fetch('/api/symbols?refresh=1');
        const data=await res.json();
        if(data.success&&data.symbols&&data.symbols.length>0){
            fillSymbolSelect(data.symbols, 'بروزرسانی زنده');
            console.log('لیست ارزها بروزرسانی شد:',data.count,'ارز');
        }else{
            info.textContent='⚠️ دریافت لیست ارزها ناموفق - استفاده از لیست آماده داخل کد';
            fillSymbolSelect(SYMBOLS_200, 'لیست آماده داخل کد');
        }
    }catch(e){
        info.textContent='❌ خطا در بروزرسانی: '+e.message+' - استفاده از لیست آماده داخل کد';
        fillSymbolSelect(SYMBOLS_200, 'لیست آماده داخل کد');
    }
}

// ==================== جستجوی ارز ====================
function setupSymbolSearch(){
    const searchInput=document.getElementById('symbolSearch');
    const dropdown=document.getElementById('symbolDropdown');
    const sel=document.getElementById('symbolSelect');

    searchInput.addEventListener('input',function(){
        const q=this.value.trim().toUpperCase();
        if(!q){dropdown.classList.remove('show');return;}
        filteredSymbols=allSymbolsList.filter(s=>s.indexOf(q)!==-1).slice(0,100);
        if(filteredSymbols.length===0){
            dropdown.innerHTML='<div class="symItem" style="color:#ff1744;">❌ ارزی یافت نشد</div>';
            dropdown.classList.add('show');
            return;
        }
        dropdown.innerHTML=filteredSymbols.map(s=>`<div class="symItem${s===currentSymbol?' active':''}" data-sym="${s}">${s}</div>`).join('');
        dropdown.classList.add('show');
    });

    searchInput.addEventListener('keydown',function(e){
        if(e.key==='Enter'&&filteredSymbols.length>0){
            selectSymbol(filteredSymbols[0]);
            this.value='';
            dropdown.classList.remove('show');
        }
    });

    dropdown.addEventListener('click',function(e){
        const item=e.target.closest('.symItem');
        if(item&&item.dataset.sym){
            selectSymbol(item.dataset.sym);
            searchInput.value='';
            dropdown.classList.remove('show');
        }
    });

    document.addEventListener('click',function(e){
        if(!e.target.closest('.symbolSearch')){
            dropdown.classList.remove('show');
        }
    });
}

function selectSymbol(sym){
    if(!sym)return;
    currentSymbol=sym;
    document.getElementById('symbolSelect').value=sym;
    document.getElementById('symbolInfo').textContent=`✅ ارز انتخابی: ${sym}`;
    loadChart();
}

const symSel=document.getElementById('symbolSelect');
sessionRestore();

function initChart(){
    if(typeof LightweightCharts==='undefined'){
        document.getElementById('statusBar').textContent='❌ کتابخانه نمودار (LightweightCharts) بارگذاری نشد - اتصال اینترنت را چک کن و صفحه را رفرش کن';
        return false;
    }
    const c=document.getElementById('chartDiv');
    chart=LightweightCharts.createChart(c,{
        layout:{background:{color:'#050810'},textColor:'#667788'},
        grid:{vertLines:{color:'rgba(26,42,58,0.2)'},horzLines:{color:'rgba(26,42,58,0.2)'}},
        crosshair:{mode:LightweightCharts.CrosshairMode.Normal},
        rightPriceScale:{borderColor:'#1a2a3a'},
        timeScale:{borderColor:'#1a2a3a',timeVisible:true}
    });
    candleSeries=chart.addCandlestickSeries({upColor:'#00c853',downColor:'#ff1744'});
    return true;
}

function removeAllRibbonSeries(){
    for(const s of ribbonSeries){
        if(s){try{chart.removeSeries(s)}catch(e){}}
    }
    ribbonSeries=[];
    for(const pl of ribbonPriceLines){
        if(pl){try{candleSeries.removePriceLine(pl)}catch(e){}}
    }
    ribbonPriceLines=[];
}

function calcEMA(d,p){const r=[];if(!d||d.length===0)return r;if(d[0]&&d[0].close!==undefined){r.push({time:d[0].time,value:d[0].close});}else{return r;}const k=2/(p+1);for(let i=1;i<d.length;i++){if(d[i]&&d[i].close!==undefined){r.push({time:d[i].time,value:(d[i].close-r[i-1].value)*k+r[i-1].value});}}return r;}

function calcATR(d,p){const r=[];if(!d||d.length<2)return r;const tr=[];for(let i=0;i<d.length;i++){if(i===0){if(d[i]&&d[i].high!==undefined&&d[i].low!==undefined){tr.push(d[i].high-d[i].low);}else{tr.push(0);}continue;}if(d[i]&&d[i-1]&&d[i].high!==undefined&&d[i].low!==undefined&&d[i-1].close!==undefined){tr.push(Math.max(d[i].high-d[i].low,Math.abs(d[i].high-d[i-1].close),Math.abs(d[i].low-d[i-1].close)));}else{tr.push(0);}}if(tr.length<p)return r;let s=0;for(let i=0;i<p;i++)s+=tr[i];r.push({time:d[p-1].time,value:s/p});for(let i=p;i<tr.length;i++){const prevVal=r[r.length-1].value;r.push({time:d[i].time,value:(prevVal*(p-1)+tr[i])/p});}return r;}

function calcRSI(d,p){const r=[];if(!d||d.length<p+1)return r;let g=0,l=0;for(let i=1;i<=p;i++){if(d[i]&&d[i-1]&&d[i].close!==undefined&&d[i-1].close!==undefined){const ch=d[i].close-d[i-1].close;if(ch>0)g+=ch;else l+=Math.abs(ch);}}let ag=g/p,al=l/p;for(let i=p;i<d.length;i++){if(d[i]&&d[i-1]&&d[i].close!==undefined&&d[i-1].close!==undefined){if(i===p){const rs=ag/(al||0.001);r.push({time:d[i].time,value:100-(100/(1+rs))});}else{const ch=d[i].close-d[i-1].close;const ga=ch>0?ch:0;const lo=ch<0?Math.abs(ch):0;ag=(ag*(p-1)+ga)/p;al=(al*(p-1)+lo)/p;const rs=ag/(al||0.001);r.push({time:d[i].time,value:100-(100/(1+rs))});}}}return r;}

function calcMACD(d,f,s,g){const ef=calcEMA(d,f),es=calcEMA(d,s);const ml=[];for(let i=0;i<Math.min(ef.length,es.length);i++){ml.push({time:ef[i].time,value:ef[i].value-es[i].value});}const sl=calcEMA(ml,g);return{macd:ml,signal:sl};}

// امتیاز ۰ تا ۱ از قدرت روند (فاصله EMA سریع/کند نسبت به ATR)، قدرت مومنتوم (فاصله RSI از خط میانی)
// و شدت انبساط نوسان (رنج کندل نسبت به ATR)
function calcMarketScore(emaFastV, emaSlowV, atrV, rsiV, candleRange){
    if(!atrV || atrV<=0) return 0;
    const trendScore = Math.min(1, Math.abs(emaFastV-emaSlowV)/atrV/2);
    const momentumScore = (rsiV!==undefined) ? Math.min(1, Math.abs(rsiV-50)/50) : 0;
    const volScore = (candleRange!==undefined) ? Math.min(1, Math.max(0,(candleRange/atrV)-1)) : 0;
    return Math.max(0, Math.min(1, trendScore*0.5 + momentumScore*0.3 + volScore*0.2));
}

// نسبت ریسک به ریوارد خودکار: امتیاز بازار را بین حداقل و حداکثر R:R ایمن (تنظیم‌شده توسط کاربر) نگاشت می‌کند.
function calcDynamicRR(emaFastV, emaSlowV, atrV, rsiV, candleRange, minRR, maxRR){
    minRR = (minRR===undefined||isNaN(minRR)) ? 1.5 : minRR;
    maxRR = (maxRR===undefined||isNaN(maxRR)) ? 3 : maxRR;
    if(maxRR<minRR){const tmp=minRR;minRR=maxRR;maxRR=tmp;}
    if(!atrV || atrV<=0) return minRR;
    const score = calcMarketScore(emaFastV, emaSlowV, atrV, rsiV, candleRange);
    return minRR + score*(maxRR-minRR);
}

// ظرفیت پیشروی: امتیاز بازار منهای جریمه‌ی «کشیدگی قیمت» (فاصله قیمت فعلی از EMA کند نسبت به ATR).
// هرچه قیمت از قبل بیشتر دویده باشد، احتمال رسیدن به تارگت‌های دورتر کمتر در نظر گرفته می‌شود.
function calcTargetCapacityScore(emaFastV, emaSlowV, atrV, rsiV, candleRange, closePrice){
    const score = calcMarketScore(emaFastV, emaSlowV, atrV, rsiV, candleRange);
    if(!atrV || atrV<=0) return score;
    const overext = Math.abs(closePrice-emaSlowV)/atrV;
    const penalty = Math.min(0.5, Math.max(0,(overext-3)/10));
    return Math.max(0, score-penalty);
}

// تارگت‌های پلکانی را با یک "گام ثابت" می‌سازد (بر اساس R:R یا حالت دستی) تا بشه بعداً
// بدون تغییر دادن تارگت‌های قبلی، تارگت‌های بیشتری در همون فاصله اضافه کرد.
// achievable بر اساس امتیاز ظرفیت و فاصله‌ی پلکانی هر سطح از سطح پایه مشخص می‌شود.
function buildTargetsWithCapacity(basePrice, unitDist, dir, count, capacityScore, baseCount){
    const arr=[];
    const thresholdStep = 1/(baseCount||count||1);
    for(let i=1;i<=count;i++){
        const price = dir==='long' ? basePrice+i*unitDist : basePrice-i*unitDist;
        const threshold = Math.min(0.9,(i-1)*thresholdStep);
        arr.push({price:price, achievable: capacityScore>=threshold});
    }
    return arr;
}

// وقتی قیمت از آخرین تارگت موجود عبور کرده و معامله هنوز باز است، تارگت بعدی را با
// "گام لحظه‌ای" (بر اساس ATR و R:R همون کندل فعلی) اضافه می‌کند — نه گام ثابتِ لحظه‌ی ورود.
// این یعنی وقتی ارز پامپ/ریزش شدید می‌کند و نوسان (ATR) و قدرت روند بالا می‌رود،
// فاصله‌ی تارگت‌های جدید هم به همون نسبت بزرگ‌تر می‌شود تا بهترین نقاط سود پوشش داده بشن.
// تارگت‌های قبلی (که از قبل روی نمودار بودن) دست‌نخورده می‌مونن.
function extendTargetsIfNeeded(position, currentClose, stepDistNow, capacityScore, maxTargets){
    if(!position || !position.targets || !position.targets.length || !stepDistNow || stepDistNow<=0) return false;
    maxTargets = maxTargets || ((position.capBase||4)+8);
    const thresholdStep = 1/(position.capBase||4);
    let changed=false;
    while(position.targets.length < maxTargets){
        const last=position.targets[position.targets.length-1];
        const beyond = position.dir==='long' ? currentClose>last.price : currentClose<last.price;
        if(!beyond) break;
        const price = position.dir==='long' ? last.price+stepDistNow : last.price-stepDistNow;
        const i=position.targets.length+1;
        const threshold=Math.min(0.9,(i-1)*thresholdStep);
        position.targets.push({price:price, achievable: capacityScore>=threshold});
        changed=true;
    }
    return changed;
}

// دقت نمایش قیمت را متناسب با محدوده قیمتی نماد (به‌خصوص ارزهای زیر ۱ دلار) تنظیم می‌کند.
function applyDynamicPricePrecision(candles){
    if(!candleSeries || !candles || !candles.length) return;
    const sample=candles.slice(-20).map(c=>c.close).filter(v=>v>0).sort((a,b)=>a-b);
    if(!sample.length) return;
    const price=sample[Math.floor(sample.length/2)];
    let precision,minMove;
    if(price>=1000){precision=2;minMove=0.01;}
    else if(price>=1){precision=4;minMove=0.0001;}
    else if(price>=0.1){precision=5;minMove=0.00001;}
    else if(price>=0.01){precision=6;minMove=0.000001;}
    else if(price>=0.001){precision=7;minMove=0.0000001;}
    else if(price>=0.0001){precision=8;minMove=0.00000001;}
    else{precision=10;minMove=0.0000000001;}
    try{candleSeries.applyOptions({priceFormat:{type:'price',precision:precision,minMove:minMove}});}
    catch(e){console.error('خطا در تنظیم دقت قیمت:',e);}
}

// ==================== اندیکاتور Multi-Layer Confirmation ====================
// چهار لایه مستقل که هر کدام باید هم‌جهت باشند تا سیگنال صادر شود:
// لایه ۱: ساختار کندلی بازگشتی (engulfing) | لایه ۲: اعتبارسنجی نوسان/رنج (ATR)
// لایه ۳: تایید مومنتوم (RSI نسبت به خط میانی) | لایه ۴: فیلتر زمینه روند کوتاه‌مدت (کراس EMA)
// سیگنال فقط در بسته‌شدن کندل (bar close) و فقط در نقطه تغییر وضعیت صادر می‌شود (بدون تکرار).
function calcMultiLayer(d, settings){
    settings = settings || multiLayerSettings;
    const result={markers:[],barStates:[],finalState:'transition',lastSignal:null,activePosition:null,lastPosition:null,trades:[]};
    if(!d || d.length<Math.max(settings.atrLen,settings.rsiLen,settings.emaSlow)+5) return result;

    const atr=calcATR(d,settings.atrLen);
    const rsi=calcRSI(d,settings.rsiLen);
    const emaF=calcEMA(d,settings.emaFast);
    const emaS=calcEMA(d,settings.emaSlow);
    const atrMap={};atr.forEach(x=>atrMap[x.time]=x.value);
    const rsiMap={};rsi.forEach(x=>rsiMap[x.time]=x.value);
    const efMap={};emaF.forEach(x=>efMap[x.time]=x.value);
    const esMap={};emaS.forEach(x=>esMap[x.time]=x.value);
    const targetMults=[];for(let i=1;i<=(settings.targetCount||3);i++)targetMults.push(i*settings.atrTargetStep);

    let prevState='transition', position=null;
    for(let i=1;i<d.length;i++){
        const c=d[i], p=d[i-1];
        const t=c.time;
        const atrV=atrMap[t], rsiV=rsiMap[t], efV=efMap[t], esV=esMap[t];
        if(atrV===undefined||rsiV===undefined||efV===undefined||esV===undefined){
            result.barStates.push({time:t,state:'transition'});
            continue;
        }

        // لایه ۱: ساختار کندلی بازگشتی (bullish/bearish engulfing)
        const bullEngulf = c.close>c.open && p.close<p.open && c.close>=p.open && c.open<=p.close;
        const bearEngulf = c.close<c.open && p.close>p.open && c.close<=p.open && c.open>=p.close;

        // لایه ۲: اعتبارسنجی نوسان/رنج نسبت به ATR + حداقل نسبت بدنه به رنج کندل (کاهش نویز)
        const range=c.high-c.low;
        const body=Math.abs(c.close-c.open);
        const volOk = range >= (atrV*settings.volMult);
        const bodyOk = range>0 ? (body/range*100) >= settings.bodyPct : false;

        // لایه ۳: تایید مومنتوم نسبت به خط میانی RSI
        const momUp = rsiV >= settings.rsiMid;
        const momDown = rsiV <= (100-settings.rsiMid);

        // لایه ۴: فیلتر زمینه روند کوتاه‌مدت (EMA سریع نسبت به EMA کند)
        const trendUp = efV>esV;
        const trendDown = efV<esV;

        let newState='transition';
        if(bullEngulf && volOk && bodyOk && momUp && trendUp) newState='up';
        else if(bearEngulf && volOk && bodyOk && momDown && trendDown) newState='down';
        else newState=prevState==='transition' ? 'transition' : prevState;

        result.barStates.push({time:t,state:newState});

        if(newState!==prevState){
            if(position){
                result.markers.push({time:t,position:position.dir==='long'?'aboveBar':'belowBar',color:position.dir==='long'?'#00e5ff':'#aa00ff',shape:'circle',text:'ML-CLOSE'});
                result.trades.push({dir:position.dir,entry:position.entry,entryTime:position.entryTime,exit:c.close,exitTime:t,stop:position.stop,targets:position.targets});
                result.lastSignal={type:'ML-CLOSE',time:t,price:c.close,dir:position.dir};
                result.lastPosition=Object.assign({},position,{closed:true,exit:c.close,exitTime:t});
                position=null;
            }
            if(newState==='up'){
                result.markers.push({time:t,position:'belowBar',color:'#00e5ff',shape:'arrowUp',text:'ML-BUY'});
                result.lastSignal={type:'ML-BUY',time:t,price:c.close};
                const stopDist=atrV*settings.atrStopMult;
                const stopPrice=c.low-stopDist;
                const capScore=calcTargetCapacityScore(efV,esV,atrV,rsiV,range,c.close);
                const tCount=settings.targetCount||4;
                let unitDist;
                if(settings.autoRR){
                    const rr=calcDynamicRR(efV,esV,atrV,rsiV,range,settings.minRR,settings.maxRR);
                    unitDist=(rr*stopDist)/tCount;
                }else{
                    unitDist=settings.atrTargetStep*atrV;
                }
                const tgts=buildTargetsWithCapacity(c.close,unitDist,'long',tCount,capScore,tCount);
                position={dir:'long',entry:c.close,entryTime:t,stop:stopPrice,targets:tgts,unitDist:unitDist,capBase:tCount};
            }else if(newState==='down'){
                result.markers.push({time:t,position:'aboveBar',color:'#aa00ff',shape:'arrowDown',text:'ML-SELL'});
                result.lastSignal={type:'ML-SELL',time:t,price:c.close};
                const stopDist=atrV*settings.atrStopMult;
                const stopPrice=c.high+stopDist;
                const capScore=calcTargetCapacityScore(efV,esV,atrV,rsiV,range,c.close);
                const tCount=settings.targetCount||4;
                let unitDist;
                if(settings.autoRR){
                    const rr=calcDynamicRR(efV,esV,atrV,rsiV,range,settings.minRR,settings.maxRR);
                    unitDist=(rr*stopDist)/tCount;
                }else{
                    unitDist=settings.atrTargetStep*atrV;
                }
                const tgts=buildTargetsWithCapacity(c.close,unitDist,'short',tCount,capScore,tCount);
                position={dir:'short',entry:c.close,entryTime:t,stop:stopPrice,targets:tgts,unitDist:unitDist,capBase:tCount};
            }
        }
        if(position && position.targets && position.targets.length){
            const capScore=calcTargetCapacityScore(efV,esV,atrV,rsiV,range,c.close);
            const stopDistNow=atrV*settings.atrStopMult;
            let stepDistNow;
            if(settings.autoRR){
                const rrNow=calcDynamicRR(efV,esV,atrV,rsiV,range,settings.minRR,settings.maxRR);
                stepDistNow=(rrNow*stopDistNow)/(position.capBase||settings.targetCount||4);
            }else{
                stepDistNow=settings.atrTargetStep*atrV;
            }
            extendTargetsIfNeeded(position,c.close,stepDistNow,capScore);
        }
        prevState=newState;
    }
    result.finalState=prevState;
    result.activePosition=position;
    if(position){result.lastPosition=Object.assign({},position,{closed:false});}
    return result;
}

// جمع‌آوری مارکرهای همه اندیکاتورهای فعال و نمایش یکجا روی چارت
function updateAllMarkers(){
    if(!candleSeries)return;
    let markers=[];
    if(indicatorEnabled && ribbonResult){
        markers=markers.concat(ribbonResult.markers);
        if(alphaSettings.showCross && ribbonResult.crossMarkers && ribbonResult.crossMarkers.length>0){
            markers=markers.concat(ribbonResult.crossMarkers);
        }
    }
    if(multiLayerEnabled && multiLayerResult){
        markers=markers.concat(multiLayerResult.markers);
    }
    if(zonesEnabled && zonesResult){
        markers=markers.concat(zonesResult.markers);
    }
    if(structureEnabled && structureResult){
        markers=markers.concat(structureResult.markers);
    }
    if(fanEnabled && fanResult){
        markers=markers.concat(fanResult.markers);
    }
    if(aiPathEnabled && aiPathResult){
        markers=markers.concat(aiPathResult.markers);
    }
    if(pfEnabled && pfResult){
        markers=markers.concat(pfResult.markers);
    }
    if(mbEnabled && mbResult){
        markers=markers.concat(mbResult.markers);
    }
    if(fvgEnabled && fvgResult){
        markers=markers.concat(fvgResult.markers);
    }
    if(psEnabled && psResult){
        markers=markers.concat(psResult.markers);
    }
    if(sxEnabled && sxResult){
        markers=markers.concat(sxResult.markers);
    }
    if(lzAllEnabled && lzAllResult){
        markers=markers.concat(lzAllResult.markers);
    }
    markers.sort((a,b)=>a.time-b.time);
    try{candleSeries.setMarkers(markers);}catch(e){console.error('خطا در تنظیم مارکرها:',e);}
}

function removeMultiLayerPriceLines(){
    for(const pl of multiLayerPriceLines){
        if(pl){try{candleSeries.removePriceLine(pl)}catch(e){}}
    }
    multiLayerPriceLines=[];
}

function drawMultiLayer(d){
    if(!chart||!candleSeries){console.error('چارت آماده نیست');return null;}
    try{
        removeMultiLayerPriceLines();
        multiLayerResult=calcMultiLayer(d, multiLayerSettings);
        updateAllMarkers();

        const mlP = multiLayerResult.activePosition || multiLayerResult.lastPosition;
        if(mlP && mlP.stop){
            try{
                const tag = mlP.closed ? ' (بسته)' : '';
                multiLayerPriceLines.push(candleSeries.createPriceLine({price:mlP.stop,color:'#ff1744',lineWidth:2,lineStyle:3,title:'ML-SL'+tag}));
                (mlP.targets||[]).forEach((tp,idx)=>{
                    const achievable = tp.achievable!==false;
                    const price = (tp && typeof tp==='object') ? tp.price : tp;
                    const lineColor = achievable ? '#00e5ff' : '#556677';
                    const lineTitle = 'ML-TP'+(idx+1)+(achievable?tag:' ✗'+tag);
                    multiLayerPriceLines.push(candleSeries.createPriceLine({price:price,color:lineColor,lineWidth:1,lineStyle:achievable?3:1,title:lineTitle}));
                });
                console.log('خطوط SL/TP برای Multi-Layer رسم شدند. SL: '+mlP.stop+(mlP.closed?' (بسته)':' (باز)'));
            }catch(e){console.error('خطا در SL/TP مولتی‌لایر:',e);}
        }

        console.log('=== Multi-Layer: '+multiLayerResult.markers.length+' سیگنال یافت شد | وضعیت: '+multiLayerResult.finalState+' ===');
        return multiLayerResult;
    }catch(err){
        console.error('خطای کلی در drawMultiLayer:',err);
        return null;
    }
}

function toggleMultiLayer(){
    multiLayerEnabled=!multiLayerEnabled;
    const btn=document.getElementById('btnMultiLayer');
    if(multiLayerEnabled){
        btn.classList.add('active');
        btn.textContent='🧩 حذف اندیکاتور Multi-Layer';
        if(currentCandles.length>0){
            setTimeout(function(){
                drawMultiLayer(currentCandles);
                if(signalFilterEnabled)setTimeout(function(){ drawSignalFilter(currentCandles); },50);
                checkNewMultiLayerSignal();
            },50);
        }
    }else{
        btn.classList.remove('active');
        btn.textContent='🧩 اعمال اندیکاتور Multi-Layer';
        multiLayerResult=null;
        removeMultiLayerPriceLines();
        updateAllMarkers();
    }
}

// ==================== اندیکاتور Zones/Zigzag (میانگین کند/تند + زیگزاگ پیوت‌ها + مناطق حمایت/مقاومت رنگی) ====================
function calcZonesIndicator(d, settings){
    const s=settings||zonesSettings;
    const result={slow:[],fast:[],pivots:[],markers:[],zones:[]};
    if(!d||d.length<Math.max(s.slowLen,20)+5)return result;

    function sma(arr,len){
        const out=[];let sum=0;
        for(let i=0;i<arr.length;i++){
            sum+=arr[i].close;
            if(i>=len)sum-=arr[i-len].close;
            if(i>=len-1)out.push({time:arr[i].time,value:sum/len});
        }
        return out;
    }
    result.slow=sma(d,s.slowLen);
    result.fast=sma(d,s.fastLen);

    // تشخیص پیوت‌های سقف/کف محلی (Zigzag)
    const rawPivots=[];
    for(let i=s.pivotLeft;i<d.length-s.pivotRight;i++){
        let isHigh=true,isLow=true;
        for(let j=i-s.pivotLeft;j<=i+s.pivotRight;j++){
            if(j===i)continue;
            if(d[j].high>=d[i].high)isHigh=false;
            if(d[j].low<=d[i].low)isLow=false;
        }
        if(isHigh)rawPivots.push({time:d[i].time,price:d[i].high,type:'high'});
        else if(isLow)rawPivots.push({time:d[i].time,price:d[i].low,type:'low'});
    }
    // نگه‌داشتن فقط پیوت‌هایی که واقعاً جهت را عوض می‌کنند (زیگزاگ)
    const zz=[];
    for(const p of rawPivots){
        if(zz.length===0){zz.push(p);continue;}
        const last=zz[zz.length-1];
        if(last.type===p.type){
            if((p.type==='high'&&p.price>last.price)||(p.type==='low'&&p.price<last.price))zz[zz.length-1]=p;
        }else zz.push(p);
    }
    result.pivots=zz;
    zz.forEach(p=>{
        result.markers.push({
            time:p.time,
            position:p.type==='high'?'aboveBar':'belowBar',
            color:'#ffffff',
            shape:p.type==='high'?'arrowDown':'arrowUp',
            text:p.type==='high'?'ZZ-H':'ZZ-L'
        });
    });

    // خوشه‌بندی پیوت‌های اخیر برای رسم مناطق حمایت/مقاومت رنگی
    const lastPrice=d[d.length-1].close;
    const recentPrices=zz.slice(-16).map(p=>p.price);
    const threshold=lastPrice*0.003;
    const clusters=[];
    for(const price of recentPrices){
        const grp=clusters.find(g=>Math.abs(g.avg-price)<=threshold);
        if(grp){grp.prices.push(price);grp.avg=grp.prices.reduce((a,b)=>a+b,0)/grp.prices.length;}
        else clusters.push({avg:price,prices:[price]});
    }
    const zoneColors=['#ff1744','#ff9800','#9e9e9e','#00bcd4','#ffeb3b','#4caf50'];
    clusters.sort((a,b)=>Math.abs(a.avg-lastPrice)-Math.abs(b.avg-lastPrice));
    clusters.slice(0,s.zoneCount).forEach((z,idx)=>{
        result.zones.push({price:z.avg,color:zoneColors[idx%zoneColors.length]});
    });

    return result;
}

function removeZonesSeries(){
    zonesLineSeriesList.forEach(ser=>{try{chart.removeSeries(ser);}catch(e){}});
    zonesLineSeriesList=[];
    if(zonesZigzagSeries){try{chart.removeSeries(zonesZigzagSeries);}catch(e){}zonesZigzagSeries=null;}
    zonesPriceLines.forEach(pl=>{try{candleSeries.removePriceLine(pl);}catch(e){}});
    zonesPriceLines=[];
}

function drawZonesIndicator(d){
    if(!chart||!candleSeries){console.error('چارت آماده نیست');return null;}
    try{
        removeZonesSeries();
        zonesResult=calcZonesIndicator(d, zonesSettings);

        const slowSeries=chart.addLineSeries({color:'#ffeb3b',lineWidth:2,priceLineVisible:false,lastValueVisible:false,crosshairMarkerVisible:false});
        slowSeries.setData(zonesResult.slow);
        zonesLineSeriesList.push(slowSeries);

        const fastSeries=chart.addLineSeries({color:'#00bcd4',lineWidth:1,priceLineVisible:false,lastValueVisible:false,crosshairMarkerVisible:false});
        fastSeries.setData(zonesResult.fast);
        zonesLineSeriesList.push(fastSeries);

        zonesZigzagSeries=chart.addLineSeries({color:'#ffffff',lineWidth:1,priceLineVisible:false,lastValueVisible:false,crosshairMarkerVisible:false});
        zonesZigzagSeries.setData(zonesResult.pivots.map(p=>({time:p.time,value:p.price})));

        zonesResult.zones.forEach(z=>{
            zonesPriceLines.push(candleSeries.createPriceLine({price:z.price,color:z.color,lineWidth:1,lineStyle:2,title:'Zone '+z.price.toPrecision(5)}));
        });

        updateAllMarkers();
        console.log('=== Zones/Zigzag: '+zonesResult.pivots.length+' پیوت | '+zonesResult.zones.length+' ناحیه رسم شد ===');
        return zonesResult;
    }catch(err){
        console.error('خطای کلی در drawZonesIndicator:',err);
        return null;
    }
}

function toggleZonesIndicator(){
    zonesEnabled=!zonesEnabled;
    const btn=document.getElementById('btnZones');
    if(zonesEnabled){
        btn.classList.add('active');
        btn.textContent='📐 حذف اندیکاتور Zones/Zigzag';
        if(currentCandles.length>0){
            setTimeout(function(){ drawZonesIndicator(currentCandles); },50);
        }
    }else{
        btn.classList.remove('active');
        btn.textContent='📐 اعمال اندیکاتور Zones/Zigzag';
        zonesResult=null;
        removeZonesSeries();
        updateAllMarkers();
    }
}

// ==================== فیلتر تایید سیگنال Multi-Layer (نسخه چند-فاکتوره و قوی‌تر) ====================
// این فیلتر دیگر فقط بر اساس بالا/پایین بودن قیمت نسبت به یک خط تصمیم نمی‌گیرد؛ بلکه ۳ فاکتور را با هم می‌سنجد
// تا در حالت‌های مرزی (نزدیک خط) خطای کمتری داشته باشد:
//   ۱) موقعیت قیمت نسبت به EMA کند (روند بلندمدت) - با یک «منطقه خنثی» بر اساس ATR تا نوسان‌های کوچک را نادیده بگیرد
//   ۲) شیب EMA کند (آیا روند واقعاً در حال بالا/پایین رفتن است یا فقط لحظه‌ای رد شده)
//   ۳) موقعیت EMA تند نسبت به EMA کند (تاییدیه دوم، شبیه کراس‌آور)
// هرکدام از این ۳ فاکتور یک امتیاز ۱+ یا ۱- می‌دهد. جمع امتیازها بین ۳- تا ۳+ است:
//   امتیاز هم‌جهت با سیگنال >= strongScore  => ✅✅ تایید قوی
//   امتیاز هم‌جهت با سیگنال >= weakScore    => ✅ تایید ضعیف
//   امتیاز == ۰                            => ⚠️ نامشخص (فاکتورها هم‌جهت نیستند)
//   امتیاز مخالف سیگنال                    => ❌ رد می‌شود
function calcSignalFilterData(d, settings){
    const s=settings||signalFilterSettings;
    const slow=calcEMA(d, s.len);
    const fast=calcEMA(d, s.fastLen);
    const atr=calcATR(d, s.atrLen);
    const atrMap={};
    atr.forEach(p=>{atrMap[p.time]=p.value;});
    let lastAtr=0;
    const atrByIndex=d.map(c=>{ if(atrMap[c.time]!==undefined)lastAtr=atrMap[c.time]; return lastAtr; });
    const slopeByIndex=slow.map((p,i)=>{
        const j=i-s.slopeLookback;
        return j>=0 ? (p.value-slow[j].value) : 0;
    });
    return {slow,fast,atrByIndex,slopeByIndex};
}

function signalFilterScoreAtIndex(data, idx, price){
    if(!data||!data.slow[idx]||!data.fast[idx])return 0;
    const slowV=data.slow[idx].value;
    const fastV=data.fast[idx].value;
    const atrV=data.atrByIndex[idx]||0;
    const slope=data.slopeByIndex[idx]||0;
    const buffer=atrV*signalFilterSettings.bufferMult;
    let score=0;
    if(price>slowV+buffer)score+=1; else if(price<slowV-buffer)score-=1;
    if(slope>0)score+=1; else if(slope<0)score-=1;
    if(fastV>slowV)score+=1; else if(fastV<slowV)score-=1;
    return score;
}

function applySignalFilterToMultiLayer(d, data){
    if(!multiLayerResult || !multiLayerResult.markers || !data)return;
    const timeIndex={};
    d.forEach((c,i)=>{timeIndex[c.time]=i;});
    multiLayerResult.markers.forEach(m=>{
        const base=m.baseText||m.text;
        if(base!=='ML-BUY' && base!=='ML-SELL')return;
        m.baseText=base;
        m.baseColor=m.baseColor||m.color;
        const idx=timeIndex[m.time];
        if(idx===undefined)return;
        const price=d[idx].close;
        const score=signalFilterScoreAtIndex(data, idx, price);
        const wantPositive=(base==='ML-BUY');
        const dirScore=wantPositive?score:-score;
        const strongTh=signalFilterSettings.strongScore||2;
        const weakTh=signalFilterSettings.weakScore||1;
        let tag,color;
        if(dirScore>=strongTh){tag=' ✅✅';color=m.baseColor;}
        else if(dirScore>=weakTh){tag=' ✅';color=m.baseColor;}
        else if(dirScore===0){tag=' ⚠️';color='#8899aa';}
        else{tag=' ❌';color='#556677';}
        m.text=base+tag;
        m.color=color;
    });
}

function removeSignalFilterLine(){
    if(signalFilterLineSeries){try{chart.removeSeries(signalFilterLineSeries);}catch(e){}signalFilterLineSeries=null;}
    if(signalFilterFastLineSeries){try{chart.removeSeries(signalFilterFastLineSeries);}catch(e){}signalFilterFastLineSeries=null;}
}

function drawSignalFilter(d){
    if(!chart||!candleSeries)return null;
    try{
        removeSignalFilterLine();
        signalFilterData=calcSignalFilterData(d, signalFilterSettings);

        if(signalFilterSettings.showLines){
            signalFilterLineSeries=chart.addLineSeries({color:'#ffa726',lineWidth:2,priceLineVisible:false,lastValueVisible:true,title:'خط تایید سیگنال (EMA'+signalFilterSettings.len+')',crosshairMarkerVisible:false});
            signalFilterLineSeries.setData(signalFilterData.slow);

            signalFilterFastLineSeries=chart.addLineSeries({color:'rgba(255,255,255,0.55)',lineWidth:1,lineStyle:2,priceLineVisible:false,lastValueVisible:false,crosshairMarkerVisible:false});
            signalFilterFastLineSeries.setData(signalFilterData.fast);
        }

        if(multiLayerEnabled && multiLayerResult){
            applySignalFilterToMultiLayer(d, signalFilterData);
            updateAllMarkers();
        }
        return signalFilterData;
    }catch(err){
        console.error('خطا در drawSignalFilter:',err);
        return null;
    }
}

function toggleSignalFilter(){
    signalFilterEnabled=!signalFilterEnabled;
    const btn=document.getElementById('btnSignalFilter');
    if(signalFilterEnabled){
        btn.classList.add('active');
        btn.textContent='📏 حذف فیلتر تایید سیگنال';
        if(currentCandles.length>0){
            setTimeout(function(){ drawSignalFilter(currentCandles); },160);
        }
    }else{
        btn.classList.remove('active');
        btn.textContent='📏 اعمال فیلتر تایید سیگنال';
        removeSignalFilterLine();
        signalFilterData=null;
        // برچسب ✅/❌ را از مارکرهای Multi-Layer پاک کن و رنگ اصلی را برگردان
        if(multiLayerResult && multiLayerResult.markers){
            multiLayerResult.markers.forEach(m=>{
                if(m.baseText){ m.text=m.baseText; m.color=m.baseColor||(m.baseText==='ML-BUY'?'#00e5ff':'#aa00ff'); }
            });
            updateAllMarkers();
        }
    }
}

// ==================== اندیکاتور ساختار بازار (Market Structure: HH / HL / LH / LL) بر اساس تصویر ارسالی کاربر ====================
// این اندیکاتور: پیوت‌های سقف/کف را می‌یابد، هرکدام را نسبت به پیوت هم‌نوعِ قبلی برچسب می‌زند (HH/LH برای سقف، HL/LL برای کف)،
// آن‌ها را با خط زیگزاگ به هم وصل می‌کند، و در نقطه شکست ساختار (BOS) یک باکس رنگی روی محدوده شکست رسم می‌کند.
function calcMarketStructure(d, opts){
    opts=opts||{};
    const left=opts.pivotLeft||5, right=opts.pivotRight||5;
    const result={pivots:[],markers:[],zigzag:[],boxes:[]};
    if(!d||d.length<left+right+5)return result;

    const rawPivots=[];
    for(let i=left;i<d.length-right;i++){
        let isHigh=true,isLow=true;
        for(let j=i-left;j<=i+right;j++){
            if(j===i)continue;
            if(d[j].high>=d[i].high)isHigh=false;
            if(d[j].low<=d[i].low)isLow=false;
        }
        if(isHigh)rawPivots.push({time:d[i].time,price:d[i].high,type:'high',index:i});
        else if(isLow)rawPivots.push({time:d[i].time,price:d[i].low,type:'low',index:i});
    }
    // فقط پیوت‌هایی که جهت را عوض می‌کنند (زیگزاگ خام)
    const zz=[];
    for(const p of rawPivots){
        if(zz.length===0){zz.push(p);continue;}
        const last=zz[zz.length-1];
        if(last.type===p.type){
            if((p.type==='high'&&p.price>last.price)||(p.type==='low'&&p.price<last.price))zz[zz.length-1]=p;
        }else zz.push(p);
    }

    let lastHigh=null, lastLow=null;
    let lastBOSHigh=null, lastBOSLow=null;
    zz.forEach(p=>{
        let label;
        if(p.type==='high'){
            label=(lastHigh!==null && p.price>lastHigh)?'HH':(lastHigh!==null?'LH':'H');
            lastHigh=p.price;
        }else{
            label=(lastLow!==null && p.price>lastLow)?'HL':(lastLow!==null?'LL':'L');
            lastLow=p.price;
        }
        result.pivots.push({time:p.time,price:p.price,type:p.type,label:label,index:p.index});
        result.zigzag.push({time:p.time,value:p.price});
        result.markers.push({
            time:p.time,
            position:p.type==='high'?'aboveBar':'belowBar',
            color:'#2962ff',
            shape:'circle',
            text:label
        });
    });

    // شناسایی شکست ساختار (BOS): وقتی کندل بسته بالاتر از آخرین سقف مهم یا پایین‌تر از آخرین کف مهم بسته شود
    const highs=result.pivots.filter(p=>p.type==='high');
    const lows=result.pivots.filter(p=>p.type==='low');
    for(let i=1;i<highs.length;i++){
        const prev=highs[i-1], cur=highs[i];
        for(let k=prev.index+1;k<d.length;k++){
            if(d[k].close>prev.price){
                result.boxes.push({from:prev.time,to:d[k].time,top:Math.max(prev.price,d[k].close),bottom:Math.min(prev.price,d[k].close),type:'bull',label:'BOS'});
                break;
            }
            if(cur && d[k].time>=cur.time)break;
        }
    }
    for(let i=1;i<lows.length;i++){
        const prev=lows[i-1], cur=lows[i];
        for(let k=prev.index+1;k<d.length;k++){
            if(d[k].close<prev.price){
                result.boxes.push({from:prev.time,to:d[k].time,top:Math.max(prev.price,d[k].close),bottom:Math.min(prev.price,d[k].close),type:'bear',label:'BOS'});
                break;
            }
            if(cur && d[k].time>=cur.time)break;
        }
    }

    return result;
}

function removeMarketStructureSeries(){
    if(structureLineSeries){try{chart.removeSeries(structureLineSeries);}catch(e){}structureLineSeries=null;}
    structureBoxSeries.forEach(s=>{try{chart.removeSeries(s);}catch(e){}});
    structureBoxSeries=[];
}

function drawMarketStructure(d){
    if(!chart||!candleSeries)return null;
    try{
        removeMarketStructureSeries();
        structureResult=calcMarketStructure(d, {pivotLeft:5,pivotRight:5});

        structureLineSeries=chart.addLineSeries({color:'#ffffff',lineWidth:1,priceLineVisible:false,lastValueVisible:false,crosshairMarkerVisible:false});
        structureLineSeries.setData(structureResult.zigzag);

        // باکس‌های شکست ساختار (BOS) با رنگ صورتی/بنفش مشابه تصویر مرجع
        structureResult.boxes.forEach(box=>{
            const top=chart.addLineSeries({color:'rgba(233,30,99,0.85)',lineWidth:2,priceLineVisible:false,lastValueVisible:false,crosshairMarkerVisible:false});
            top.setData([{time:box.from,value:box.top},{time:box.to,value:box.top}]);
            structureBoxSeries.push(top);
            const bottom=chart.addLineSeries({color:'rgba(233,30,99,0.85)',lineWidth:2,priceLineVisible:false,lastValueVisible:false,crosshairMarkerVisible:false});
            bottom.setData([{time:box.from,value:box.bottom},{time:box.to,value:box.bottom}]);
            structureBoxSeries.push(bottom);
        });

        updateAllMarkers();
        console.log('=== ساختار بازار: '+structureResult.pivots.length+' پیوت | '+structureResult.boxes.length+' شکست ساختار (BOS) ===');
        return structureResult;
    }catch(err){
        console.error('خطای کلی در drawMarketStructure:',err);
        return null;
    }
}

function toggleMarketStructure(){
    structureEnabled=!structureEnabled;
    const btn=document.getElementById('btnStructure');
    if(structureEnabled){
        btn.classList.add('active');
        btn.textContent='🏗️ حذف اندیکاتور ساختار بازار';
        if(currentCandles.length>0){
            setTimeout(function(){ drawMarketStructure(currentCandles); },180);
        }
    }else{
        btn.classList.remove('active');
        btn.textContent='🏗️ اعمال اندیکاتور ساختار بازار';
        structureResult=null;
        removeMarketStructureSeries();
        updateAllMarkers();
    }
}

// ==================== اندیکاتور Fan Projection (بر اساس ۳ تصویر ارسالی کاربر) ====================
// این اندیکاتور سه بخش دارد که دقیقاً منطبق با چیزی است که در تصاویر کاربر دیده می‌شود:
//   ۱) مثلث‌های سفید روی نقاط سوئینگ (پیوت‌های سقف/کف) - همان مثلث‌های سفید بالا/پایین کندل‌ها در عکس‌ها
//   ۲) خطوط بادبزنی سفید که از مهم‌ترین سوئینگ (سقف/کف اصلی) به چند سوئینگ بعدی کشیده و تا آخرین کندل امتداد داده می‌شوند
//      - دقیقاً شبیه خطوط شعاعی سفیدی که در هر سه عکس از یک نقطه به بیرون پخش می‌شوند
//   ۳) خط نقطه‌چین رنگی پیش‌بینی (رگرسیون خطی روی N کندل آخر) که جلوی آخرین کندل امتداد پیدا می‌کند - شبیه نقاط آبی/قرمز
//      که در سمت راست نمودار در عکس‌ها دیده می‌شوند (آبی=پیش‌بینی صعودی، قرمز=پیش‌بینی نزولی)
function calcFanProjection(d, opts){
    opts=opts||fanSettings;
    const left=opts.pivotLeft||5, right=opts.pivotRight||5;
    const fanRays=opts.fanRays||4;
    const regLen=opts.regressionLen||20;
    const projBars=opts.projectionBars||10;
    const result={markers:[], fanLines:[], projection:[], projectionColor:'#2196f3'};
    if(!d||d.length<left+right+5)return result;

    // ---- ۱) یافتن پیوت‌های سقف/کف (همان تکنیک Market Structure) ----
    const rawPivots=[];
    for(let i=left;i<d.length-right;i++){
        let isHigh=true,isLow=true;
        for(let j=i-left;j<=i+right;j++){
            if(j===i)continue;
            if(d[j].high>=d[i].high)isHigh=false;
            if(d[j].low<=d[i].low)isLow=false;
        }
        if(isHigh)rawPivots.push({time:d[i].time,price:d[i].high,type:'high',index:i});
        else if(isLow)rawPivots.push({time:d[i].time,price:d[i].low,type:'low',index:i});
    }
    const zz=[];
    for(const p of rawPivots){
        if(zz.length===0){zz.push(p);continue;}
        const last=zz[zz.length-1];
        if(last.type===p.type){
            if((p.type==='high'&&p.price>last.price)||(p.type==='low'&&p.price<last.price))zz[zz.length-1]=p;
        }else zz.push(p);
    }

    // ---- مثلث‌های سفید روی هر سوئینگ ----
    zz.forEach(p=>{
        result.markers.push({
            time:p.time,
            position:p.type==='high'?'aboveBar':'belowBar',
            color:'#ffffff',
            shape:p.type==='high'?'arrowDown':'arrowUp',
            text:''
        });
    });

    // ---- ۲) خطوط بادبزنی: از مهم‌ترین سوئینگ (اکسترمم اولیه) به چند سوئینگ بعدی، امتداد تا آخرین کندل ----
    if(zz.length>=2){
        let origin=zz[0];
        for(const p of zz){
            if(p.type===origin.type){
                if((origin.type==='low'&&p.price<origin.price)||(origin.type==='high'&&p.price>origin.price))origin=p;
            }
        }
        const originIdx=zz.indexOf(origin);
        const targets=zz.slice(originIdx+1, originIdx+1+fanRays);
        const lastIndex=d.length-1;
        const lastTime=d[lastIndex].time;
        targets.forEach(t=>{
            const idxSpan=(t.index-origin.index)||1;
            const slope=(t.price-origin.price)/idxSpan;
            const extendedPrice=origin.price+slope*(lastIndex-origin.index);
            result.fanLines.push([
                {time:origin.time,value:origin.price},
                {time:t.time,value:t.price},
                {time:lastTime,value:extendedPrice}
            ]);
        });
    }

    // ---- ۳) پیش‌بینی رگرسیون خطی روی regLen کندل آخر، امتداد به سمت جلو به تعداد projBars کندل ----
    if(d.length>=regLen+2){
        const seg=d.slice(d.length-regLen);
        let sumX=0,sumY=0,sumXY=0,sumXX=0;
        seg.forEach((c,i)=>{sumX+=i;sumY+=c.close;sumXY+=i*c.close;sumXX+=i*i;});
        const n=seg.length;
        const denom=(n*sumXX-sumX*sumX)||1;
        const slope=(n*sumXY-sumX*sumY)/denom;
        const intercept=(sumY-slope*sumX)/n;
        const dir=slope>=0?'up':'down';
        result.projectionColor=dir==='up'?'#2196f3':'#ff1744';
        const step=d.length>=2?(d[d.length-1].time-d[d.length-2].time):60;
        result.projection.push({time:d[d.length-1].time,value:d[d.length-1].close});
        for(let k=1;k<=projBars;k++){
            const idx=n-1+k;
            const val=intercept+slope*idx;
            result.projection.push({time:d[d.length-1].time+step*k,value:val});
        }
    }

    return result;
}

function removeFanProjectionSeries(){
    fanLineSeriesList.forEach(s=>{try{chart.removeSeries(s);}catch(e){}});
    fanLineSeriesList=[];
    if(fanProjectionSeries){try{chart.removeSeries(fanProjectionSeries);}catch(e){}fanProjectionSeries=null;}
}

function drawFanProjection(d){
    if(!chart||!candleSeries)return null;
    try{
        removeFanProjectionSeries();
        fanResult=calcFanProjection(d, fanSettings);

        // خطوط بادبزنی سفید نیمه‌شفاف
        fanResult.fanLines.forEach(line=>{
            const s=chart.addLineSeries({color:'rgba(255,255,255,0.55)',lineWidth:1,priceLineVisible:false,lastValueVisible:false,crosshairMarkerVisible:false});
            s.setData(line);
            fanLineSeriesList.push(s);
        });

        // خط نقطه‌چین رنگی پیش‌بینی (آبی=صعودی / قرمز=نزولی)
        if(fanResult.projection.length>1){
            fanProjectionSeries=chart.addLineSeries({
                color:fanResult.projectionColor, lineWidth:2, lineStyle:2,
                priceLineVisible:false, lastValueVisible:false, crosshairMarkerVisible:false
            });
            fanProjectionSeries.setData(fanResult.projection);
        }

        updateAllMarkers();
        console.log('=== Fan Projection: '+fanResult.markers.length+' سوئینگ | '+fanResult.fanLines.length+' خط بادبزن | جهت پیش‌بینی: '+(fanResult.projectionColor==='#2196f3'?'صعودی':'نزولی')+' ===');
        return fanResult;
    }catch(err){
        console.error('خطای کلی در drawFanProjection:',err);
        return null;
    }
}

function toggleFanProjection(){
    fanEnabled=!fanEnabled;
    const btn=document.getElementById('btnFanProjection');
    if(fanEnabled){
        btn.classList.add('active');
        btn.textContent='🔱 حذف اندیکاتور Fan Projection';
        if(currentCandles.length>0){
            setTimeout(function(){ drawFanProjection(currentCandles); },180);
        }
    }else{
        btn.classList.remove('active');
        btn.textContent='🔱 اعمال اندیکاتور Fan Projection';
        fanResult=null;
        removeFanProjectionSeries();
        updateAllMarkers();
    }
}

// ==================== اندیکاتور AI Price Path (بر اساس دو عکس ارسالی کاربر) ====================


// ==================== آزمایشگاه بک‌تست اندیکاتورها ====================
// سیگنال‌ها روی کل دیتا (با کندل‌های گرم‌کردن) محاسبه می‌شوند ولی فقط معاملاتی که داخل بازه انتخابی باز شده‌اند شمرده می‌شوند.
// ورود/خروج روی قیمت بسته شدن کندل سیگنال (یعنی لحظه‌ای که سیگنال واقعاً معلوم می‌شود).
const BT_TF_SEC={'1m':60,'5m':300,'15m':900,'30m':1800,'1h':3600,'4h':14400,'1d':86400};
const BT_MAX_CANDLES=10000, BT_WARMUP=300;
const BT_NAMES={alpha:'Alpha Ribbon',multilayer:'Multi-Layer',zones:'Zones/Zigzag',signalfilter:'فیلتر تایید سیگنال',structure:'ساختار بازار (BOS)',fan:'Fan Projection',aipath:'AI Price Path',pf:'Lorentzian ML',mybot:'MyBot (ربات MT5)',p1:'P1 FVG Order Blocks',p2:'P2 Impulse Heatmap',p3:'P3 ML Adaptive SuperTrend',p4:'P4 Lorentzian',p5:'P5 Pro Scalper',p6:'P6 Breakout Channels',p7:'P7 Swift Algo X',pall:'Σ ترکیب وزنی P1-P7'};

// ==================== اندیکاتور Pro F (ورود/خروج هوشمند: Supertrend + امتیازدهی ۱۰ معیاره + فیلتر رژیم بازار + تایید تایم‌فریم بالاتر) ====================
// منطق:
//   ۱) جهت بازار با Supertrend (ATR) تعیین می‌شود؛ ورود فقط روی «بسته‌شدن کندل» (بدون ریپینت).
//   ۲) دو نوع ورود: FLIP = برگشت جهت Supertrend | PB = پولبک به EMA سریع در روند و بازگشت بالای/پایین کندل قبلی.
//   ۳) فیلترهای سخت (برگرفته از موتور Brain Tunnel): رژیم بازار (ADX پایین + Hurst پایین = بازار رنج => ورود ممنوع)،
//      باند نوسان ATR٪، و تایید تایم‌فریم بالاتر (کندل‌های بسته‌شده تایم‌فریم انتخابی، بدون نگاه به آینده).
//   ۴) امتیاز کیفیت ۱۰ معیاره: روند اصلی، EMA، ADX/DI، RSI، MACD، حجم، قدرت کندل، ساختار HH/HL، فشار خرید/فروش، Aroon.
//   ۵) خروج: حد ضرر (سوئینگ/ATR) | TP1 جزئی + انتقال حد ضرر به ورود | TP2 | تریلینگ با Supertrend بعد از TP1 | برگشت روند | سیگنال مخالف | حداکثر زمان.
//   ۶) اگر حد ضرر و حد سود در یک کندل باشند، حد ضرر اول حساب می‌شود (محافظه‌کارانه).
let pfEnabled=false;
let pfResult=null;
let pfLineSeries=[];
let pfLevelSeries=[];
let pfPriceLines=[];
const PF_TF_SEC={'1m':60,'5m':300,'15m':900,'30m':1800,'1h':3600,'4h':14400,'1d':86400,'1w':604800};
// تایم‌فریم بالاتر خودکار (مطابق موتور Brain Tunnel)
const PF_HTF_AUTO={'1m':['5m','15m'],'5m':['15m','1h'],'15m':['1h','4h'],'30m':['1h','4h'],'1h':['4h','1d'],'4h':['1d','1w'],'1d':['1w'],'1w':[]};
// دوره اندیکاتورها بر اساس تایم‌فریم (مطابق موتور Brain Tunnel)
const PF_TF_PERIODS={
    '1m':{rsi:10,mf:8,ms:18,msig:6,atr:10,adx:10},
    '5m':{rsi:12,mf:10,ms:22,msig:7,atr:12,adx:12},
    '15m':{rsi:14,mf:12,ms:26,msig:9,atr:14,adx:14},
    '30m':{rsi:14,mf:12,ms:26,msig:9,atr:14,adx:14},
    '1h':{rsi:14,mf:12,ms:26,msig:9,atr:14,adx:14},
    '4h':{rsi:16,mf:14,ms:30,msig:10,atr:16,adx:16},
    '1d':{rsi:20,mf:16,ms:34,msig:12,atr:20,adx:20},
    '1w':{rsi:24,mf:18,ms:38,msig:14,atr:24,adx:24}
};
const PF_PRESETS={
    // «جنگجوی قوی»: بدون فیلتر مسدودکننده؛ قدرت از ورودی‌های بیشتر + خروج هوشمند (تریلینگ شاندلیر) + سود بدون سقف می‌آید
    power:{minScore:0,adxMin:18,entryMode:'all',cooldown:0,rr1:1.2,rr2:10,regimeFilter:false,htfMode:'off',minAtrPct:0,maxAtrPct:0,tp1Pct:30,maxHold:1000,trail:true,moveBE:true,chTrail:true,chMult:2.5,trailStartR:1.0,brkLen:20},
    // «جنگجوی محدودشده» (منطق قدیمی) فقط برای مقایسه
    strict:{minScore:7,adxMin:22,entryMode:'flip',cooldown:6,rr1:1.5,rr2:3,regimeFilter:true,htfMode:'strict',minAtrPct:0.04,maxAtrPct:8,tp1Pct:50,maxHold:150,chTrail:false},
    balanced:{minScore:5,adxMin:18,entryMode:'both',cooldown:4,rr1:1.5,rr2:3,regimeFilter:true,htfMode:'strict',minAtrPct:0.04,maxAtrPct:8,tp1Pct:50,maxHold:150,chTrail:false},
    more:{minScore:4,adxMin:14,entryMode:'both',cooldown:2,rr1:1.2,rr2:2.5,regimeFilter:false,htfMode:'soft',minAtrPct:0.04,maxAtrPct:8,tp1Pct:50,maxHold:150,chTrail:false}
};
const PF_FIELDS=[
    {id:'setPfStMult',k:'stMult',t:'num',min:0.5},
    {id:'setPfAtrLen',k:'atrLen',t:'int',min:2},
    {id:'setPfEmaFast',k:'emaFast',t:'int',min:2},
    {id:'setPfEmaSlow',k:'emaSlow',t:'int',min:3},
    {id:'setPfEmaTrend',k:'emaTrend',t:'int',min:10},
    {id:'setPfTfAdaptive',k:'tfAdaptive',t:'chk'},
    {id:'setPfAdxMin',k:'adxMin',t:'num',min:0},
    {id:'setPfMinScore',k:'minScore',t:'int',min:0},
    {id:'setPfBody',k:'bodyMinPct',t:'num',min:0},
    {id:'setPfVol',k:'volMult',t:'num',min:0},
    {id:'setPfEntryMode',k:'entryMode',t:'sel'},
    {id:'setPfDir',k:'dirMode',t:'sel'},
    {id:'setPfCooldown',k:'cooldown',t:'int',min:0},
    {id:'setPfRegime',k:'regimeFilter',t:'chk'},
    {id:'setPfRegimeAdx',k:'regimeAdx',t:'num',min:5},
    {id:'setPfHurstMin',k:'hurstMin',t:'num',min:0},
    {id:'setPfMinAtrPct',k:'minAtrPct',t:'num',min:0},
    {id:'setPfMaxAtrPct',k:'maxAtrPct',t:'num',min:0},
    {id:'setPfHtfMode',k:'htfMode',t:'sel'},
    {id:'setPfHtf1',k:'htfTf1',t:'sel'},
    {id:'setPfHtf2',k:'htfTf2',t:'sel'},
    {id:'setPfClosedOnly',k:'closedOnly',t:'chk'},
    {id:'setPfSlMode',k:'slMode',t:'sel'},
    {id:'setPfSlAtr',k:'slAtr',t:'num',min:0.2},
    {id:'setPfSwing',k:'swingLen',t:'int',min:2},
    {id:'setPfRR1',k:'rr1',t:'num',min:0.2},
    {id:'setPfRR2',k:'rr2',t:'num',min:0.3},
    {id:'setPfAdaptRR',k:'adaptiveRR',t:'chk'},
    {id:'setPfTp1Pct',k:'tp1Pct',t:'num',min:0},
    {id:'setPfBE',k:'moveBE',t:'chk'},
    {id:'setPfTrail',k:'trail',t:'chk'},
    {id:'setPfMaxHold',k:'maxHold',t:'int',min:5},
    {id:'setPfArrow',k:'arrowSize',t:'num',min:1},
    {id:'setPfShowLine',k:'showLine',t:'chk'},
    {id:'setPfShowLevels',k:'showLevels',t:'chk'},
    {id:'setPfShowCard',k:'showCard',t:'chk'},
    {id:'setPfChTrail',k:'chTrail',t:'chk'},
    {id:'setPfChMult',k:'chMult',t:'num',min:0.5},
    {id:'setPfTrailStartR',k:'trailStartR',t:'num',min:0},
    {id:'setPfBrkLen',k:'brkLen',t:'int',min:5},
    {id:'setPfUseProfile',k:'useProfile',t:'chk'},
    {id:'setPfSetup',k:'setup',t:'sel'}
];
PF_FIELDS.push({id:'setLzK',k:'lz_k',t:'int',min:1},{id:'setLzMaxBars',k:'lz_maxBars',t:'int',min:50},{id:'setLzFc',k:'lz_fc',t:'int',min:2},{id:'setLzVol',k:'lz_vol',t:'chk'},{id:'setLzRegime',k:'lz_regime',t:'chk'},{id:'setLzAdx',k:'lz_adx',t:'chk'},{id:'setLzRegimeThr',k:'lz_regimeThr',t:'num'},{id:'setLzAdxThr',k:'lz_adxThr',t:'num'},{id:'setLzEma',k:'lz_ema',t:'chk'},{id:'setLzEmaP',k:'lz_emaP',t:'int',min:2},{id:'setLzSma',k:'lz_sma',t:'chk'},{id:'setLzSmaP',k:'lz_smaP',t:'int',min:2},{id:'setLzKernel',k:'lz_kernel',t:'chk'},{id:'setLzKernelShow',k:'lz_kernelShow',t:'chk'},{id:'setLzKernelSmooth',k:'lz_kernelSmooth',t:'chk'},{id:'setLzH',k:'lz_h',t:'int',min:3},{id:'setLzR',k:'lz_r',t:'num',min:0.25},{id:'setLzX',k:'lz_x',t:'int',min:0},{id:'setLzLag',k:'lz_lag',t:'int',min:0},{id:'setLzDyn',k:'lz_dyn',t:'chk'},{id:'setLzShowExits',k:'lz_showExits',t:'chk'},{id:'setLzFullHist',k:'lz_fullHist',t:'chk'},{id:'setLzLabel',k:'lz_label',t:'sel'},{id:'setLzShowPred',k:'lz_showPred',t:'chk'},{id:'setLzF1t',k:'lz_f1t',t:'sel'},{id:'setLzF1a',k:'lz_f1a',t:'int',min:1},{id:'setLzF1b',k:'lz_f1b',t:'int',min:1},{id:'setLzF2t',k:'lz_f2t',t:'sel'},{id:'setLzF2a',k:'lz_f2a',t:'int',min:1},{id:'setLzF2b',k:'lz_f2b',t:'int',min:1},{id:'setLzF3t',k:'lz_f3t',t:'sel'},{id:'setLzF3a',k:'lz_f3a',t:'int',min:1},{id:'setLzF3b',k:'lz_f3b',t:'int',min:1},{id:'setLzF4t',k:'lz_f4t',t:'sel'},{id:'setLzF4a',k:'lz_f4a',t:'int',min:1},{id:'setLzF4b',k:'lz_f4b',t:'int',min:1},{id:'setLzF5t',k:'lz_f5t',t:'sel'},{id:'setLzF5a',k:'lz_f5a',t:'int',min:1},{id:'setLzF5b',k:'lz_f5b',t:'int',min:1});

let pfSettings=Object.assign({
    preset:'power',atrLen:14,stMult:3,emaFast:21,emaSlow:55,emaTrend:200,rsiLen:14,adxLen:14,
    volMult:0,bodyMinPct:40,dirMode:'both',slMode:'swing',slAtr:1.5,swingLen:8,slBufAtr:0.2,
    minRiskAtr:1.0,maxRiskAtr:3.5,tp1Pct:30,moveBE:true,trail:true,maxHold:1000,
    showLine:true,showLevels:true,showCard:true,maxLevels:8,
    arrowSize:2,tfAdaptive:true,regimeAdx:25,hurstMin:0.55,minAtrPct:0.04,maxAtrPct:8,
    adaptiveRR:false,closedOnly:true,htfTf1:'auto',htfTf2:'off',
    chTrail:true,chMult:2.5,trailStartR:1.0,brkLen:20,useProfile:true,
    setup:'lorentzian',lz_k:8,lz_maxBars:2000,lz_fc:5,lz_f1t:'RSI',lz_f1a:14,lz_f1b:1,lz_f2t:'WT',lz_f2a:10,lz_f2b:11,lz_f3t:'CCI',lz_f3a:20,lz_f3b:1,lz_f4t:'ADX',lz_f4a:20,lz_f4b:2,lz_f5t:'RSI',lz_f5a:9,lz_f5b:1,lz_vol:true,lz_regime:true,lz_adx:false,lz_regimeThr:-0.1,lz_adxThr:20,lz_ema:false,lz_emaP:200,lz_sma:false,lz_smaP:200,lz_kernel:true,lz_kernelShow:true,lz_kernelSmooth:false,lz_h:8,lz_r:8,lz_x:25,lz_lag:2,lz_dyn:false,lz_showExits:false,lz_fullHist:false,lz_label:'literal',lz_showPred:false,rv_rsiLen:3,rv_rsiLo:20,rv_trendMode:'with',rv_trendLen:100,rv_bbK:0,rv_meanLen:20,rv_exitMode:'atr',rv_stopAtr:2.5,rv_tgtAtr:1.2,rv_maxBars:30
},PF_PRESETS.power);
// پروفایل بهینه هر تایم‌فریم (خروجی بهینه‌ساز Walk-Forward؛ فقط تایم‌فریم‌هایی که روی دیتای دیده‌نشده تایید شده‌اند ذخیره می‌شوند)
let PF_TF_PROFILES=(function(){try{const o=JSON.parse(localStorage.getItem('pfTfProfiles')||'{}');return (o&&typeof o==='object')?o:{};}catch(e){return {};}})();
function pfSaveProfiles(){try{localStorage.setItem('pfTfProfiles',JSON.stringify(PF_TF_PROFILES));}catch(e){}}
function pfProfileFor(tf){return (pfSettings.useProfile&&PF_TF_PROFILES[tf])?PF_TF_PROFILES[tf]:{};}

function pfEma(arr,p){
    const n=arr.length,r=new Array(n),k=2/(p+1);
    if(!n)return r;
    r[0]=arr[0];
    for(let i=1;i<n;i++)r[i]=arr[i]*k+r[i-1]*(1-k);
    return r;
}
function pfSma(arr,p){
    const n=arr.length,r=new Array(n).fill(NaN);let s=0;
    for(let i=0;i<n;i++){
        s+=arr[i];
        if(i>=p)s-=arr[i-p];
        if(i>=p-1)r[i]=s/p;
    }
    return r;
}
function pfAtr(d,p){
    const n=d.length,r=new Array(n).fill(NaN),tr=new Array(n);
    for(let i=0;i<n;i++){
        const pc=i>0?d[i-1].close:d[i].close;
        tr[i]=Math.max(d[i].high-d[i].low,Math.abs(d[i].high-pc),Math.abs(d[i].low-pc));
    }
    if(n<p)return r;
    let s=0;for(let i=0;i<p;i++)s+=tr[i];
    r[p-1]=s/p;
    for(let i=p;i<n;i++)r[i]=(r[i-1]*(p-1)+tr[i])/p;
    return r;
}
function pfRsi(d,p){
    const n=d.length,r=new Array(n).fill(NaN);
    if(n<=p)return r;
    let g=0,l=0;
    for(let i=1;i<=p;i++){const df=d[i].close-d[i-1].close;if(df>=0)g+=df;else l-=df;}
    g/=p;l/=p;
    r[p]=l===0?100:100-100/(1+g/l);
    for(let i=p+1;i<n;i++){
        const df=d[i].close-d[i-1].close;
        g=(g*(p-1)+(df>0?df:0))/p;
        l=(l*(p-1)+(df<0?-df:0))/p;
        r[i]=l===0?100:100-100/(1+g/l);
    }
    return r;
}
function pfAdx(d,p){
    const n=d.length,adx=new Array(n).fill(NaN),pdi=new Array(n).fill(NaN),mdi=new Array(n).fill(NaN);
    if(n<2*p+2)return {adx:adx,pdi:pdi,mdi:mdi};
    const tr=new Array(n).fill(0),pm=new Array(n).fill(0),mm=new Array(n).fill(0);
    for(let i=1;i<n;i++){
        const up=d[i].high-d[i-1].high,dn=d[i-1].low-d[i].low;
        pm[i]=(up>dn&&up>0)?up:0;
        mm[i]=(dn>up&&dn>0)?dn:0;
        tr[i]=Math.max(d[i].high-d[i].low,Math.abs(d[i].high-d[i-1].close),Math.abs(d[i].low-d[i-1].close));
    }
    let trS=0,pS=0,mS=0;
    for(let i=1;i<=p;i++){trS+=tr[i];pS+=pm[i];mS+=mm[i];}
    const dx=new Array(n).fill(NaN);
    for(let i=p;i<n;i++){
        if(i>p){trS=trS-trS/p+tr[i];pS=pS-pS/p+pm[i];mS=mS-mS/p+mm[i];}
        pdi[i]=trS>0?100*pS/trS:0;
        mdi[i]=trS>0?100*mS/trS:0;
        const sm=pdi[i]+mdi[i];
        dx[i]=sm>0?100*Math.abs(pdi[i]-mdi[i])/sm:0;
    }
    let s=0;for(let i=p;i<2*p;i++)s+=dx[i];
    adx[2*p-1]=s/p;
    for(let i=2*p;i<n;i++)adx[i]=(adx[i-1]*(p-1)+dx[i])/p;
    return {adx:adx,pdi:pdi,mdi:mdi};
}
function pfSupertrend(d,atr,mult){
    const n=d.length,dir=new Array(n).fill(0),line=new Array(n).fill(NaN);
    let fu=NaN,fl=NaN,started=false;
    for(let i=0;i<n;i++){
        if(!isFinite(atr[i]))continue;
        const hl2=(d[i].high+d[i].low)/2,bu=hl2+mult*atr[i],bl=hl2-mult*atr[i];
        if(!started){
            fu=bu;fl=bl;dir[i]=d[i].close>=hl2?1:-1;started=true;
        }else{
            const pfu=fu,pfl=fl,pc=d[i-1].close;
            fu=(bu<pfu||pc>pfu)?bu:pfu;
            fl=(bl>pfl||pc<pfl)?bl:pfl;
            dir[i]=dir[i-1];
            if(dir[i-1]===-1&&d[i].close>pfu)dir[i]=1;
            else if(dir[i-1]===1&&d[i].close<pfl)dir[i]=-1;
        }
        line[i]=dir[i]===1?fl:fu;
    }
    return {dir:dir,line:line};
}
// نمای هرست (R/S) - پورت از موتور Brain Tunnel؛ فقط روی کندل‌های کاندید محاسبه می‌شود تا سریع بماند
function pfHurst(closes,end,maxLag){
    maxLag=maxLag||50;
    if(end+1<maxLag+10)return 0.5;
    const start=Math.max(0,end+1-maxLag*2);
    const prices=closes.slice(start,end+1);
    if(prices.length<maxLag)return 0.5;
    const lr=[];
    for(let i=1;i<prices.length;i++){if(prices[i-1]>0)lr.push(Math.log(prices[i]/prices[i-1]));}
    if(lr.length<10)return 0.5;
    const tau=[];
    const lagMax=Math.min(maxLag,Math.floor(lr.length/2));
    for(let lag=2;lag<lagMax;lag++){
        const segs=Math.floor(lr.length/lag);
        if(segs<2)continue;
        const rs=[];
        for(let sg=0;sg<segs;sg++){
            const s0=sg*lag,e0=s0+lag;
            if(e0>lr.length)break;
            let mean=0;
            for(let j=s0;j<e0;j++)mean+=lr[j];
            mean/=lag;
            let cum=0,mx=0,mn=0,vr=0;
            for(let j=s0;j<e0;j++){cum+=lr[j]-mean;if(cum>mx)mx=cum;if(cum<mn)mn=cum;vr+=(lr[j]-mean)*(lr[j]-mean);}
            const S=Math.sqrt(vr/lag);
            if(S>0)rs.push((mx-mn)/S);
        }
        if(rs.length){
            let a=0;for(let j=0;j<rs.length;j++)a+=rs[j];
            a/=rs.length;
            if(a>0)tau.push([Math.log(lag),Math.log(a)]);
        }
    }
    if(tau.length<2)return 0.5;
    let sx=0,sy=0,sxy=0,sx2=0;
    tau.forEach(function(t){sx+=t[0];sy+=t[1];sxy+=t[0]*t[1];sx2+=t[0]*t[0];});
    const m=tau.length,den=m*sx2-sx*sx;
    if(den===0)return 0.5;
    return Math.min(1,Math.max(0,(m*sxy-sx*sy)/den));
}
function pfEmptyStats(){
    return {trades:0,wins:0,losses:0,be:0,winRate:0,winRateNoBE:0,totalR:0,avgR:0,pf:0,maxDD:0,longN:0,shortN:0,tp1Rate:0,tp1n:0};
}
function pfOutcomeFa(o){
    return {ex4:'خروج ۴ کندلی',kex:'خروج کرنل',tgt:'هدف',mean:'بازگشت به میانگین',sl:'حد ضرر',tp1:'TP1',tp2:'TP2',be:'سر به سر',trail:'تریلینگ',flip:'برگشت روند',rev:'سیگنال مخالف',time:'پایان زمان',open:'باز'}[o]||o;
}
function pfOutcomeTag(o){
    return {ex4:'4B',kex:'KERN',tgt:'TGT',mean:'MEAN',sl:'SL',tp1:'TP1',tp2:'TP2',be:'BE',trail:'TRAIL',flip:'EXIT',rev:'EXIT',time:'TIME',open:'OPEN'}[o]||o;
}

// تعیین جهت تایم‌فریم بالاتر برای هر کندل تایم‌فریم اصلی: فقط از کندل‌های «بسته‌شده» HTF استفاده می‌شود (بدون نگاه به آینده)
function pfHtfBiasFor(d,hc,mainSec,htfSec,s){
    if(!hc||hc.length<80||!d||!d.length)return null;
    const ef=Math.max(2,parseInt(s.emaFast)||21),es=Math.max(3,parseInt(s.emaSlow)||55);
    const per=(s.tfAdaptive&&s.htfName&&PF_TF_PERIODS[s.htfName])?PF_TF_PERIODS[s.htfName]:null;
    const atrLen=per?per.atr:Math.max(2,parseInt(s.atrLen)||14);
    const closes=hc.map(c=>c.close);
    const e1=pfEma(closes,ef),e2=pfEma(closes,es);
    const st=pfSupertrend(hc,pfAtr(hc,atrLen),Math.max(0.5,parseFloat(s.stMult)||3));
    const warm=Math.max(es,30);
    const biasH=hc.map(function(c,k){
        if(k<warm||!isFinite(st.line[k]))return 0;
        if(st.dir[k]===1&&e1[k]>e2[k])return 1;
        if(st.dir[k]===-1&&e1[k]<e2[k])return -1;
        return 0;
    });
    const out=new Int8Array(d.length);
    let k=-1;
    for(let i=0;i<d.length;i++){
        const barClose=d[i].time+mainSec;
        while(k+1<hc.length&&hc[k+1].time+htfSec<=barClose)k++;
        out[i]=k>=0?biasH[k]:0;
    }
    return out;
}

// htf = {biases:[Int8Array,...], tfs:[...]} (اختیاری)
function calcProF(d,s,htf){
    s=s||pfSettings;
    if(s&&s.setup==='lorentzian')return calcLorentzian(d,s);
    if(s&&s.setup==='revert')return calcProFRev(d,s);
    const n=d?d.length:0;
    const res={trades:[],markers:[],up:[],dn:[],stats:pfEmptyStats(),open:null,lastDir:0,htfNow:[],htfTfs:(htf&&htf.tfs)?htf.tfs.slice():[],filtered:{regime:0,htf:0,vol:0,score:0}};
    if(n<80)return res;
    const num=function(v,def){const x=parseFloat(v);return isNaN(x)?def:x;};
    const per=s.tfAdaptive?PF_TF_PERIODS[s.tf]:null;
    const atrLen=per?per.atr:Math.max(2,parseInt(s.atrLen)||14);
    const rsiLen=per?per.rsi:Math.max(2,parseInt(s.rsiLen)||14);
    const adxLen=per?per.adx:Math.max(2,parseInt(s.adxLen)||14);
    const mF=per?per.mf:12,mS=per?per.ms:26,mG=per?per.msig:9;
    const stMult=Math.max(0.5,num(s.stMult,3));
    const closes=d.map(c=>c.close);
    const emaF=pfEma(closes,Math.max(2,parseInt(s.emaFast)||21));
    const emaS=pfEma(closes,Math.max(3,parseInt(s.emaSlow)||55));
    const emaT=pfEma(closes,Math.max(10,parseInt(s.emaTrend)||200));
    const atr=pfAtr(d,atrLen);
    const rsi=pfRsi(d,rsiLen);
    const adxO=pfAdx(d,adxLen);
    const st=pfSupertrend(d,atr,stMult);
    const eA=pfEma(closes,mF),eB=pfEma(closes,mS);
    const macdL=eA.map((v,i)=>v-eB[i]);
    const macdS=pfEma(macdL,mG);
    const hist=macdL.map((v,i)=>v-macdS[i]);
    const vols=d.map(c=>c.volume>0?c.volume:0);
    const volAvg=pfSma(vols,20);
    let hasVol=false;
    for(let i=Math.max(0,n-60);i<n;i++){if(vols[i]>0){hasVol=true;break;}}
    const minScore=Math.max(0,parseInt(s.minScore));
    const adxMin=num(s.adxMin,18),volMult=num(s.volMult,0),bodyMin=num(s.bodyMinPct,40)/100;
    const cooldown=Math.max(0,parseInt(s.cooldown)||0);
    const mode=s.entryMode||'all',dirMode=s.dirMode||'both';
    const brkLen=Math.max(5,parseInt(s.brkLen)||20);
    const chOn=!!s.chTrail,chMult=Math.max(0.5,num(s.chMult,2.5)),trailStartR=Math.max(0,num(s.trailStartR,1));
    const tp1Frac=Math.min(1,Math.max(0,num(s.tp1Pct,50)/100));
    const rr1=Math.max(0.2,num(s.rr1,1.5)),rr2=Math.max(rr1+0.1,num(s.rr2,3));
    const maxHold=Math.max(5,parseInt(s.maxHold)||150);
    const swingLen=Math.max(2,parseInt(s.swingLen)||8);
    const warm=Math.max(60,atrLen*3,(parseInt(s.emaSlow)||55)+5);
    const regimeOn=!!s.regimeFilter,regimeAdx=num(s.regimeAdx,25),hurstMin=num(s.hurstMin,0.55);
    const minAtrPct=num(s.minAtrPct,0),maxAtrPct=num(s.maxAtrPct,0);
    const htfMode=s.htfMode||'off';
    const htfB=(htf&&htf.biases&&htf.biases.length&&htfMode!=='off')?htf.biases:[];
    if(htf&&htf.biases)htf.biases.forEach(function(b){res.htfNow.push(b?b[n-1]:0);});

    for(let i=0;i<n;i++){
        if(!isFinite(st.line[i]))continue;
        if(st.dir[i]===1)res.up.push({time:d[i].time,value:st.line[i]});
        else res.up.push({time:d[i].time});
        if(st.dir[i]===-1)res.dn.push({time:d[i].time,value:st.line[i]});
        else res.dn.push({time:d[i].time});
    }

    // ارزیابی سیگنال ورود روی کندل بسته‌شده i
    function evalEntry(i){
        const a=atr[i];
        if(!isFinite(a)||a<=0)return null;
        const c=d[i],p=d[i-1];
        const dr=st.dir[i];
        const flipUp=st.dir[i-1]===-1&&dr===1,flipDn=st.dir[i-1]===1&&dr===-1;
        const rng=c.high-c.low,body=Math.abs(c.close-c.open);
        let sig=null,type='';
        const pbUp=dr===1&&emaF[i]>emaS[i]&&p.low<=emaF[i-1]+0.1*a&&c.close>emaF[i]&&c.close>p.high&&c.close>c.open;
        const pbDn=dr===-1&&emaF[i]<emaS[i]&&p.high>=emaF[i-1]-0.1*a&&c.close<emaF[i]&&c.close<p.low&&c.close<c.open;
        const okFlip=(mode==='flip'||mode==='both'||mode==='all'),okPb=(mode==='pullback'||mode==='both'||mode==='all'),okBrk=(mode==='breakout'||mode==='all');
        // BRK: ادامه روند با شکست سقف/کف N کندل اخیر (ورود مجدد قدرتمند بعد از حد ضرر یا استراحت روند)
        let brkUp=false,brkDn=false;
        if(okBrk&&i>brkLen+1){
            let hh=-Infinity,ll=Infinity;
            for(let j=i-brkLen;j<i;j++){if(d[j].high>hh)hh=d[j].high;if(d[j].low<ll)ll=d[j].low;}
            brkUp=dr===1&&emaF[i]>emaS[i]&&c.close>hh&&c.close>c.open&&rng>0&&(c.close-c.low)/rng>=0.6;
            brkDn=dr===-1&&emaF[i]<emaS[i]&&c.close<ll&&c.close<c.open&&rng>0&&(c.high-c.close)/rng>=0.6;
        }
        if(okFlip&&flipUp){sig='long';type='FLIP';}
        else if(okFlip&&flipDn){sig='short';type='FLIP';}
        else if(okPb&&pbUp){sig='long';type='PB';}
        else if(okPb&&pbDn){sig='short';type='PB';}
        else if(okBrk&&brkUp){sig='long';type='BRK';}
        else if(okBrk&&brkDn){sig='short';type='BRK';}
        if(!sig)return null;
        if(dirMode==='long'&&sig==='short')return null;
        if(dirMode==='short'&&sig==='long')return null;
        const m=sig==='long'?1:-1;
        // فیلتر نوسان (ATR٪ قیمت)
        const atrPct=a/c.close*100;
        if((minAtrPct>0&&atrPct<minAtrPct)||(maxAtrPct>0&&atrPct>maxAtrPct)){res.filtered.vol++;return null;}
        // تایید تایم‌فریم بالاتر
        for(let h=0;h<htfB.length;h++){
            const v=htfB[h]?htfB[h][i]:0;
            if(htfMode==='strict'){if(v!==m){res.filtered.htf++;return null;}}
            else if(v===-m){res.filtered.htf++;return null;}
        }
        // فیلتر رژیم بازار: ADX پایین + Hurst پایین = بازار رنج => ورود ممنوع
        const adxV=adxO.adx[i];
        if(regimeOn&&isFinite(adxV)&&adxV<=regimeAdx){
            if(pfHurst(closes,i)<hurstMin){res.filtered.regime++;return null;}
        }
        // امتیاز کیفیت (۱۰ معیار)
        let score=0;
        if(m*(c.close-emaT[i])>0)score++;
        if(m*(emaF[i]-emaS[i])>0)score++;
        if(isFinite(adxV)&&adxV>=adxMin&&m*(adxO.pdi[i]-adxO.mdi[i])>0)score++;
        if(isFinite(rsi[i])&&(m>0?(rsi[i]>=50&&rsi[i]<=78):(rsi[i]<=50&&rsi[i]>=22)))score++;
        if(m*hist[i]>0&&m*(hist[i]-hist[i-1])>0)score++;
        if(!hasVol||volMult<=0||(isFinite(volAvg[i])&&vols[i]>=volMult*volAvg[i]))score++;
        if(rng>0&&body/rng>=bodyMin&&(m>0?(c.close-c.low)/rng>=0.6:(c.high-c.close)/rng>=0.6))score++;
        // ساختار بازار: HH+HL (خرید) / LH+LL (فروش) نسبت به پنجره قبلی
        if(i>=30){
            let sh=-Infinity,sl=Infinity,ph=-Infinity,pl=Infinity;
            for(let j=i-19;j<=i;j++){if(d[j].high>sh)sh=d[j].high;if(d[j].low<sl)sl=d[j].low;}
            for(let j=i-24;j<=i-5;j++){if(d[j].high>ph)ph=d[j].high;if(d[j].low<pl)pl=d[j].low;}
            if(m>0?(sh>ph&&sl>pl):(sh<ph&&sl<pl))score++;
        }
        // فشار خرید/فروش (حجم کندل‌های صعودی در برابر نزولی، ۲۰ کندل اخیر)
        if(!hasVol){score++;}
        else{
            let bv=0,sv=0;
            for(let j=i-19;j<=i;j++){if(d[j].close>d[j].open)bv+=vols[j];else sv+=vols[j];}
            const pr=(bv/(sv+1)-1)*50;
            if(m*pr>8)score++;
        }
        // Aroon(25)
        if(i>=26){
            let hi=-Infinity,lo=Infinity,hiI=i,loI=i;
            for(let j=i-25;j<=i;j++){
                if(d[j].high>=hi){hi=d[j].high;hiI=j;}
                if(d[j].low<=lo){lo=d[j].low;loI=j;}
            }
            const au=100*(25-(i-hiI))/25,ad=100*(25-(i-loI))/25;
            if(m>0?(au>70&&au>ad+30):(ad>70&&ad>au+30))score++;
        }
        if(score<minScore){res.filtered.score++;return null;}
        // حد ضرر
        let risk;
        if(s.slMode==='atr'){
            risk=Math.max(0.2,num(s.slAtr,1.5))*a;
        }else{
            let sw=m>0?Infinity:-Infinity;
            for(let j=Math.max(0,i-swingLen+1);j<=i;j++){
                if(m>0)sw=Math.min(sw,d[j].low);else sw=Math.max(sw,d[j].high);
            }
            const buf=num(s.slBufAtr,0.2)*a;
            const raw=m>0?c.close-(sw-buf):(sw+buf)-c.close;
            risk=Math.min(Math.max(raw,num(s.minRiskAtr,0.8)*a),num(s.maxRiskAtr,3.5)*a);
        }
        if(!(risk>0))return null;
        // ضریب RR تطبیقی (نوسان + قدرت روند)
        let rf=1;
        if(s.adaptiveRR&&isFinite(adxV))rf=Math.min(1.6,Math.max(1,(1+atrPct/10)*(1+adxV/100)));
        return {dir:sig,m:m,type:type,score:score,risk:risk,rr1:rr1*rf,rr2:rr2*rf};
    }

    function finish(pos,idx,exitPrice,outcome){
        let R=0;
        pos.legs.forEach(function(l){R+=l.f*pos.m*(l.p-pos.entry)/pos.risk;});
        if(pos.remain>1e-9)R+=pos.remain*pos.m*(exitPrice-pos.entry)/pos.risk;
        return {dir:pos.dir,type:pos.type,score:pos.score,entryIdx:pos.entryIdx,entryTime:d[pos.entryIdx].time,entry:pos.entry,
            sl0:pos.sl0,sl:pos.sl,risk:pos.risk,tp1:pos.tp1,tp2:pos.tp2,exitIdx:idx,exitTime:d[idx].time,exitPrice:exitPrice,
            R:R,outcome:outcome,tp1Hit:pos.tp1Hit,tp1Idx:pos.tp1Idx,bars:idx-pos.entryIdx,open:outcome==='open'};
    }

    let pos=null;
    const lastEntry={long:-9999,short:-9999};
    for(let i=warm;i<n;i++){
        const c=d[i];
        let closedByClose=false;
        const cand=evalEntry(i);
        if(pos){
            const m=pos.m;
            const adverse=m>0?c.low:c.high,fav=m>0?c.high:c.low;
            const slHit=m>0?adverse<=pos.sl:adverse>=pos.sl;
            if(slHit){
                let oc='sl';
                if(pos.tp1Hit||Math.abs(pos.sl-pos.sl0)>1e-12)oc=Math.abs(pos.sl-pos.entry)<pos.risk*0.02?'be':'trail';
                res.trades.push(finish(pos,i,pos.sl,oc));pos=null;
            }else{
                if(!pos.tp1Hit&&(m>0?fav>=pos.tp1:fav<=pos.tp1)){
                    pos.tp1Hit=true;pos.tp1Idx=i;
                    if(tp1Frac>0){pos.legs.push({f:tp1Frac,p:pos.tp1});pos.remain-=tp1Frac;}
                    if(s.moveBE)pos.pendingBE=true;
                }
                if(pos.tp1Hit&&pos.remain<=1e-9){
                    res.trades.push(finish(pos,i,pos.tp1,'tp1'));pos=null;
                }else if(pos.tp1Hit&&(m>0?fav>=pos.tp2:fav<=pos.tp2)){
                    res.trades.push(finish(pos,i,pos.tp2,'tp2'));pos=null;
                }
            }
            if(pos){
                let reason=null;
                if(st.dir[i]===-m)reason='flip';
                else if(cand&&cand.dir!==pos.dir)reason='rev';
                else if(i-pos.entryIdx>=maxHold)reason='time';
                if(reason){
                    res.trades.push(finish(pos,i,c.close,reason));pos=null;closedByClose=(reason!=='time');
                }else{
                    if(pos.pendingBE){pos.sl=m>0?Math.max(pos.sl,pos.entry):Math.min(pos.sl,pos.entry);pos.pendingBE=false;}
                    if(pos.tp1Hit&&s.trail){
                        const tl=st.line[i];
                        if(m>0&&tl>pos.sl&&tl<c.close)pos.sl=tl;
                        if(m<0&&tl<pos.sl&&tl>c.close)pos.sl=tl;
                    }
                    // تریلینگ شاندلیر: از همان لحظه‌ای که معامله به +trailStartR رسید فعال می‌شود (نیازی به TP1 نیست) و سود را قفل می‌کند
                    if(chOn){
                        pos.ext=m>0?Math.max(pos.ext,c.high):Math.min(pos.ext,c.low);
                        if(m*(pos.ext-pos.entry)/pos.risk>=trailStartR&&isFinite(atr[i])){
                            const tl2=pos.ext-m*chMult*atr[i];
                            if(m>0&&tl2>pos.sl&&tl2<c.close)pos.sl=tl2;
                            if(m<0&&tl2<pos.sl&&tl2>c.close)pos.sl=tl2;
                        }
                    }
                }
            }
        }
        if(!pos&&cand&&(closedByClose||!res.trades.length||res.trades[res.trades.length-1].exitIdx!==i)){
            if(i-lastEntry[cand.dir]>=cooldown){
                const m=cand.m,e=c.close;
                pos={dir:cand.dir,m:m,type:cand.type,score:cand.score,entryIdx:i,entry:e,risk:cand.risk,
                    sl:e-m*cand.risk,sl0:e-m*cand.risk,tp1:e+m*cand.rr1*cand.risk,tp2:e+m*cand.rr2*cand.risk,
                    legs:[],remain:1,tp1Hit:false,tp1Idx:-1,pendingBE:false,ext:e};
                lastEntry[cand.dir]=i;
            }
        }
    }
    if(pos){
        const t=finish(pos,n-1,d[n-1].close,'open');
        t.sl=pos.sl;
        res.trades.push(t);
        res.open=t;
        res.lastDir=pos.m;
    }
    // مارکرها (فلش ورود بزرگ‌تر)
    const asz=Math.max(1,Math.min(5,num(s.arrowSize,2)));
    res.trades.forEach(function(t){
        const long=t.dir==='long';
        res.markers.push({time:t.entryTime,position:long?'belowBar':'aboveBar',color:long?'#00e676':'#ff1744',shape:long?'arrowUp':'arrowDown',size:asz,text:(long?'PF BUY ':'PF SELL ')+t.type+' '+t.score+'/10'});
        if(t.tp1Hit&&t.tp1Idx>=0&&!(t.outcome==='tp1'&&t.tp1Idx===t.exitIdx)){
            res.markers.push({time:d[t.tp1Idx].time,position:long?'aboveBar':'belowBar',color:'#69f0ae',shape:'circle',size:Math.max(1,asz*0.6),text:'TP1'});
        }
        if(!t.open){
            const col=t.R>0.0001?'#00e676':(t.R<-0.0001?'#ff5252':'#ffd54f');
            res.markers.push({time:t.exitTime,position:long?'aboveBar':'belowBar',color:col,shape:'square',size:Math.max(1,asz*0.6),text:pfOutcomeTag(t.outcome)+' '+(t.R>=0?'+':'')+t.R.toFixed(1)+'R'});
        }
    });
    // آمار تمام معامله‌های بسته‌شده
    const stt=pfEmptyStats();
    let gp=0,gl=0,eq=0,peak=0;
    res.trades.forEach(function(t){
        if(t.dir==='long')stt.longN++;else stt.shortN++;
        if(t.open)return;
        stt.trades++;stt.totalR+=t.R;
        if(t.tp1Hit)stt.tp1n++;
        if(t.R>0.0001){stt.wins++;gp+=t.R;}
        else if(t.R<-0.0001){stt.losses++;gl+=-t.R;}
        else stt.be++;
        eq+=t.R;if(eq>peak)peak=eq;
        if(peak-eq>stt.maxDD)stt.maxDD=peak-eq;
    });
    stt.winRate=stt.trades?stt.wins/stt.trades*100:0;
    stt.winRateNoBE=(stt.wins+stt.losses)?stt.wins/(stt.wins+stt.losses)*100:0;
    stt.avgR=stt.trades?stt.totalR/stt.trades:0;
    stt.tp1Rate=stt.trades?stt.tp1n/stt.trades*100:0;
    stt.pf=gl>0?gp/gl:(gp>0?Infinity:0);
    res.stats=stt;
    return res;
}


// ==================== موتور بازگشت به میانگین (Revert): خرید ضعف‌های شدید RSI/Bollinger و خروج سریع روی هدف ATR یا میانگین؛ برد بالا با ضرر/سود کنترل‌شده ====================
function pfBuildMarkersAndStats(res,d,s){
    const asz=Math.max(1,Math.min(5,parseFloat(s.arrowSize)||2));
    res.trades.forEach(function(t){
        const long=t.dir==='long';
        res.markers.push({time:t.entryTime,position:long?'belowBar':'aboveBar',color:long?'#00e676':'#ff1744',shape:long?'arrowUp':'arrowDown',size:asz,text:(long?'PF BUY ':'PF SELL ')+t.type+' '+t.score+'/10'});
        if(!t.open){
            const col=t.R>0.0001?'#00e676':(t.R<-0.0001?'#ff5252':'#ffd54f');
            res.markers.push({time:t.exitTime,position:long?'aboveBar':'belowBar',color:col,shape:'square',size:Math.max(1,asz*0.6),text:pfOutcomeTag(t.outcome)+' '+(t.R>=0?'+':'')+t.R.toFixed(1)+'R'});
        }
    });
    const stt=pfEmptyStats();
    let gp=0,gl=0,eq=0,peak=0;
    res.trades.forEach(function(t){
        if(t.dir==='long')stt.longN++;else stt.shortN++;
        if(t.open)return;
        stt.trades++;stt.totalR+=t.R;
        if(t.R>0.0001){stt.wins++;gp+=t.R;}
        else if(t.R<-0.0001){stt.losses++;gl+=-t.R;}
        else stt.be++;
        eq+=t.R;if(eq>peak)peak=eq;
        if(peak-eq>stt.maxDD)stt.maxDD=peak-eq;
    });
    stt.winRate=stt.trades?stt.wins/stt.trades*100:0;
    stt.winRateNoBE=(stt.wins+stt.losses)?stt.wins/(stt.wins+stt.losses)*100:0;
    stt.avgR=stt.trades?stt.totalR/stt.trades:0;
    stt.pf=gl>0?gp/gl:(gp>0?Infinity:0);
    res.stats=stt;
}
function calcProFRev(d,s){
    const n=d?d.length:0;
    const res={trades:[],markers:[],up:[],dn:[],stats:pfEmptyStats(),open:null,lastDir:0,htfNow:[],htfTfs:[],filtered:{regime:0,htf:0,vol:0,score:0}};
    if(n<80)return res;
    const num=function(v,def){const x=parseFloat(v);return isNaN(x)?def:x;};
    const per=s.tfAdaptive?PF_TF_PERIODS[s.tf]:null;
    const atrLen=per?per.atr:Math.max(2,parseInt(s.atrLen)||14);
    const rsiLen=Math.max(2,parseInt(s.rv_rsiLen)||3);
    const rsiLo=num(s.rv_rsiLo,20),rsiHi=100-rsiLo;
    const trendMode=s.rv_trendMode||'with';
    const trendLen=Math.max(10,parseInt(s.rv_trendLen)||100);
    const bbK=num(s.rv_bbK,0),meanLen=Math.max(5,parseInt(s.rv_meanLen)||20);
    const exitMode=s.rv_exitMode||'atr';
    const stopAtr=Math.max(0.5,num(s.rv_stopAtr,2.5)),tgtAtr=Math.max(0.3,num(s.rv_tgtAtr,1.2));
    const maxBars=Math.max(3,parseInt(s.rv_maxBars)||30);
    const dirMode=s.dirMode||'both';
    const closes=d.map(function(c){return c.close;});
    const atr=pfAtr(d,atrLen),rsi=pfRsi(d,rsiLen),emaT=pfEma(closes,trendLen),mean=pfSma(closes,meanLen);
    const sd=new Array(n).fill(NaN);
    if(bbK>0){
        for(let i=meanLen-1;i<n;i++){
            let v=0;
            for(let j=i-meanLen+1;j<=i;j++){const df=closes[j]-mean[i];v+=df*df;}
            sd[i]=Math.sqrt(v/meanLen);
        }
    }
    const warm=Math.max(60,atrLen*3,meanLen+5,trendMode==='with'?trendLen:0);
    for(let i=0;i<n;i++){if(isFinite(mean[i]))res.up.push({time:d[i].time,value:mean[i]});}
    function mk(pos,idx,px,oc){
        const R=pos.m*(px-pos.entry)/pos.risk;
        return {dir:pos.dir,type:'REV',score:pos.score,entryIdx:pos.entryIdx,entryTime:d[pos.entryIdx].time,entry:pos.entry,
            sl0:pos.sl,sl:pos.sl,risk:pos.risk,tp1:pos.tp1,tp2:pos.tp1,exitIdx:idx,exitTime:d[idx].time,exitPrice:px,
            R:R,outcome:oc,tp1Hit:false,tp1Idx:-1,bars:idx-pos.entryIdx,open:oc==='open'};
    }
    let pos=null;
    for(let i=warm;i<n;i++){
        const c=d[i];
        let exitedNow=false;
        if(pos){
            const m=pos.m;
            let px=null,oc=null;
            if(m>0?c.low<=pos.sl:c.high>=pos.sl){px=m>0?Math.min(pos.sl,c.open):Math.max(pos.sl,c.open);oc='sl';}
            else if(pos.tgt!==null&&(m>0?c.high>=pos.tgt:c.low<=pos.tgt)){px=pos.tgt;oc='tgt';}
            else if(exitMode==='mean'&&isFinite(mean[i])&&(m>0?c.close>=mean[i]:c.close<=mean[i])){px=c.close;oc='mean';}
            else if(i-pos.entryIdx>=maxBars){px=c.close;oc='time';}
            if(oc){res.trades.push(mk(pos,i,px,oc));pos=null;exitedNow=true;}
        }
        if(pos||exitedNow)continue;
        const a=atr[i];
        if(!isFinite(a)||a<=0||!isFinite(rsi[i])||!isFinite(mean[i]))continue;
        const okL=rsi[i]<rsiLo&&(bbK<=0||c.close<mean[i]-bbK*sd[i])&&(trendMode!=='with'||c.close>emaT[i]);
        const okS=rsi[i]>rsiHi&&(bbK<=0||c.close>mean[i]+bbK*sd[i])&&(trendMode!=='with'||c.close<emaT[i]);
        let sig=null;
        if(okL&&dirMode!=='short')sig='long';
        else if(okS&&dirMode!=='long')sig='short';
        if(!sig)continue;
        const m=sig==='long'?1:-1,e=c.close,risk=stopAtr*a;
        const ext=m>0?(rsiLo-rsi[i])/rsiLo:(rsi[i]-rsiHi)/(100-rsiHi);
        const tgt=exitMode==='atr'?e+m*tgtAtr*a:null;
        pos={dir:sig,m:m,entryIdx:i,entry:e,risk:risk,sl:e-m*risk,tgt:tgt,tp1:tgt!==null?tgt:mean[i],score:Math.max(1,Math.min(10,Math.round(5+ext*5)))};
    }
    if(pos){
        const t=mk(pos,n-1,d[n-1].close,'open');
        res.trades.push(t);res.open=t;res.lastDir=pos.m;
    }
    pfBuildMarkersAndStats(res,d,s);
    return res;
}


// ==================== Lorentzian Classification (Machine Learning) - بازسازی اندیکاتور jdehorty ====================
function lzNanArr(n){return new Array(n).fill(NaN);}
function lzEmaA(a,p){
    const n=a.length,r=lzNanArr(n),k=2/(p+1);let prev=NaN;
    for(let i=0;i<n;i++){
        const v=a[i];
        if(!isFinite(v))continue;
        prev=isFinite(prev)?k*v+(1-k)*prev:v;
        r[i]=prev;
    }
    return r;
}
function lzSmaA(a,p){
    const n=a.length,r=lzNanArr(n);
    for(let i=p-1;i<n;i++){
        let s=0,ok=true;
        for(let j=i-p+1;j<=i;j++){if(!isFinite(a[j])){ok=false;break;}s+=a[j];}
        if(ok)r[i]=s/p;
    }
    return r;
}
function lzRmaA(a,p){
    const n=a.length,r=lzNanArr(n);let prev=NaN,cnt=0,sum=0;
    for(let i=0;i<n;i++){
        const v=a[i];
        if(!isFinite(v))continue;
        if(!isFinite(prev)){cnt++;sum+=v;if(cnt===p){prev=sum/p;r[i]=prev;}}
        else{prev=(prev*(p-1)+v)/p;r[i]=prev;}
    }
    return r;
}
function lzRsiA(src,len){
    const n=src.length,up=lzNanArr(n),dn=lzNanArr(n),r=lzNanArr(n);
    for(let i=1;i<n;i++){const ch=src[i]-src[i-1];up[i]=Math.max(ch,0);dn[i]=Math.max(-ch,0);}
    const u=lzRmaA(up,len),w=lzRmaA(dn,len);
    for(let i=0;i<n;i++){
        if(!isFinite(u[i])||!isFinite(w[i]))continue;
        r[i]=w[i]===0?100:(u[i]===0?0:100-100/(1+u[i]/w[i]));
    }
    return r;
}
function lzCciA(src,len){
    const n=src.length,sma=lzSmaA(src,len),r=lzNanArr(n);
    for(let i=len-1;i<n;i++){
        if(!isFinite(sma[i]))continue;
        let dev=0;
        for(let j=i-len+1;j<=i;j++)dev+=Math.abs(src[j]-sma[i]);
        dev/=len;
        r[i]=dev===0?0:(src[i]-sma[i])/(0.015*dev);
    }
    return r;
}
function lzNormalizeA(a,mn,mx){
    const n=a.length,r=lzNanArr(n);let hmin=1e11,hmax=-1e11;
    for(let i=0;i<n;i++){
        const v=a[i];
        if(!isFinite(v))continue;
        if(v<hmin)hmin=v;
        if(v>hmax)hmax=v;
        r[i]=mn+(mx-mn)*(v-hmin)/Math.max(hmax-hmin,10e-10);
    }
    return r;
}
function lzAdxA(d,len,prevSrc){
    const n=d.length,dx=lzNanArr(n);
    let trS=0,dmpS=0,dmnS=0;
    for(let i=0;i<n;i++){
        const h=d[i].high,l=d[i].low;
        const pc=i>0?(prevSrc?prevSrc[i-1]:d[i-1].close):0;
        const ph=i>0?d[i-1].high:0,pl=i>0?d[i-1].low:0;
        const tr=Math.max(Math.max(h-l,Math.abs(h-pc)),Math.abs(l-pc));
        const dmp=(h-ph>pl-l)?Math.max(h-ph,0):0;
        const dmn=(pl-l>h-ph)?Math.max(pl-l,0):0;
        trS=trS-trS/len+tr;dmpS=dmpS-dmpS/len+dmp;dmnS=dmnS-dmnS/len+dmn;
        const dip=dmpS/trS*100,din=dmnS/trS*100;
        dx[i]=Math.abs(dip-din)/(dip+din)*100;
    }
    return lzSmaA(dx,len);
}
function lzFeatureA(type,pa,pb,d,hlc3,close){
    const n=d.length;
    if(type==='RSI')return lzEmaA(lzRsiA(close,pa),pb).map(function(v){return isFinite(v)?v/100:NaN;});
    if(type==='CCI')return lzNormalizeA(lzEmaA(lzCciA(hlc3,pa),pb),0,1);
    if(type==='WT'){
        const e1=lzEmaA(hlc3,pa);
        const e2=lzEmaA(e1.map(function(v,i){return Math.abs(hlc3[i]-v);}),pa);
        const ci=hlc3.map(function(v,i){return (v-e1[i])/(0.015*e2[i]);});
        const wt1=lzEmaA(ci,pb),wt2=lzSmaA(wt1,4);
        return lzNormalizeA(wt1.map(function(v,i){return v-wt2[i];}),0,1);
    }
    if(type==='ADX')return lzAdxA(d,pa,null).map(function(v){return isFinite(v)?v/100:NaN;});
    return lzNanArr(n);
}
function lzRegimeA(src,d,thr){
    const n=src.length,flag=new Array(n).fill(false),slope=lzNanArr(n);
    let v1=0,v2=0,klPrev=0;
    for(let i=0;i<n;i++){
        v1=i>0?0.2*(src[i]-src[i-1])+0.8*v1:0;
        v2=0.1*(d[i].high-d[i].low)+0.8*v2;
        const om=Math.abs(v1/v2);
        const alpha=(-om*om+Math.sqrt(Math.pow(om,4)+16*om*om))/8;
        const kl=alpha*src[i]+(1-alpha)*klPrev;
        if(i>0)slope[i]=Math.abs(kl-klPrev);
        klPrev=kl;
    }
    const ema=lzEmaA(slope,200);
    for(let i=0;i<n;i++){
        if(!isFinite(slope[i])||!isFinite(ema[i])||ema[i]===0)continue;
        flag[i]=((slope[i]-ema[i])/ema[i])>=thr;
    }
    return flag;
}
function lzKernelA(src,h,r,x,kind){
    const n=src.length,out=lzNanArr(n),L=x+1,w=new Array(L+1);
    let cw=0;
    for(let i=0;i<=L;i++){
        w[i]=kind==='rq'?Math.pow(1+(i*i)/(h*h*2*r),-r):Math.exp(-(i*i)/(2*h*h));
        cw+=w[i];
    }
    for(let t=L;t<n;t++){
        let s=0;
        for(let i=0;i<=L;i++)s+=src[t-i]*w[i];
        out[t]=s/cw;
    }
    return out;
}
let LZ_CACHE={key:'',res:null};
function calcLorentzian(d,s){
    const n=d?d.length:0;
    if(n<2)return calcLorentzianRaw(d,s);
    const ks=[];
    Object.keys(s).forEach(function(k){if(k.indexOf('lz_')===0||k==='dirMode'||k==='arrowSize')ks.push(k+'='+s[k]);});
    const key=ks.join('|')+'#'+n+'#'+d[0].time+'#'+d[n-1].time+'#'+d[n-1].close+'#'+d[n-1].high+'#'+d[n-1].low;
    if(LZ_CACHE.key===key&&LZ_CACHE.res)return LZ_CACHE.res;
    const r=calcLorentzianRaw(d,s);
    LZ_CACHE={key:key,res:r};
    return r;
}
function calcLorentzianRaw(d,s){
    const n=d?d.length:0;
    const res={trades:[],markers:[],up:[],dn:[],stats:pfEmptyStats(),open:null,lastDir:0,htfNow:[],htfTfs:[],filtered:{regime:0,htf:0,vol:0,score:0},engine:'LDC',last:null};
    if(n<120)return res;
    const gi=function(v,def,mn){const x=parseInt(v);return isNaN(x)?def:Math.max(mn,x);};
    const gf=function(v,def){const x=parseFloat(v);return isNaN(x)?def:x;};
    const K=gi(s.lz_k,8,1),maxBars=gi(s.lz_maxBars,2000,50),fc=Math.min(5,gi(s.lz_fc,5,2));
    const hlc3=d.map(function(c){return (c.high+c.low+c.close)/3;}),close=d.map(function(c){return c.close;}),ohlc4=d.map(function(c){return (c.open+c.high+c.low+c.close)/4;});
    const src=hlc3;
    // ---- فیچرها ----
    const F=[];
    for(let k=1;k<=fc;k++){
        const ty=s['lz_f'+k+'t']||'RSI',pa=gi(s['lz_f'+k+'a'],14,1),pb=gi(s['lz_f'+k+'b'],1,1);
        F.push(Float64Array.from(lzFeatureA(ty,pa,pb,d,hlc3,close)));
    }
    // ---- فیلترها ----
    const tr=new Array(n);
    for(let i=0;i<n;i++){const pc=i>0?d[i-1].close:d[i].close;tr[i]=Math.max(d[i].high-d[i].low,Math.abs(d[i].high-pc),Math.abs(d[i].low-pc));}
    const atr10=lzRmaA(tr,10),atr14=lzRmaA(tr,14);
    const regimeF=lzRegimeA(ohlc4,d,gf(s.lz_regimeThr,-0.1));
    const adxF=s.lz_adx?lzAdxA(d,14,hlc3):null,adxThr=gf(s.lz_adxThr,20);
    const emaA=s.lz_ema?lzEmaA(close,gi(s.lz_emaP,200,2)):null,smaA=s.lz_sma?lzSmaA(close,gi(s.lz_smaP,200,2)):null;
    // ---- کرنل ----
    const h=gi(s.lz_h,8,3),r=gf(s.lz_r,8),x=gi(s.lz_x,25,0),lag=gi(s.lz_lag,2,0);
    const y1=lzKernelA(src,h,r,x,'rq'),y2=lzKernelA(src,Math.max(1,h-lag),r,x,'g');
    // ---- برچسب‌ها ----
    const forward=(s.lz_label!=='literal');
    const lab=new Int8Array(n);
    for(let j=0;j<n;j++){
        if(forward){if(j+4<n)lab[j]=src[j+4]>src[j]?1:(src[j+4]<src[j]?-1:0);}
        else if(j>=4)lab[j]=src[j-4]<src[j]?-1:(src[j-4]>src[j]?1:0);
    }
    // ---- شروع محاسبه ----
    let tStart=60;
    for(let k=0;k<fc;k++){let f0=0;while(f0<n&&!isFinite(F[k][f0]))f0++;tStart=Math.max(tStart,f0+30);}
    tStart=Math.max(tStart,x+5);
    const pred=new Int16Array(n),sig=new Int8Array(n),chg=new Uint8Array(n);
    const startL=new Uint8Array(n),startS=new Uint8Array(n),bearCh=new Uint8Array(n),bullCh=new Uint8Array(n),bullRate=new Uint8Array(n);
    const full=!!s.lz_fullHist,lag4=forward?4:0,jLow=forward?0:4;
    const Fa=F[0],Fb=F[1],Fc=F[2],Fd=F[3],Fe=F[4];
    const dists=[],preds=[];
    const useK=!!s.lz_kernel,smooth=!!s.lz_kernelSmooth;
    for(let t=tStart;t<n;t++){
        // --- پیش‌بینی ML (فاصله لورنتزی + انتخاب همسایه‌ها) ---
        const jMax=t-lag4,jMin=full?jLow:Math.max(jLow,jMax-maxBars+1);
        dists.length=0;preds.length=0;
        let last=-1;
        for(let j=jMin;j<=jMax;j++){
            if((j&3)===0)continue;
            let dd;
            if(fc===5)dd=Math.log((1+Math.abs(Fa[t]-Fa[j]))*(1+Math.abs(Fb[t]-Fb[j]))*(1+Math.abs(Fc[t]-Fc[j]))*(1+Math.abs(Fd[t]-Fd[j]))*(1+Math.abs(Fe[t]-Fe[j])));
            else{dd=0;for(let k=0;k<fc;k++)dd+=Math.log(1+Math.abs(F[k][t]-F[k][j]));}
            if(!(dd>=0))continue;
            if(dd>=last){
                last=dd;dists.push(dd);preds.push(lab[j]);
                if(preds.length>K){last=dists[Math.round(K*3/4)];dists.shift();preds.shift();}
            }
        }
        let pr=0;for(let q=0;q<preds.length;q++)pr+=preds[q];
        pred[t]=pr;
        // --- فیلترها ---
        const volOk=!s.lz_vol||(isFinite(atr10[t])&&tr[t]>atr10[t]);
        const regOk=!s.lz_regime||regimeF[t];
        const adxOk=!s.lz_adx||(isFinite(adxF[t])&&adxF[t]>adxThr);
        const all=volOk&&regOk&&adxOk;
        const prevS=sig[t-1];
        sig[t]=(pr>0&&all)?1:((pr<0&&all)?-1:prevS);
        chg[t]=sig[t]!==prevS?1:0;
        // --- روند EMA/SMA و کرنل ---
        const emaUp=!emaA||close[t]>emaA[t],emaDn=!emaA||close[t]<emaA[t];
        const smaUp=!smaA||close[t]>smaA[t],smaDn=!smaA||close[t]<smaA[t];
        const k1=y1[t],k0=y1[t-1],kk=y1[t-2];
        bullRate[t]=(isFinite(k1)&&isFinite(k0)&&k0<k1)?1:0;
        const bearRate=(isFinite(k1)&&isFinite(k0)&&k0>k1);
        const wasBull=(isFinite(k0)&&isFinite(kk)&&kk<k0),wasBear=(isFinite(k0)&&isFinite(kk)&&kk>k0);
        bearCh[t]=(bearRate&&wasBull)?1:0;
        bullCh[t]=(bullRate[t]&&wasBear)?1:0;
        const bullK=useK?(smooth?(isFinite(y2[t])&&isFinite(k1)&&y2[t]>=k1):bullRate[t]===1):true;
        const bearK=useK?(smooth?(isFinite(y2[t])&&isFinite(k1)&&y2[t]<=k1):bearRate):true;
        startL[t]=(chg[t]&&sig[t]===1&&emaUp&&smaUp&&bullK)?1:0;
        startS[t]=(chg[t]&&sig[t]===-1&&emaDn&&smaDn&&bearK)?1:0;
    }
    // ---- معاملات: ورود روی فلیپ سیگنال، خروج بعد از ۴ کندل یا فلیپ زودهنگام ----
    const dynMode=!!s.lz_dyn&&!s.lz_ema&&!s.lz_sma&&!smooth;
    const dirMode=s.dirMode||'both';
    let pos=null;
    const mk=function(p,idx,oc){
        const px=d[idx].close,R=p.m*(px-p.entry)/p.risk;
        return {dir:p.m>0?'long':'short',type:'LDC',score:Math.min(10,Math.abs(p.pred)),pred:p.pred,entryIdx:p.entryIdx,entryTime:d[p.entryIdx].time,entry:p.entry,
            sl0:NaN,sl:NaN,tp1:NaN,tp2:NaN,risk:p.risk,exitIdx:idx,exitTime:d[idx].time,exitPrice:px,R:R,outcome:oc,tp1Hit:false,tp1Idx:-1,bars:idx-p.entryIdx,open:oc==='open'};
    };
    for(let t=tStart;t<n;t++){
        if(pos){
            const m=pos.m,held=t-pos.entryIdx;
            let oc=null;
            if(dynMode&&(m>0?bearCh[t]:bullCh[t])&&held>=1)oc='kex';
            else if(!dynMode&&held>=4)oc='ex4';
            else if(chg[t]&&sig[t]===-m)oc='rev';
            if(oc){res.trades.push(mk(pos,t,oc));pos=null;}
        }
        if(!pos){
            const m=startL[t]?1:(startS[t]?-1:0);
            if(m!==0&&!(m>0&&dirMode==='short')&&!(m<0&&dirMode==='long')&&isFinite(atr14[t])&&atr14[t]>0){
                pos={m:m,entryIdx:t,entry:close[t],risk:atr14[t],pred:pred[t]};
            }
        }
    }
    if(pos){const tt=mk(pos,n-1,'open');res.trades.push(tt);res.open=tt;res.lastDir=pos.m;}
    // ---- خطوط کرنل (سبز = شیب صعودی، قرمز = شیب نزولی) ----
    if(s.lz_kernelShow){
        const upM=new Uint8Array(n),dnM=new Uint8Array(n);
        for(let i=Math.max(1,tStart);i<n;i++){
            if(!isFinite(y1[i])||!isFinite(y1[i-1]))continue;
            if(y1[i-1]<y1[i]){upM[i-1]=1;upM[i]=1;}else{dnM[i-1]=1;dnM[i]=1;}
        }
        for(let i=0;i<n;i++){
            res.up.push(upM[i]?{time:d[i].time,value:y1[i]}:{time:d[i].time});
            res.dn.push(dnM[i]?{time:d[i].time,value:y1[i]}:{time:d[i].time});
        }
    }
    pfBuildMarkersAndStats(res,d,s);
    // ---- نشانگرها ----
    const asz=Math.max(1,Math.min(5,parseFloat(s.arrowSize)||2));
    const mks=[];
    res.trades.forEach(function(tr2){
        const long=tr2.dir==='long';
        mks.push({time:tr2.entryTime,position:long?'belowBar':'aboveBar',color:long?'#00e676':'#ff1744',shape:long?'arrowUp':'arrowDown',size:asz,text:'LDC '+(long?'BUY ':'SELL ')+(tr2.pred>=0?'+':'')+tr2.pred});
        if(s.lz_showExits&&!tr2.open){
            const col=tr2.R>0.0001?'#00e676':(tr2.R<-0.0001?'#ff5252':'#ffd54f');
            mks.push({time:tr2.exitTime,position:long?'aboveBar':'belowBar',color:col,shape:'square',size:Math.max(1,asz*0.6),text:pfOutcomeTag(tr2.outcome)});
        }
    });
    if(s.lz_showPred){
        for(let i=Math.max(tStart,n-150);i<n;i++){
            mks.push({time:d[i].time,position:pred[i]>=0?'belowBar':'aboveBar',color:pred[i]>0?'#00e676':(pred[i]<0?'#ff5252':'#9e9e9e'),shape:'circle',size:0.1,text:String(pred[i])});
        }
    }
    mks.sort(function(a,b){return a.time-b.time;});
    res.markers=mks;
    res.last={pred:pred[n-1],signal:sig[n-1],kernelUp:bullRate[n-1]===1};
    return res;
}

function pfReadSettingsFromUI(){
    PF_FIELDS.forEach(function(f){
        const el=document.getElementById(f.id);
        if(!el)return;
        if(f.t==='chk'){pfSettings[f.k]=!!el.checked;return;}
        if(f.t==='sel'){pfSettings[f.k]=el.value;return;}
        let v=f.t==='int'?parseInt(el.value):parseFloat(el.value);
        if(isNaN(v))return;
        if(f.min!==undefined&&v<f.min)v=f.min;
        pfSettings[f.k]=v;
    });
    const pe=document.getElementById('setPfPreset');
    if(pe)pfSettings.preset=pe.value;
}

function pfWriteSettingsToUI(){
    PF_FIELDS.forEach(function(f){
        const el=document.getElementById(f.id);
        if(!el)return;
        if(f.t==='chk')el.checked=!!pfSettings[f.k];
        else el.value=pfSettings[f.k];
    });
    const pe=document.getElementById('setPfPreset');
    if(pe)pe.value=pfSettings.preset||'balanced';
}

function pfPresetChanged(v){
    if(!PF_PRESETS[v])return;
    Object.assign(pfSettings,PF_PRESETS[v]);
    pfSettings.preset=v;
    pfWriteSettingsToUI();
    applySettings();
}

function pfFmtPf(v){return v===Infinity?'∞':v.toFixed(2);}
function pfFmtPrice(p){return p>=100?p.toFixed(2):(p>=1?p.toFixed(4):p.toFixed(6));}

// ---------- تایم‌فریم تایید (HTF) ----------
const pfHtfCache={};
function pfResolveHtfList(mainTf,s){
    const mainSec=PF_TF_SEC[mainTf];
    const out=[];
    if(!mainSec||s.htfMode==='off')return out;
    const auto=PF_HTF_AUTO[mainTf]||[];
    [s.htfTf1,s.htfTf2].forEach(function(v,idx){
        if(!v||v==='off')return;
        const tf=(v==='auto')?auto[idx]:v;
        if(!tf||!PF_TF_SEC[tf]||PF_TF_SEC[tf]<=mainSec)return;
        if(out.indexOf(tf)<0)out.push(tf);
    });
    return out;
}
async function pfFetchHtf(symbol,tf,spanSec){
    const limit=Math.min(3000,Math.max(300,Math.ceil(spanSec/PF_TF_SEC[tf])+300));
    const res=await fetch('/api/candles?symbol='+encodeURIComponent(symbol)+'&timeframe='+tf+'&limit='+limit);
    const j=await res.json();
    if(!j.success||!j.data||!j.data.length)throw new Error('no data');
    return j.data.filter(function(c){return c&&c.close>0;}).sort(function(a,b){return a.time-b.time;});
}
// برای نمودار: از کش استفاده می‌کند و در پس‌زمینه تازه‌سازی می‌کند. waiting = تایم‌فریم‌هایی که هنوز دیتایشان نیامده
function pfGetHtf(symbol,tf,d,s,onReady){
    const out={biases:[],tfs:[],waiting:[],failed:[]};
    const mainSec=PF_TF_SEC[tf];
    if(!mainSec)return out;
    pfResolveHtfList(tf,s).forEach(function(h){
        const key=symbol+'|'+h;
        const c=pfHtfCache[key];
        if(!c||(!c.pending&&Date.now()-c.ts>30000)){
            const prev=c&&c.candles?c.candles:null;
            pfHtfCache[key]={ts:c?c.ts:0,candles:prev,pending:true,err:null};
            pfFetchHtf(symbol,h,d.length*mainSec).then(function(cd){
                pfHtfCache[key]={ts:Date.now(),candles:cd,pending:false,err:null};
                if(onReady)onReady();
            }).catch(function(e){
                pfHtfCache[key]={ts:Date.now(),candles:prev,pending:false,err:String(e&&e.message||e)};
                if(onReady)onReady();
            });
        }
        const cc=pfHtfCache[key];
        if(cc&&cc.candles){
            const b=pfHtfBiasFor(d,cc.candles,mainSec,PF_TF_SEC[h],Object.assign({},s,{htfName:h}));
            if(b){out.biases.push(b);out.tfs.push(h);}else out.failed.push(h);
        }else if(cc&&cc.err)out.failed.push(h);
        else out.waiting.push(h);
    });
    return out;
}
// برای بک‌تست: مستقیم دریافت می‌کند
async function pfBtHtf(symbol,tf,d,s){
    const out={biases:[],tfs:[],waiting:[],failed:[]};
    const mainSec=PF_TF_SEC[tf];
    if(!mainSec)return out;
    const list=pfResolveHtfList(tf,s);
    for(let q=0;q<list.length;q++){
        const h=list[q];
        try{
            const hc=await pfFetchHtf(symbol,h,d.length*mainSec);
            const b=pfHtfBiasFor(d,hc,mainSec,PF_TF_SEC[h],Object.assign({},s,{htfName:h}));
            if(b){out.biases.push(b);out.tfs.push(h);}else out.failed.push(h);
        }catch(e){out.failed.push(h);}
    }
    return out;
}
// اگر آخرین کندل هنوز بسته نشده (در حال شکل‌گیری)، از موتور حذف می‌شود تا سیگنال ریپینت نداشته باشد
function pfEngineData(d,tf,s){
    if(!s.closedOnly||!d||!d.length)return d;
    const sec=PF_TF_SEC[tf];
    if(!sec)return d;
    return (d[d.length-1].time+sec>Date.now()/1000)?d.slice(0,-1):d;
}

function pfRemoveSeries(){
    pfLineSeries.forEach(function(s){try{chart.removeSeries(s);}catch(e){}});
    pfLineSeries=[];
    pfLevelSeries.forEach(function(s){try{chart.removeSeries(s);}catch(e){}});
    pfLevelSeries=[];
    pfPriceLines.forEach(function(p){try{candleSeries.removePriceLine(p);}catch(e){}});
    pfPriceLines=[];
}

function pfHideCard(){
    const card=document.getElementById('pfCard');
    if(card){card.classList.remove('show');card.innerHTML='';}
}

function pfToggleCard(){
    const card=document.getElementById('pfCard');
    if(card)card.classList.toggle('mini');
}

function pfUpdateCard(res,htfInfo){
    const card=document.getElementById('pfCard');
    if(!card)return;
    if(!pfSettings.showCard||!res){pfHideCard();return;}
    const s=res.stats;
    const row=function(k,v,c){return '<div class="pfRow"><span>'+k+'</span><span class="'+(c||'')+'">'+v+'</span></div>';};
    const wrCls=s.winRate>=50?'pfBuy':'pfSell';
    const isL=res.engine==='LDC';
    let h='<div class="pfTitle" onclick="pfToggleCard()">'+(isL?'🧠 Lorentzian ML':'🚀 Pro F')+' | برد '+s.winRate.toFixed(0)+'% از '+s.trades+' معامله</div><div class="pfBody">';
    h+='<div class="pfWin"><div class="pfWinBig '+wrCls+'">'+s.winRate.toFixed(1)+'%</div><div class="pfWinSub">وین‌ریت همه معاملات انجام‌شده<br>'+s.wins+' برد | '+s.losses+' باخت | '+s.be+' سر به سر</div></div>';
    if(htfInfo&&(htfInfo.tfs.length||htfInfo.waiting.length||htfInfo.failed.length)){
        let t='تایید تایم‌فریم: ';
        htfInfo.tfs.forEach(function(tf,i){
            const b=res.htfNow[i];
            t+=tf+' '+(b>0?'<b class="pfBuy">▲</b>':(b<0?'<b class="pfSell">▼</b>':'<b>—</b>'))+' ';
        });
        htfInfo.waiting.forEach(function(tf){t+=tf+' ⏳ ';});
        htfInfo.failed.forEach(function(tf){t+=tf+' ⚠️ ';});
        h+='<div class="pfOpen">'+t+'</div>';
    }
    if(res.open&&res.open.type==='LDC'){
        const o=res.open,m=o.dir==='long'?1:-1,pnl=m*(o.exitPrice-o.entry)/o.entry*100;
        h+='<div class="pfOpen"><b class="'+(o.dir==='long'?'pfBuy':'pfSell')+'">'+(o.dir==='long'?'خرید (LONG)':'فروش (SHORT)')+'</b> باز | پیش‌بینی ML: '+(o.pred>=0?'+':'')+o.pred+'</div>';
        h+=row('ورود',pfFmtPrice(o.entry));
        h+=row('کندل‌های نگهداری',o.bars+' از 4');
        h+=row('سود/زیان فعلی',(pnl>=0?'+':'')+pnl.toFixed(2)+'%',pnl>=0?'pfBuy':'pfSell');
    }else if(res.open){
        const o=res.open;
        h+='<div class="pfOpen"><b class="'+(o.dir==='long'?'pfBuy':'pfSell')+'">'+(o.dir==='long'?'خرید (LONG)':'فروش (SHORT)')+'</b> باز | امتیاز '+o.score+'/10</div>';
        h+=row('ورود',pfFmtPrice(o.entry));
        h+=row('حد ضرر',pfFmtPrice(o.sl),'pfSell');
        h+=row('TP1'+(o.tp1Hit?' ✓':''),pfFmtPrice(o.tp1),'pfBuy');
        h+=row('TP2',pfSettings.rr2<=5?pfFmtPrice(o.tp2):'بدون سقف (تریلینگ)','pfBuy');
        h+=row('سود/زیان فعلی',(o.R>=0?'+':'')+o.R.toFixed(2)+'R',o.R>=0?'pfBuy':'pfSell');
    }else{
        h+='<div class="pfOpen">بدون معامله باز (منتظر سیگنال)</div>';
    }
    h+=row('برد بدون سر به سر',s.winRateNoBE.toFixed(0)+'%');
    if(!isL)h+=row('رسیدن به TP1',s.tp1Rate.toFixed(0)+'%');
    h+=row('Profit Factor',pfFmtPf(s.pf),s.pf>=1?'pfBuy':'pfSell');
    h+=row('جمع سود/زیان',(s.totalR>=0?'+':'')+s.totalR.toFixed(1)+'R',s.totalR>=0?'pfBuy':'pfSell');
    h+=row('میانگین هر معامله',(s.avgR>=0?'+':'')+s.avgR.toFixed(2)+'R');
    h+=row('حداکثر افت',s.maxDD.toFixed(1)+'R','pfSell');
    if(pfSettings.useProfile&&PF_TF_PROFILES[currentTimeframe])h+='<div class="pfFilt">🧬 پروفایل بهینه '+currentTimeframe+' فعال</div>';
    if(isL&&res.last){h+='<div class="pfFilt">آخرین پیش‌بینی: '+(res.last.pred>=0?'+':'')+res.last.pred+' | سیگنال: '+(res.last.signal>0?'خرید':(res.last.signal<0?'فروش':'—'))+' | کرنل: '+(res.last.kernelUp?'صعودی':'نزولی')+'</div>';}
    const f=res.filtered;
    if(!isL)h+='<div class="pfFilt">رد‌شده با فیلتر: رژیم '+f.regime+' | تایم‌فریم '+f.htf+' | امتیاز '+f.score+' | نوسان '+f.vol+'</div>';
    h+='</div>';
    card.innerHTML=h;
    card.classList.add('show');
}

function drawProF(d){
    if(!chart||!candleSeries)return null;
    try{
        const s=Object.assign({},pfSettings,pfProfileFor(currentTimeframe),{tf:currentTimeframe});
        const symbol=currentSymbol,tf=currentTimeframe;
        const htfInfo=(s.setup==='lorentzian')?{tfs:[],waiting:[],failed:[],biases:[]}:pfGetHtf(symbol,tf,d,s,function(){
            if(pfEnabled&&currentSymbol===symbol&&currentTimeframe===tf&&currentCandles.length)drawProF(currentCandles);
        });
        // تا رسیدن دیتای تایم‌فریم تایید، سیگنال بدون فیلتر نمایش داده نمی‌شود
        if(htfInfo.waiting.length){
            pfRemoveSeries();
            pfResult=null;
            updateAllMarkers();
            const card=document.getElementById('pfCard');
            if(card&&pfSettings.showCard){card.innerHTML='<div class="pfTitle">🚀 Pro F</div><div class="pfBody">⏳ در حال دریافت تایم‌فریم تایید: '+htfInfo.waiting.join(', ')+'</div>';card.classList.add('show');}
            return null;
        }
        pfRemoveSeries();
        const ed=pfEngineData(d,tf,s);
        pfResult=calcProF(ed,s,htfInfo);
        if(pfSettings.showLine){
            const up=chart.addLineSeries({color:'rgba(0,230,118,0.85)',lineWidth:2,priceLineVisible:false,lastValueVisible:false,crosshairMarkerVisible:false});
            up.setData(pfResult.up);
            const dn=chart.addLineSeries({color:'rgba(255,23,68,0.85)',lineWidth:2,priceLineVisible:false,lastValueVisible:false,crosshairMarkerVisible:false});
            dn.setData(pfResult.dn);
            pfLineSeries.push(up,dn);
        }
        if(pfSettings.showLevels){
            const lastTime=ed[ed.length-1].time;
            const list=pfResult.trades.slice(-Math.max(1,pfSettings.maxLevels||8));
            list.forEach(function(t){
                const x1=t.open?lastTime:t.exitTime;
                if(x1<=t.entryTime)return;
                const mk=function(price,color,style){
                    const sr=chart.addLineSeries({color:color,lineWidth:1,lineStyle:style,priceLineVisible:false,lastValueVisible:false,crosshairMarkerVisible:false});
                    sr.setData([{time:t.entryTime,value:price},{time:x1,value:price}]);
                    pfLevelSeries.push(sr);
                };
                mk(t.entry,'rgba(255,255,255,0.55)',1);
                if(t.type==='LDC')return;
                mk(t.sl0,'rgba(255,82,82,0.9)',2);
                mk(t.tp1,'rgba(105,240,174,0.9)',2);
                if(pfSettings.rr2<=5)mk(t.tp2,'rgba(0,230,118,0.9)',2);
            });
        }
        if(pfResult.open){
            const o=pfResult.open;
            pfPriceLines.push(candleSeries.createPriceLine({price:o.entry,color:'#ffffff',lineWidth:1,lineStyle:0,title:'PF ورود'}));
            if(o.type!=='LDC'){
            pfPriceLines.push(candleSeries.createPriceLine({price:o.sl,color:'#ff5252',lineWidth:2,lineStyle:3,title:'PF SL'}));
            if(!o.tp1Hit)pfPriceLines.push(candleSeries.createPriceLine({price:o.tp1,color:'#69f0ae',lineWidth:1,lineStyle:2,title:'PF TP1'}));
            if(pfSettings.rr2<=5)pfPriceLines.push(candleSeries.createPriceLine({price:o.tp2,color:'#00e676',lineWidth:1,lineStyle:2,title:'PF TP2'}));
            }
        }
        updateAllMarkers();
        pfUpdateCard(pfResult,htfInfo);
        const st=pfResult.stats;
        console.log('=== Pro F: '+st.trades+' معامله | برد '+st.winRate.toFixed(0)+'% | PF '+pfFmtPf(st.pf)+' | جمع '+st.totalR.toFixed(1)+'R ===');
        return pfResult;
    }catch(err){
        console.error('خطای کلی در drawProF:',err);
        return null;
    }
}

function removeProF(){
    pfResult=null;
    pfRemoveSeries();
    pfHideCard();
}


// ==================== سیستم امتیازدهی هوشمند (Smart Weighting) ====================
// این سیستم خودش یاد می‌گیره کدوم اندیکاتور در شرایط فعلی بازار بهتر کار می‌کنه
// و وزن اون رو بیشتر می‌کنه. مثلاً اگه P3 و P4 (ML-based) توی روند بهتر عمل کنن، وزنشون بیشتر می‌شه.

let smartWeights = {
    1: 1.0,  // P1: FVG
    2: 1.0,  // P2: Impulse
    3: 1.2,  // P3: ML SuperTrend (پیش‌فرض کمی بیشتر چون ML-based)
    4: 1.2,  // P4: Lorentzian (پیش‌فرض کمی بیشتر چون ML-based)
    5: 1.0,  // P5: Pro Scalper
    6: 1.0,  // P6: Breakout
    7: 1.0   // P7: Swift Algo
};

let smartWeightHistory = [];  // تاریخچه برای نمایش

function updateSmartWeights(performanceData) {
    // performanceData: {1: {winRate: 55, total: 20}, 2: {...}, ...}
    // محاسبه میانگین وین‌ریت
    let totalWinRate = 0;
    let count = 0;
    Object.keys(performanceData).forEach(key => {
        const p = performanceData[key];
        if (p.total >= 5) {  // حداقل 5 معامله برای اعتبار
            totalWinRate += p.winRate;
            count++;
        }
    });
    const avgWinRate = count > 0 ? totalWinRate / count : 50;

    // تنظیم وزن‌ها بر اساس عملکرد نسبت به میانگین
    Object.keys(performanceData).forEach(key => {
        const p = performanceData[key];
        if (p.total >= 5) {
            const diff = p.winRate - avgWinRate;
            // هر 10٪ اختلاف = 0.2 تغییر وزن
            const adjustment = Math.max(-0.5, Math.min(0.5, diff / 50));
            smartWeights[key] = Math.max(0.5, Math.min(2.0, 1.0 + adjustment));
        }
    });

    smartWeightHistory.push({
        time: Date.now(),
        weights: Object.assign({}, smartWeights)
    });

    // نگه‌داری فقط ۱۰۰ رکورد آخر
    if (smartWeightHistory.length > 100) {
        smartWeightHistory = smartWeightHistory.slice(-100);
    }

    console.log('🧠 وزن‌های هوشمند به‌روزرسانی شد:', smartWeights);
    return smartWeights;
}

// تابع برای دریافت عملکرد هر اندیکاتور (باید از بک‌تست استفاده بشه)
function calculateIndicatorPerformance(symbol, timeframe) {
    // این تابع باید با دیتای واقعی صدا زده بشه
    // فعلاً یه ساختار نمونه برمی‌گردونه
    return new Promise((resolve) => {
        // شبیه‌سازی محاسبه بر اساس دیتای اخیر
        const performance = {};
        for (let i = 1; i <= 7; i++) {
            performance[i] = {
                winRate: 45 + Math.random() * 20,  // 45-65٪ (این باید از بک‌تست واقعی بیاد)
                total: 10 + Math.floor(Math.random() * 30)
            };
        }
        resolve(performance);
    });
}

// اعمال وزن‌های هوشمند روی lzWeights
function applySmartWeights() {
    for (let i = 1; i <= 7; i++) {
        if (smartWeights[i]) {
            lzWeights[i] = smartWeights[i];
            const el = document.getElementById('lzW' + i);
            if (el) el.value = smartWeights[i];
        }
    }
    console.log('✅ وزن‌های هوشمند اعمال شد');
}

// تابع اصلی برای به‌روزرسانی خودکار
async function autoUpdateSmartWeights() {
    const perf = await calculateIndicatorPerformance(currentSymbol, currentTimeframe);
    updateSmartWeights(perf);
    applySmartWeights();
    if (lzAllEnabled) {
        lzAllRedraw(true);
    }
}

// ==================== P1: FVG Order Blocks [BigBeluga] ====================
// بازسازی مستقیم از سورس Pine اصلی (v5، © BigBeluga، CC BY-NC-SA 4.0)
let fvgEnabled=false;
let fvgResult=null;
let fvgPrimitive=null;

function fvgReadSettings(){
    const g=function(id,def){const e=document.getElementById(id);return e?e.value:def;};
    const c=function(id,def){const e=document.getElementById(id);return e?e.checked:def;};
    let mp=parseFloat(g('setFvgMinPct','0.5'));if(isNaN(mp)||mp<0)mp=0.5;
    let cnt=parseInt(g('setFvgCount','6'));if(isNaN(cnt)||cnt<1)cnt=6;
    return {filter:mp,boxAmount:cnt,showBroken:c('setFvgBroken',false),showSignal:c('setFvgSignals',false),
            showImb:c('setFvgShowGap',true),bullCol:g('setFvgBullCol','#14be94'),bearCol:g('setFvgBearCol','#c21919')};
}

function calcFvgOB(d,s){
    const n=d.length;
    const LOOKBACK=2000, ATR_LEN=200, MAX_BOXES=500, MAX_LABELS=50;
    // ---- ATR(200) با RMA (قبل از ۲۰۰ کندل: میانگین انبساطی تا به TradingView که تاریخچه‌ی بیشتری دارد نزدیک باشد)
    const atr=new Array(n).fill(NaN);
    let rma=NaN,sum=0;
    for(let i=0;i<n;i++){
        const tr=(i===0)?(d[i].high-d[i].low):Math.max(d[i].high-d[i].low,Math.abs(d[i].high-d[i-1].close),Math.abs(d[i].low-d[i-1].close));
        if(i<ATR_LEN){sum+=tr;rma=sum/(i+1);}
        else rma=(rma*(ATR_LEN-1)+tr)/ATR_LEN;
        atr[i]=rma;
    }
    // ---- فیلترهای گپ
    const fUp=new Array(n).fill(NaN),fDn=new Array(n).fill(NaN);
    for(let i=2;i<n;i++){
        fUp[i]=(d[i].low-d[i-2].high)/d[i].low*100;
        fDn[i]=(d[i-2].low-d[i].high)/d[i-2].low*100;
    }
    const winMax=function(arr,i){let m=-Infinity;for(let k=Math.max(0,i-ATR_LEN+1);k<=i;k++){if(!isNaN(arr[k])&&arr[k]>m)m=arr[k];}return m;};

    const boxes1=new Array(10).fill(null);   // بولیش (array.new<box>(10, na))
    const boxes2=new Array(10).fill(null);   // بریش
    const all=[];let allPtr=0,alive=0;
    const reg=function(b){
        b.alive=true;all.push(b);alive++;
        if(alive>MAX_BOXES){while(allPtr<all.length&&!all[allPtr].alive)allPtr++;if(allPtr<all.length){all[allPtr].alive=false;alive--;allPtr++;}}
    };
    const kill=function(b,arr){
        if(b.alive){b.alive=false;alive--;}
        const k=arr.indexOf(b);if(k>=0)arr.splice(k,1);
    };
    let isBull=false,isBear=false;
    const labels=[],sigs=[];

    for(let i=0;i<n;i++){
        const c=d[i];
        const inLook=(n-1-i)<LOOKBACK;
        if(inLook&&i>=2){
            isBull=(d[i-2].high<c.low)&&(d[i-2].high<d[i-1].high)&&(d[i-2].low<c.low)&&(fUp[i]>s.filter);
            isBear=(d[i-2].low>c.high)&&(d[i-2].low>d[i-1].low)&&(d[i-2].high>c.high)&&(fDn[i]>s.filter);
        }
        // ---- گپ و اوردر بلاک صعودی
        if(isBull){
            const mx=winMax(fUp,i),t=Math.max(0,Math.min(1,mx>0?fUp[i]/mx:0));
            if(s.showImb){
                reg({kind:'gap',dir:1,left:i-1,right:i+5,top:c.low,bottom:d[i-2].high,text:fUp[i].toFixed(2)+'%',a:0.10+0.20*t});
            }
            const b={kind:'ob',dir:1,left:i-1,top:d[i-2].high,bottom:d[i-2].high-atr[i],pct:fUp[i],a:0.30*t,broken:false};
            reg(b);boxes1.push(b);
        }
        // ---- گپ و اوردر بلاک نزولی
        if(isBear){
            const mx=winMax(fDn,i),t=Math.max(0,Math.min(1,mx>0?fDn[i]/mx:0));
            if(s.showImb){
                reg({kind:'gap',dir:-1,left:i-1,right:i+5,top:d[i-2].low,bottom:c.high,text:'-'+fDn[i].toFixed(2)+'%',a:0.10+0.20*t});
            }
            const b={kind:'ob',dir:-1,left:i-1,top:d[i-2].low+atr[i],bottom:d[i-2].low,pct:fDn[i],a:0.30*t,broken:false};
            reg(b);boxes2.push(b);
        }
        // ---- بولیش: شکست / سیگنال / حذف هم‌پوشان
        for(const b of boxes1.slice()){
            if(!b||boxes1.indexOf(b)<0)continue;
            if(c.high<b.bottom){
                b.broken=true;
                if(!s.showBroken){kill(b,boxes1);}
            }
            if(i>=1&&c.low>b.top&&d[i-1].low<=b.top&&!isBull){
                sigs.push({idx:i,dir:1});
                if(s.showSignal)labels.push({idx:i-1,price:d[i-1].low,dir:1});
            }
            for(const b1 of boxes1.slice()){
                if(!b1||boxes1.indexOf(b)<0)break;
                if(b1.top<b.top&&b1.top>b.bottom){kill(b,boxes1);}
            }
        }
        // ---- بریش
        for(const b of boxes2.slice()){
            if(!b||boxes2.indexOf(b)<0)continue;
            if(c.low>b.top){
                b.broken=true;
                if(!s.showBroken){kill(b,boxes2);}
            }
            if(i>=1&&c.high<b.bottom&&d[i-1].high>=b.bottom&&!isBear){
                sigs.push({idx:i,dir:-1});
                if(s.showSignal)labels.push({idx:i-1,price:d[i-1].high,dir:-1});
            }
            for(const b1 of boxes2.slice()){
                if(!b1||boxes2.indexOf(b)<0)break;
                if(b1.top<b.top&&b1.top>b.bottom){kill(b,boxes2);}
            }
        }
        // ---- محدودیت تعداد بلاک‌ها (مثل اسکریپت اصلی: size >= amount => shift)
        if(boxes1.length>=s.boxAmount){const x=boxes1.shift();if(x&&x.alive){x.alive=false;alive--;}}
        if(boxes2.length>=s.boxAmount){const x=boxes2.shift();if(x&&x.alive){x.alive=false;alive--;}}
    }
    const live=[];
    for(const b of all){if(b.alive)live.push(b);}
    return {boxes:live,labels:labels.slice(-MAX_LABELS),signals:sigs,settings:s,n:n,markers:[]};
}

// ---- رسم روی چارت (Series Primitive در lightweight-charts 4.1) ----
class FvgRenderer{
    constructor(p){this._p=p;}
    draw(target){
        const p=this._p;
        if(!p._chart||!p._series||!p._data)return;
        const res=p._data,s=res.settings,ts=p._chart.timeScale(),ser=p._series,n=res.n;
        target.useMediaCoordinateSpace(function(scope){
            const ctx=scope.context,W=scope.mediaSize.width;
            const rgba=function(hex,a){
                const h=hex.replace('#','');
                return 'rgba('+parseInt(h.substr(0,2),16)+','+parseInt(h.substr(2,2),16)+','+parseInt(h.substr(4,2),16)+','+a+')';
            };
            ctx.textBaseline='middle';
            // ترتیب: اول گپ‌ها بعد اوردر بلاک‌ها
            for(const pass of ['gap','ob']){
                for(const b of res.boxes){
                    if(b.kind!==pass)continue;
                    const right=(b.kind==='gap')?b.right:(n-1+15);
                    const x1=ts.logicalToCoordinate(b.left),x2=ts.logicalToCoordinate(right);
                    const y1=ser.priceToCoordinate(b.top),y2=ser.priceToCoordinate(b.bottom);
                    if(x1===null||x2===null||y1===null||y2===null||isNaN(y1)||isNaN(y2))continue;
                    if(x2<0||x1>W)continue;
                    const top=Math.min(y1,y2),h=Math.max(1,Math.abs(y2-y1)),w=Math.max(1,x2-x1);
                    if(b.kind==='gap'){
                        ctx.fillStyle='rgba(255,255,255,'+b.a.toFixed(3)+')';
                        ctx.fillRect(x1,top,w,h);
                        ctx.fillStyle='#ffffff';ctx.font='11px sans-serif';ctx.textAlign='center';
                        ctx.fillText(b.text,x1+w/2,top+h/2);
                    }else{
                        const col=b.dir===1?s.bullCol:s.bearCol;
                        if(b.broken){
                            ctx.fillStyle='rgba(255,255,255,0.15)';
                            ctx.fillRect(x1,top,w,h);
                        }else{
                            ctx.fillStyle=rgba(col,b.a.toFixed(3));
                            ctx.fillRect(x1,top,w,h);
                            ctx.strokeStyle=col;ctx.lineWidth=1;
                            ctx.strokeRect(x1+0.5,top+0.5,w,h);
                        }
                        ctx.fillStyle='#ffffff';ctx.font='10px sans-serif';ctx.textAlign='right';
                        ctx.fillText(b.pct.toFixed(2)+'%',Math.min(x2,W)-4,top+h/2);
                    }
                }
            }
            // لیبل‌های سیگنال (︽ سبز زیر کندل / ﹀ قرمز بالای کندل)
            for(const L of res.labels){
                const x=ts.logicalToCoordinate(L.idx),y=ser.priceToCoordinate(L.price);
                if(x===null||y===null||x<0||x>W)continue;
                ctx.strokeStyle=L.dir===1?s.bullCol:s.bearCol;ctx.lineWidth=2;ctx.lineCap='round';ctx.lineJoin='round';
                ctx.beginPath();
                if(L.dir===1){
                    ctx.moveTo(x-5,y+10);ctx.lineTo(x,y+5);ctx.lineTo(x+5,y+10);
                    ctx.moveTo(x-5,y+16);ctx.lineTo(x,y+11);ctx.lineTo(x+5,y+16);
                }else{
                    ctx.moveTo(x-5,y-10);ctx.lineTo(x,y-5);ctx.lineTo(x+5,y-10);
                    ctx.moveTo(x-5,y-16);ctx.lineTo(x,y-11);ctx.lineTo(x+5,y-16);
                }
                ctx.stroke();
            }
        });
    }
}
class FvgPaneView{
    constructor(p){this._p=p;}
    zOrder(){return 'bottom';}
    renderer(){return new FvgRenderer(this._p);}
}
class FvgPrimitive{
    constructor(){this._data=null;this._chart=null;this._series=null;this._req=null;this._views=[new FvgPaneView(this)];}
    attached(param){this._chart=param.chart;this._series=param.series;this._req=param.requestUpdate;}
    detached(){this._chart=null;this._series=null;this._req=null;}
    paneViews(){return this._views;}
    updateAllViews(){}
    setData(r){this._data=r;if(this._req)this._req();}
}

function fvgRemove(){
    if(fvgPrimitive&&candleSeries){try{candleSeries.detachPrimitive(fvgPrimitive);}catch(e){}}
    fvgPrimitive=null;
    fvgResult=null;
    lzVotes[1]=null;
}

function drawFvgOB(d){
    if(!chart||!candleSeries||!d||d.length<3){return null;}
    try{
        const s=fvgReadSettings();
        fvgResult=calcFvgOB(d,s);
        if(!fvgPrimitive){
            fvgPrimitive=new FvgPrimitive();
            candleSeries.attachPrimitive(fvgPrimitive);
        }
        fvgPrimitive.setData(fvgResult);
        // رأی P1: آخرین سیگنال ریتست (حتی اگر نمایش لیبل خاموش باشد) در ۱۰ کندل اخیر
        const last=fvgResult.signals.length?fvgResult.signals[fvgResult.signals.length-1]:null;
        lzVotes[1]=(last&&last.idx>=d.length-10)?(last.dir===1?'long':'short'):null;
        updateAllMarkers();
        console.log('=== P1 FVG OB: '+fvgResult.boxes.filter(function(b){return b.kind==='ob';}).length+' بلاک | '+fvgResult.signals.length+' سیگنال ===');
        return fvgResult;
    }catch(err){
        console.error('خطای کلی در drawFvgOB:',err);
        return null;
    }
}

function fvgRedraw(){
    if(fvgEnabled&&currentCandles.length>0)drawFvgOB(currentCandles);
}

function toggleFvgOB(){
    fvgEnabled=!fvgEnabled;
    const btn=document.getElementById('btnLzRun1');
    if(fvgEnabled){
        if(btn){btn.classList.add('active');btn.textContent='⏹ حذف';}
        if(currentCandles.length>0)setTimeout(function(){drawFvgOB(currentCandles);},50);
    }else{
        if(btn){btn.classList.remove('active');btn.textContent='▶ اجرا';}
        fvgRemove();
        updateAllMarkers();
    }
}

// ==================== P3: Machine Learning Adaptive SuperTrend [AlgoAlpha] ====================
// بازسازی مستقیم از سورس Pine اصلی (K-Means روی ATR برای انتخاب ATR تطبیقی + SuperTrend)
let mlstEnabled=false;
let mlstResult=null;
let mlstPrimitive=null;

function mlstReadSettings(){
    const g=function(id,def){const e=document.getElementById(id);return e?e.value:def;};
    const f=function(id,def){const v=parseFloat(g(id,def));return isNaN(v)?def:v;};
    const e=document.getElementById('setMlStTable');
    return {atrLen:Math.max(1,Math.round(f('setMlStAtr',10))),fact:f('setMlStFact',3),train:Math.max(10,Math.round(f('setMlStTrain',100))),
            highvol:f('setMlStHigh',0.75),midvol:f('setMlStMid',0.5),lowvol:f('setMlStLow',0.25),
            t1:f('setMlStT1',70),t2:f('setMlStT2',95),green:g('setMlStGreen','#00ffbb'),red:g('setMlStRed','#ff1100'),
            table:e?e.checked:false};
}

function calcMlSt(d,s){
    const n=d.length;
    // ATR با RMA (اولین مقدار = SMA ی len کندل اول، مثل ta.rma)
    const atrOf=function(len){
        const out=new Array(n).fill(NaN);let rma=NaN,sum=0;
        for(let i=0;i<n;i++){
            const tr=(i===0)?(d[i].high-d[i].low):Math.max(d[i].high-d[i].low,Math.abs(d[i].high-d[i-1].close),Math.abs(d[i].low-d[i-1].close));
            if(i<len-1){sum+=tr;}
            else if(i===len-1){sum+=tr;rma=sum/len;out[i]=rma;}
            else{rma=(rma*(len-1)+tr)/len;out[i]=rma;}
        }
        return out;
    };
    const vol=atrOf(s.atrLen),atr7=atrOf(7);
    const TR=s.train;
    const nz=function(x){return isNaN(x)?0:x;};
    const same=function(a,b){return a===b||(isNaN(a)&&isNaN(b));};

    const cluster=new Array(n).fill(-1);
    const st=new Array(n).fill(NaN),dir=new Array(n).fill(NaN);
    const loH=new Array(n).fill(NaN),upH=new Array(n).fill(NaN),asg=new Array(n).fill(NaN);
    let tbl=null;

    for(let i=0;i<n;i++){
        // --- highest / lowest ATR در پنجره‌ی آموزش
        let upper=NaN,lower=NaN;
        if(i>=TR-1){
            upper=-Infinity;lower=Infinity;
            for(let k=i-TR+1;k<=i;k++){const v=vol[k];if(!isNaN(v)){if(v>upper)upper=v;if(v<lower)lower=v;}}
            if(upper===-Infinity){upper=NaN;lower=NaN;}
        }
        let aM=lower+(upper-lower)*s.highvol;
        let bM=lower+(upper-lower)*s.midvol;
        let cM=lower+(upper-lower)*s.lowvol;
        let sizeA=0,sizeB=0,sizeC=0;
        // --- K-Means
        if(nz(vol[i])>0&&i>=TR-1){
            let pa=NaN,pb=NaN,pc=NaN,first=true,iter=0;
            while(iter<1000){
                let sa=0,na_=0,sb=0,nb=0,sc=0,nc=0;
                // ترتیب جمع: جدیدترین اول (unshift در حلقه از قدیمی به جدید)
                for(let j=0;j<TR;j++){
                    const v=vol[i-j];
                    const d1=Math.abs(v-aM),d2=Math.abs(v-bM),d3=Math.abs(v-cM);
                    if(d1<d2&&d1<d3){sa+=v;na_++;}
                    if(d2<d1&&d2<d3){sb+=v;nb++;}
                    if(d3<d1&&d3<d2){sc+=v;nc++;}
                }
                pa=aM;pb=bM;pc=cM;
                aM=na_?sa/na_:NaN;bM=nb?sb/nb:NaN;cM=nc?sc/nc:NaN;
                sizeA=na_;sizeB=nb;sizeC=nc;
                iter++;
                if(same(aM,pa)&&same(bM,pb)&&same(cM,pc))break;
            }
        }
        // --- نزدیک‌ترین کلاستر به ATR فعلی
        const dists=[Math.abs(vol[i]-aM),Math.abs(vol[i]-bM),Math.abs(vol[i]-cM)];
        const cents=[aM,bM,cM];
        let mn=Infinity;for(const x of dists){if(!isNaN(x)&&x<mn)mn=x;}
        let cl=-1;if(mn!==Infinity){cl=dists.indexOf(mn);}
        cluster[i]=cl;
        const assigned=(cl===-1)?NaN:cents[cl];
        asg[i]=assigned;
        // --- pine_supertrend(factor, atr=assigned)
        const c=d[i],src=(c.high+c.low)/2;
        let up=src+s.fact*assigned,lo=src-s.fact*assigned;
        const prevLo=nz(i>0?loH[i-1]:NaN),prevUp=nz(i>0?upH[i-1]:NaN);
        const cPrev=i>0?d[i-1].close:NaN;
        lo=(lo>prevLo||cPrev<prevLo)?lo:prevLo;
        up=(up<prevUp||cPrev>prevUp)?up:prevUp;
        loH[i]=lo;upH[i]=up;
        const prevST=i>0?st[i-1]:NaN;
        let dr;
        if(i===0||isNaN(asg[i-1]))dr=1;
        else if(prevST===prevUp)dr=c.close>up?-1:1;
        else dr=c.close<lo?1:-1;
        dir[i]=dr;
        st[i]=(dr===-1)?lo:up;
        if(i===n-1)tbl={hv:aM,mv:bM,lv:cM,sizeA:sizeA,sizeB:sizeB,sizeC:sizeC,vol:vol[i],cluster:cl};
    }
    const upV=new Array(n).fill(NaN),dnV=new Array(n).fill(NaN),mid=new Array(n).fill(NaN);
    const shapes=[],labels=[];
    for(let i=0;i<n;i++){
        const c=d[i];
        if(!isNaN(st[i])){
            if(c.close>st[i])upV[i]=st[i];
            if(c.close<st[i])dnV[i]=st[i];
        }
        if(i>0)mid[i]=(c.open+c.close)/2;
        if(i>0&&!isNaN(st[i])){
            if(dir[i]<0&&dir[i-1]>=0)shapes.push({idx:i,price:st[i],dir:1});     // Bullish Trend
            if(dir[i]>0&&dir[i-1]<=0)shapes.push({idx:i,price:st[i],dir:-1});    // Bearish Trend
        }
        if(!isNaN(st[i])&&!isNaN(atr7[i])){
            labels.push({idx:i,price:dir[i]>0?st[i]+atr7[i]:st[i]-atr7[i],text:String(4-(cluster[i]+1)),cl:cluster[i],dir:dir[i]});
        }
    }
    return {n:n,st:st,dir:dir,upV:upV,dnV:dnV,mid:mid,shapes:shapes,labels:labels.slice(-500),table:tbl,settings:s,markers:[]};
}

class MlStRenderer{
    constructor(p,top){this._p=p;this._top=top;}
    draw(target){
        const p=this._p;
        if(!p._chart||!p._series||!p._data)return;
        const r=p._data,s=r.settings,ts=p._chart.timeScale(),ser=p._series,top=this._top;
        target.useMediaCoordinateSpace(function(scope){
            const ctx=scope.context,W=scope.mediaSize.width;
            const rgb=function(hex){const h=hex.replace('#','');return [parseInt(h.substr(0,2),16),parseInt(h.substr(2,2),16),parseInt(h.substr(4,2),16)];};
            const rgba=function(hex,transp){const c=rgb(hex);return 'rgba('+c[0]+','+c[1]+','+c[2]+','+(1-transp/100).toFixed(3)+')';};
            const X=function(i){return ts.logicalToCoordinate(i);};
            const Y=function(v){return isNaN(v)?null:ser.priceToCoordinate(v);};
            const vr=ts.getVisibleLogicalRange();
            let a=0,b=r.n-1;
            if(vr){a=Math.max(0,Math.floor(vr.from)-2);b=Math.min(r.n-1,Math.ceil(vr.to)+2);}
            if(!top){
                // فیل گرادیانی بین وسط بدنه و SuperTrend + خط‌ها (plot.style_linebr)
                for(const kind of ['up','dn']){
                    const arr=kind==='up'?r.upV:r.dnV,col=kind==='up'?s.green:s.red;
                    for(let i=Math.max(1,a);i<=b;i++){
                        if(isNaN(arr[i])||isNaN(arr[i-1])||isNaN(r.mid[i])||isNaN(r.mid[i-1]))continue;
                        const x0=X(i-1),x1=X(i),s0=Y(arr[i-1]),s1=Y(arr[i]),m0=Y(r.mid[i-1]),m1=Y(r.mid[i]);
                        if(x0===null||x1===null||s0===null||s1===null||m0===null||m1===null)continue;
                        const gy1=(m0+m1)/2,gy2=(s0+s1)/2;
                        if(Math.abs(gy1-gy2)<0.5){ctx.fillStyle=rgba(col,s.t1);}
                        else{
                            const gr=ctx.createLinearGradient(0,gy1,0,gy2);
                            gr.addColorStop(0,rgba(col,s.t2));gr.addColorStop(1,rgba(col,s.t1));
                            ctx.fillStyle=gr;
                        }
                        ctx.beginPath();ctx.moveTo(x0,m0);ctx.lineTo(x0,s0);ctx.lineTo(x1,s1);ctx.lineTo(x1,m1);ctx.closePath();ctx.fill();
                    }
                    ctx.strokeStyle=rgba(col,s.t1);ctx.lineWidth=1;
                    for(let i=Math.max(1,a);i<=b;i++){
                        if(isNaN(arr[i])||isNaN(arr[i-1]))continue;
                        const x0=X(i-1),x1=X(i),y0=Y(arr[i-1]),y1=Y(arr[i]);
                        if(x0===null||x1===null||y0===null||y1===null)continue;
                        ctx.beginPath();ctx.moveTo(x0,y0);ctx.lineTo(x1,y1);ctx.stroke();
                    }
                }
                return;
            }
            // ---- لیبل شماره‌ی کلاستر
            ctx.textBaseline='middle';ctx.textAlign='center';ctx.font='11px sans-serif';
            for(const L of r.labels){
                if(L.idx<a||L.idx>b)continue;
                const x=X(L.idx),y=Y(L.price);
                if(x===null||y===null)continue;
                const tt=Math.max(0,Math.min(1,(L.cl+1-1)/2));
                ctx.fillStyle=rgba(L.dir>0?s.red:s.green,30+tt*60);
                ctx.fillText(L.text,x,y);
            }
            // ---- شکل‌های تغییر روند (labelup / labeldown)
            for(const S of r.shapes){
                if(S.idx<a||S.idx>b)continue;
                const x=X(S.idx),y=Y(S.price);
                if(x===null||y===null)continue;
                const bw=22,bh=18,gap=5,up=S.dir===1;
                ctx.fillStyle=up?s.green:s.red;
                const y0=up?y+gap:y-gap-bh;
                ctx.beginPath();
                if(ctx.roundRect){ctx.roundRect(x-bw/2,y0,bw,bh,3);}else{ctx.rect(x-bw/2,y0,bw,bh);}
                ctx.fill();
                ctx.beginPath();
                if(up){ctx.moveTo(x-5,y+gap);ctx.lineTo(x,y);ctx.lineTo(x+5,y+gap);}
                else{ctx.moveTo(x-5,y-gap);ctx.lineTo(x,y);ctx.lineTo(x+5,y-gap);}
                ctx.closePath();ctx.fill();
                ctx.fillStyle='#ffffff';ctx.font='10px sans-serif';
                ctx.fillText(up?'▲':'▼',x,y0+bh/2+0.5);
            }
            // ---- جدول کلاستر (بالا-راست)
            if(s.table&&r.table){
                const T=r.table;
                const fmt=function(v){return isNaN(v)?'NaN':String(Math.round(v*100)/100);};
                const names=['HIGH','MEDIUM','LOW'];
                const rows=[
                    ['Cluster Number (Volatility Level)','Cluster Centroid (ATR)','Cluster Size (No. of Data Points in Each Cluster)','Current Volatility'],
                    ['3 (High)',fmt(T.hv),fmt(T.sizeC),'HIGH (ATR: '+fmt(T.vol)+')'],
                    ['2 (Medium)',fmt(T.mv),fmt(T.sizeB),'MEDIUM (ATR: '+fmt(T.vol)+')'],
                    ['1 (Low)',fmt(T.lv),fmt(T.sizeA),'LOW (ATR: '+fmt(T.vol)+')']
                ];
                let fs=10,widths,total;
                const measure=function(){
                    ctx.font=fs+'px sans-serif';widths=[0,0,0,0];
                    for(const row of rows){for(let c=0;c<4;c++){widths[c]=Math.max(widths[c],ctx.measureText(row[c]).width+8);}}
                    total=widths[0]+widths[1]+widths[2]+widths[3];
                };
                measure();
                while(total>W-8&&fs>5){fs-=0.5;measure();}
                const rh=fs+8;let x0=W-total-4,y0=4;
                ctx.textAlign='center';ctx.textBaseline='middle';
                for(let rI=0;rI<4;rI++){
                    let x=x0;
                    for(let c=0;c<4;c++){
                        const hl=(c===3&&rI>0&&T.cluster===rI-1);
                        ctx.fillStyle=hl?'#ffffff':'#050810';
                        ctx.fillRect(x,y0+rI*rh,widths[c],rh);
                        ctx.strokeStyle='#ffffff';ctx.lineWidth=1;
                        ctx.strokeRect(x+0.5,y0+rI*rh+0.5,widths[c],rh);
                        if(c===3&&rI>0&&!hl){x+=widths[c];continue;}   // متن همرنگ پس‌زمینه (مثل اسکریپت اصلی)
                        ctx.fillStyle=(c===3&&rI>0)?'#050810':'#ffffff';
                        ctx.fillText(rows[rI][c],x+widths[c]/2,y0+rI*rh+rh/2);
                        x+=widths[c];
                    }
                }
            }
        });
    }
}
class MlStPaneView{
    constructor(p,top){this._p=p;this._top=top;}
    zOrder(){return this._top?'top':'bottom';}
    renderer(){return new MlStRenderer(this._p,this._top);}
}
class MlStPrimitive{
    constructor(){this._data=null;this._chart=null;this._series=null;this._req=null;this._views=[new MlStPaneView(this,false),new MlStPaneView(this,true)];}
    attached(param){this._chart=param.chart;this._series=param.series;this._req=param.requestUpdate;}
    detached(){this._chart=null;this._series=null;this._req=null;}
    paneViews(){return this._views;}
    updateAllViews(){}
    setData(r){this._data=r;if(this._req)this._req();}
}

function mlstRemove(){
    if(mlstPrimitive&&candleSeries){try{candleSeries.detachPrimitive(mlstPrimitive);}catch(e){}}
    mlstPrimitive=null;
    mlstResult=null;
    lzVotes[3]=null;
}

function drawMlSt(d){
    if(!chart||!candleSeries||!d||d.length<10){return null;}
    try{
        const s=mlstReadSettings();
        mlstResult=calcMlSt(d,s);
        if(!mlstPrimitive){
            mlstPrimitive=new MlStPrimitive();
            candleSeries.attachPrimitive(mlstPrimitive);
        }
        mlstPrimitive.setData(mlstResult);
        // رأی P3: جهت فعلی SuperTrend (dir<0 صعودی => لانگ | dir>0 نزولی => شورت)
        const dr=mlstResult.dir[mlstResult.n-1];
        lzVotes[3]=isNaN(dr)?null:(dr<0?'long':'short');
        console.log('=== P3 ML SuperTrend: dir='+dr+' | سیگنال‌ها='+mlstResult.shapes.length+' ===');
        return mlstResult;
    }catch(err){
        console.error('خطای کلی در drawMlSt:',err);
        return null;
    }
}

function mlstRedraw(){
    if(mlstEnabled&&currentCandles.length>0)drawMlSt(currentCandles);
}

function toggleMlSt(){
    mlstEnabled=!mlstEnabled;
    const btn=document.getElementById('btnLzRun3');
    if(mlstEnabled){
        if(btn){btn.classList.add('active');btn.textContent='⏹ حذف';}
        if(currentCandles.length>0)setTimeout(function(){drawMlSt(currentCandles);},50);
    }else{
        if(btn){btn.classList.remove('active');btn.textContent='▶ اجرا';}
        mlstRemove();
    }
}

// ==================== P6: Smart Money Breakout Channels [AlgoAlpha] ====================
// بازسازی مستقیم از سورس Pine اصلی.
// توجه: ta.requestUpAndDownVolume (حجم خرید/فروش از تایم‌فریم پایین) در این برنامه دیتا ندارد؛
// به جایش حجم هر کندل بر اساس موقعیت close در رنج کندل بین خرید و فروش تقسیم می‌شود (تخمین).
let brEnabled=false;
let brResult=null;
let brPrimitive=null;

function brReadSettings(){
    const g=function(id,def){const e=document.getElementById(id);return e?e.value:def;};
    const c=function(id,def){const e=document.getElementById(id);return e?e.checked:def;};
    const f=function(id,def){const v=parseFloat(g(id,def));return isNaN(v)?def:v;};
    return {overlap:c('setBrOverlap',false),strong:c('setBrStrong',true),normLen:Math.max(2,Math.round(f('setBrNormLen',100))),
            len:Math.max(1,Math.round(f('setBrLen',14))),showVol:c('setBrShowVol',true),mode:g('setBrMode','Comparison'),
            scale:Math.max(0.1,Math.min(2,f('setBrScale',0.5))),textSize:g('setBrTextSize','Tiny'),
            green:g('setBrGreen','#00ffbb'),red:g('setBrRed','#ff1100')};
}

function calcBrCh(d,s){
    const n=d.length,LEN=s.len,NL=s.normLen;
    const NaNs=function(){return new Array(n).fill(NaN);};
    // ---- نرمال‌سازی قیمت و stdev(14)
    const np=NaNs();
    for(let i=NL-1;i<n;i++){
        let lo=Infinity,hi=-Infinity;
        for(let k=i-NL+1;k<=i;k++){if(d[k].low<lo)lo=d[k].low;if(d[k].high>hi)hi=d[k].high;}
        np[i]=(d[i].close-lo)/(hi-lo);
    }
    const vol=NaNs();
    for(let i=0;i<n;i++){
        if(i<13)continue;
        let sm=0,ok=true;
        for(let k=i-13;k<=i;k++){if(isNaN(np[k])){ok=false;break;}sm+=np[k];}
        if(!ok)continue;
        const mean=sm/14;let v=0;
        for(let k=i-13;k<=i;k++){v+=(np[k]-mean)*(np[k]-mean);}
        vol[i]=Math.sqrt(v/14);
    }
    // ---- upper / lower از highestbars / lowestbars روی پنجره‌ی length+1
    const upper=NaNs(),lower=NaNs();
    for(let i=LEN;i<n;i++){
        let ok=true,bh=-Infinity,bhk=0,bl=Infinity,blk=0;
        for(let k=i-LEN;k<=i;k++){
            const v=vol[k];
            if(isNaN(v)){ok=false;break;}
            if(v>=bh){bh=v;bhk=k;}
            if(v<=bl){bl=v;blk=k;}
        }
        if(!ok)continue;
        upper[i]=((bhk-i)+LEN)/LEN;
        lower[i]=((blk-i)+LEN)/LEN;
    }
    // ---- ATR(length)/2 و SMA حجم ۲۰
    const atr=NaNs();{
        let rma=NaN,sum=0;
        for(let i=0;i<n;i++){
            const tr=(i===0)?(d[i].high-d[i].low):Math.max(d[i].high-d[i].low,Math.abs(d[i].high-d[i-1].close),Math.abs(d[i].low-d[i-1].close));
            if(i<LEN-1){sum+=tr;}else if(i===LEN-1){sum+=tr;rma=sum/LEN;atr[i]=rma;}else{rma=(rma*(LEN-1)+tr)/LEN;atr[i]=rma;}
        }
    }
    const smv=NaNs();
    for(let i=19;i<n;i++){let sm=0;for(let k=i-19;k<=i;k++)sm+=(d[k].volume||0);smv[i]=sm/20;}
    // ---- حجم خرید/فروش (تخمین)
    const uvA=NaNs(),dvA=NaNs(),voldA=NaNs();
    for(let i=0;i<n;i++){
        const c=d[i],v=c.volume||0,rg=c.high-c.low;
        const up=rg>0?v*(c.close-c.low)/rg:v/2;
        uvA[i]=up;dvA[i]=-(v-up);voldA[i]=up-(v-up);
    }
    const crossOver=function(a,b,i){return i>0&&a[i]>b[i]&&a[i-1]<=b[i-1];};

    const active=[],chans=[],candles=[],shapes=[];
    let lastCross=-1;           // آخرین ta.crossover(lower,upper)
    let hvold=voldA[0],lvold=voldA[0];
    let lastUp=0,lastDown=0;
    const fmtK=function(x){const r=Math.round(x/1000*10)/10;return isNaN(r)?'NaN':String(r);};

    for(let i=0;i<n;i++){
        const c=d[i];
        const cLU=crossOver(lower,upper,i),cUL=crossOver(upper,lower,i);
        if(cLU)lastCross=i;
        const duration=Math.max(lastCross>=0?(i-lastCross):0,1);
        // h / l  = highest(high,duration) / lowest(low,duration)
        let h=NaN,l=NaN;
        if(i-duration+1>=0){h=-Infinity;l=Infinity;for(let k=i-duration+1;k<=i;k++){if(d[k].high>h)h=d[k].high;if(d[k].low<l)l=d[k].low;}}
        if(cLU){hvold=voldA[i];lvold=voldA[i];}
        if(voldA[i]>hvold)hvold=voldA[i];
        if(voldA[i]<lvold)lvold=voldA[i];
        const vola=atr[i]/2;
        let upbreak=0,downbreak=0;
        // ---- ساخت کانال جدید
        if(cUL&&duration>10){
            let ok=true;
            if(!s.overlap){for(const b of active){if(h>b.bottom&&l<b.top){ok=false;break;}}}
            if(ok){
                const ch={left:i-duration,right:i,top:h,bottom:l,vola:vola,text:'',side:'',}
                active.unshift(ch);chans.push(ch);
            }
        }
        // ---- شکست یا ادامه
        const n0=active.length;
        const price=s.strong?(c.open+c.close)/2:c.close;
        for(let k=0;k<n0;k++){
            if(k>=active.length)break;
            const ch=active[k];
            if(price>ch.top){upbreak=ch.bottom;active.splice(k,1);}
            else if(price<ch.bottom){downbreak=ch.top;active.splice(k,1);}
            else{
                ch.right=i;
                const mid=(ch.top+ch.bottom)/2;
                let txt='';
                if(s.mode==='Volume')txt=fmtK(c.volume||0)+'K';
                else if(s.mode==='Comparison')txt=fmtK(uvA[i])+'K/'+fmtK(dvA[i])+'K';
                else txt=fmtK(voldA[i])+'K';
                ch.text=txt;ch.side=(price>mid)?'low':'up';
            }
        }
        if(upbreak!==0)shapes.push({idx:i,price:upbreak,dir:1});
        if(downbreak!==0)shapes.push({idx:i,price:downbreak,dir:-1});
        lastUp=upbreak;lastDown=downbreak;
        // ---- کندل‌های حجم داخل کانال جدیدتر
        if(active.length>0&&s.showVol){
            const A=active[0],mid=(A.top+A.bottom)/2,chH=(A.top-A.bottom)*s.scale,sv=smv[i];
            const q=chH/4;
            let U=null,L=null,uc,lc;
            if(s.mode==='Volume'){
                const hh=((c.volume||0)/sv)*q;
                U={o:mid,h:mid+hh,l:mid,c:mid+hh};L={o:mid,h:mid,l:mid-hh,c:mid-hh};
                const ratio=(c.volume||0)/sv;
                const tr=Math.max(20,Math.min(80,80-(ratio-0.5)*40));
                uc=lc={fg:true,tr:tr};
            }else{
                uc={col:s.green};lc={col:s.red};
                if(s.mode==='Comparison'){
                    const uh=isNaN(uvA[i])?0:(uvA[i]/sv)*q,dh=isNaN(dvA[i])?0:(dvA[i]/sv)*q;
                    U={o:mid,h:mid+uh,l:mid,c:mid+uh};L={o:mid,h:mid,l:mid+dh,c:mid+dh};
                }else{
                    const dh=isNaN(voldA[i])?0:Math.abs(voldA[i]/sv)*q;
                    if(voldA[i]>=0){U={o:mid,h:mid+dh,l:mid,c:mid+dh};L={o:mid,h:mid,l:mid,c:mid};}
                    else{U={o:mid,h:mid,l:mid,c:mid};L={o:mid,h:mid,l:mid-dh,c:mid-dh};}
                }
            }
            candles.push({idx:i,U:U,L:L,uc:uc,lc:lc});
        }
    }
    // ---- گیج آخر نمودار
    let gauge=null;
    if(active.length>0&&lastUp===0&&lastDown===0){
        const A=active[0];
        let delvol=-100*2*((voldA[n-1]-lvold)/(hvold-lvold)-0.5);
        delvol=Math.max(Math.min(delvol,100),-100);
        const pos=A.top-((delvol+100)/200)*(A.top-A.bottom);
        gauge={top:A.top,bottom:A.bottom,pointer:pos};
    }
    // ---- سقف تعداد آبجکت‌ها: 500 باکس (3 تا برای هر کانال) و 50 خط (گیج 21 خط مصرف می‌کند)
    const keepCh=chans.slice(-Math.floor(500/3));
    const keepLines=gauge?29:50;
    keepCh.forEach(function(ch){ch.line=false;});
    chans.slice(-keepLines).forEach(function(ch){ch.line=true;});
    return {n:n,channels:keepCh,candles:candles,shapes:shapes,gauge:gauge,settings:s,markers:[],active:active.length};
}

class BrRenderer{
    constructor(p,top){this._p=p;this._top=top;}
    draw(target){
        const p=this._p;
        if(!p._chart||!p._series||!p._data)return;
        const r=p._data,s=r.settings,ts=p._chart.timeScale(),ser=p._series,top=this._top;
        target.useMediaCoordinateSpace(function(scope){
            const ctx=scope.context,W=scope.mediaSize.width;
            const rgb=function(hex){const h=hex.replace('#','');return [parseInt(h.substr(0,2),16),parseInt(h.substr(2,2),16),parseInt(h.substr(4,2),16)];};
            const rgba=function(hex,a){const h=hex.replace('#','');return 'rgba('+parseInt(h.substr(0,2),16)+','+parseInt(h.substr(2,2),16)+','+parseInt(h.substr(4,2),16)+','+a+')';};
            const X=function(i){return ts.logicalToCoordinate(i);};
            const Y=function(v){return (v===undefined||isNaN(v))?null:ser.priceToCoordinate(v);};
            const fs={Tiny:8,Small:10,Medium:12,Large:16}[s.textSize]||8;
            if(!top){
                for(const ch of r.channels){
                    const x1=X(ch.left),x2=X(ch.right),yT=Y(ch.top),yB=Y(ch.bottom),yU=Y(ch.top-ch.vola),yL=Y(ch.bottom+ch.vola);
                    if(x1===null||x2===null||yT===null||yB===null)continue;
                    if(x2<0||x1>W)continue;
                    const w=Math.max(1,x2-x1);
                    ctx.fillStyle='rgba(255,255,255,0.10)';
                    ctx.fillRect(x1,Math.min(yT,yB),w,Math.abs(yB-yT));
                    if(yU!==null){ctx.fillStyle=rgba(s.red,0.30);ctx.fillRect(x1,Math.min(yT,yU),w,Math.max(1,Math.abs(yU-yT)));}
                    if(yL!==null){ctx.fillStyle=rgba(s.green,0.30);ctx.fillRect(x1,Math.min(yB,yL),w,Math.max(1,Math.abs(yB-yL)));}
                    if(ch.line){
                        const yc=Y((ch.top+ch.bottom)/2);
                        if(yc!==null){
                            ctx.strokeStyle='rgba(255,255,255,0.5)';ctx.lineWidth=1;ctx.setLineDash([4,4]);
                            ctx.beginPath();ctx.moveTo(x1,yc);ctx.lineTo(x2,yc);ctx.stroke();ctx.setLineDash([]);
                        }
                    }
                    if(ch.text){
                        const ya=(ch.side==='low')?Y(ch.bottom+ch.vola/2):Y(ch.top-ch.vola/2);
                        if(ya!==null){
                            ctx.font=fs+'px sans-serif';ctx.textAlign='right';ctx.textBaseline='middle';
                            ctx.fillStyle='rgba(255,255,255,0.70)';
                            ctx.fillText(ch.text,x2-2,ya);
                        }
                    }
                }
                return;
            }
            // ---- کندل‌های حجم (plotcandle)
            const vr=ts.getVisibleLogicalRange();
            let a=0,b=r.n-1;
            if(vr){a=Math.max(0,Math.floor(vr.from)-2);b=Math.min(r.n-1,Math.ceil(vr.to)+2);}
            const drawCandle=function(x,bw,cd,col){
                const yo=Y(cd.o),yc=Y(cd.c),yh=Y(cd.h),yl=Y(cd.l);
                if(yo===null||yc===null||yh===null||yl===null)return;
                ctx.strokeStyle=col;ctx.fillStyle=col;ctx.lineWidth=1;
                ctx.beginPath();ctx.moveTo(x,yh);ctx.lineTo(x,yl);ctx.stroke();
                const t0=Math.min(yo,yc),hh=Math.max(1,Math.abs(yc-yo));
                ctx.fillRect(x-bw/2,t0,bw,hh);
            };
            for(const k of r.candles){
                if(k.idx<a||k.idx>b)continue;
                const x=X(k.idx),xn=X(k.idx+1);
                if(x===null)continue;
                const bw=Math.max(1,((xn!==null)?Math.abs(xn-x):6)*0.75);
                const cu=k.uc.fg?'rgba(255,255,255,'+(1-k.uc.tr/100).toFixed(3)+')':k.uc.col;
                const cl=k.lc.fg?'rgba(255,255,255,'+(1-k.lc.tr/100).toFixed(3)+')':k.lc.col;
                drawCandle(x,bw,k.U,cu);
                drawCandle(x,bw,k.L,cl);
            }
            // ---- شکل‌های شکست کانال
            ctx.textAlign='center';ctx.textBaseline='middle';
            for(const S of r.shapes){
                if(S.idx<a||S.idx>b)continue;
                const x=X(S.idx),y=Y(S.price);
                if(x===null||y===null)continue;
                const bw=24,bh=20,gap=6,up=S.dir===1;
                ctx.fillStyle=up?s.green:s.red;
                const y0=up?y+gap:y-gap-bh;
                ctx.beginPath();
                if(ctx.roundRect){ctx.roundRect(x-bw/2,y0,bw,bh,3);}else{ctx.rect(x-bw/2,y0,bw,bh);}
                ctx.fill();
                ctx.beginPath();
                if(up){ctx.moveTo(x-5,y+gap);ctx.lineTo(x,y);ctx.lineTo(x+5,y+gap);}
                else{ctx.moveTo(x-5,y-gap);ctx.lineTo(x,y);ctx.lineTo(x+5,y-gap);}
                ctx.closePath();ctx.fill();
                ctx.fillStyle='#ffffff';ctx.font='11px sans-serif';
                ctx.fillText(up?'▲':'▼',x,y0+bh/2+0.5);
            }
            // ---- گیج (۲۱ خط عمودی + اشاره‌گر)
            if(r.gauge){
                const G=r.gauge,gx=X(r.n-1+2);
                if(gx!==null){
                    const seg=21,segLen=(G.top-G.bottom)/seg;
                    const g1=rgb(s.red),g2=rgb(s.green);
                    ctx.lineWidth=4;ctx.lineCap='butt';
                    for(let k=0;k<seg;k++){
                        const y1=G.top-k*segLen,y2=G.top-(k+1)*segLen;
                        const tt=Math.max(0,Math.min(1,(y1-G.bottom)/(G.top-G.bottom)));
                        const cr=Math.round(g1[0]+(g2[0]-g1[0])*tt),cg=Math.round(g1[1]+(g2[1]-g1[1])*tt),cb=Math.round(g1[2]+(g2[2]-g1[2])*tt);
                        const py1=Y(y1),py2=Y(y2);
                        if(py1===null||py2===null)continue;
                        ctx.strokeStyle='rgb('+cr+','+cg+','+cb+')';
                        ctx.beginPath();ctx.moveTo(gx,py1);ctx.lineTo(gx,py2);ctx.stroke();
                    }
                    const px=X(r.n-1+3),py=Y(G.pointer);
                    if(px!==null&&py!==null){
                        ctx.fillStyle='#ffffff';ctx.font='11px sans-serif';ctx.textAlign='left';ctx.textBaseline='middle';
                        ctx.fillText('◀',px-2,py);
                    }
                }
            }
        });
    }
}
class BrPaneView{
    constructor(p,top){this._p=p;this._top=top;}
    zOrder(){return this._top?'top':'bottom';}
    renderer(){return new BrRenderer(this._p,this._top);}
}
class BrPrimitive{
    constructor(){this._data=null;this._chart=null;this._series=null;this._req=null;this._views=[new BrPaneView(this,false),new BrPaneView(this,true)];}
    attached(param){this._chart=param.chart;this._series=param.series;this._req=param.requestUpdate;}
    detached(){this._chart=null;this._series=null;this._req=null;}
    paneViews(){return this._views;}
    updateAllViews(){}
    setData(r){this._data=r;if(this._req)this._req();}
}

function brRemove(){
    if(brPrimitive&&candleSeries){try{candleSeries.detachPrimitive(brPrimitive);}catch(e){}}
    brPrimitive=null;
    brResult=null;
    lzVotes[6]=null;
}

function drawBrCh(d){
    if(!chart||!candleSeries||!d||d.length<30){return null;}
    try{
        const s=brReadSettings();
        brResult=calcBrCh(d,s);
        if(!brPrimitive){
            brPrimitive=new BrPrimitive();
            candleSeries.attachPrimitive(brPrimitive);
        }
        // گیج در ۲ تا ۳ کندل بعد از آخرین کندل رسم می‌شود؛ حاشیه‌ی راست لازم است
        try{
            const ro=chart.timeScale().options().rightOffset;
            if(brResult.gauge&&(ro===undefined||ro<6))chart.timeScale().applyOptions({rightOffset:6});
        }catch(e){}
        brPrimitive.setData(brResult);
        // رأی P6: آخرین شکست کانال در ۱۰ کندل اخیر (صعودی => لانگ | نزولی => شورت)
        const last=brResult.shapes.length?brResult.shapes[brResult.shapes.length-1]:null;
        lzVotes[6]=(last&&last.idx>=d.length-10)?(last.dir===1?'long':'short'):null;
        console.log('=== P6 Breakout Channels: '+brResult.channels.length+' کانال | '+brResult.shapes.length+' شکست ===');
        return brResult;
    }catch(err){
        console.error('خطای کلی در drawBrCh:',err);
        return null;
    }
}

function brRedraw(){
    if(brEnabled&&currentCandles.length>0)drawBrCh(currentCandles);
}

function toggleBrCh(){
    brEnabled=!brEnabled;
    const btn=document.getElementById('btnLzRun6');
    if(brEnabled){
        if(btn){btn.classList.add('active');btn.textContent='⏹ حذف';}
        if(currentCandles.length>0)setTimeout(function(){drawBrCh(currentCandles);},50);
    }else{
        if(btn){btn.classList.remove('active');btn.textContent='▶ اجرا';}
        brRemove();
    }
}

// ==================== P2: Impulse Heatmap [marketmastery75] ====================
// ⚠️ اسکریپت اصلی invite-only است و سورسش در دسترس نیست؛ این نسخه بازسازی از روی «توضیحات و Release Notes» است:
//   هیت‌مپ حجمی روی سطوح قیمت در بازه‌ی Period | POC هموارشده | فیلتر روند EMA | عدد حجم زون‌های داغ (پیش‌فرض خاموش)
//   لیبل‌های Retest (Bounce UP / Reject DOWN) | سیگنال Buy/Sell با کندل قوی تاییدشده و فقط به‌صورت متناوب
let ihEnabled=false;
let ihResult=null;
let ihPrimitive=null;

function ihReadSettings(){
    const g=function(id,def){const e=document.getElementById(id);return e?e.value:def;};
    const c=function(id,def){const e=document.getElementById(id);return e?e.checked:def;};
    const f=function(id,def){const v=parseFloat(g(id,def));return isNaN(v)?def:v;};
    return {period:Math.max(30,Math.round(f('setIhPeriod',200))),smooth:Math.max(1,Math.round(f('setIhSmooth',10))),
            opacity:Math.max(5,Math.min(100,f('setIhOpacity',60)))/100,heat:g('setIhHeat','#ff1100'),
            showPoc:c('setIhPoc',true),pocCol:g('setIhPocCol','#ff1100'),showVol:c('setIhVol',false),volCol:g('setIhVolCol','#ffffff'),
            emaLen:Math.max(2,Math.round(f('setIhEma',50))),trend:c('setIhTrend',true),
            retest:c('setIhRetest',true),rtUp:g('setIhRtUp','#00e676'),rtDn:g('setIhRtDn','#ff1744'),
            sig:c('setIhSig',true),buy:g('setIhBuy','#00c853'),sell:g('setIhSell','#ff1744')};
}

function calcImpulseHM(d,s){
    const n=d.length,ROWS=50,TH=0.6,P=s.period;
    const first=Math.min(P,n)-1;
    const step=Math.max(1,Math.round(P/20));
    // EMA روند
    const ema=new Array(n).fill(NaN);
    {const k=2/(s.emaLen+1);let e=d[0].close;ema[0]=e;for(let i=1;i<n;i++){e=d[i].close*k+e*(1-k);ema[i]=e;}}
    const prof=function(t){
        const a=Math.max(0,t-P+1);
        let wl=Infinity,wh=-Infinity;
        for(let k=a;k<=t;k++){if(d[k].low<wl)wl=d[k].low;if(d[k].high>wh)wh=d[k].high;}
        const bs=(wh-wl)/ROWS||1e-9;
        const vols=new Array(ROWS).fill(0);
        for(let k=a;k<=t;k++){
            const c=d[k],v=c.volume||0,rg=c.high-c.low;
            let b1=Math.floor((c.low-wl)/bs),b2=Math.floor((c.high-wl)/bs);
            b1=Math.max(0,Math.min(ROWS-1,b1));b2=Math.max(0,Math.min(ROWS-1,b2));
            if(rg<=0||b1===b2){vols[b1]+=v;continue;}
            for(let b=b1;b<=b2;b++){
                const lo=Math.max(c.low,wl+b*bs),hi=Math.min(c.high,wl+(b+1)*bs);
                if(hi>lo)vols[b]+=v*(hi-lo)/rg;
            }
        }
        let mx=0,pb=0;for(let b=0;b<ROWS;b++){if(vols[b]>mx){mx=vols[b];pb=b;}}
        return {vols:vols,bs:bs,wl:wl,wh:wh,max:mx,poc:wl+(pb+0.5)*bs,start:a};
    };
    const zonesOf=function(pf){
        const out=[];let b=0;
        while(b<ROWS){
            if(pf.max>0&&pf.vols[b]/pf.max>=TH){
                let b2=b,sum=0,isum=0;
                while(b2<ROWS&&pf.vols[b2]/pf.max>=TH){sum+=pf.vols[b2];isum+=pf.vols[b2]/pf.max;b2++;}
                out.push({bottom:pf.wl+b*pf.bs,top:pf.wl+b2*pf.bs,vol:sum,inten:isum/(b2-b)});
                b=b2;
            }else b++;
        }
        return out;
    };
    const poc=new Array(n).fill(NaN);
    const segs=[],labels=[],signals=[];
    let pocS=NaN,curZones=[],lastProf=null,lastDir=0,gid=0;
    const alpha=2/(s.smooth+1);
    for(let t=first;t<n;t++){
        const pf=prof(t);lastProf=pf;
        pocS=isNaN(pocS)?pf.poc:(pf.poc*alpha+pocS*(1-alpha));
        poc[t]=pocS;
        if((t-first)%step===0||t===n-1){
            const zs=zonesOf(pf);
            const prev=segs.length?segs[segs.length-1]:null;
            for(const z of zs){
                z.gid=-1;
                if(prev){for(const q of prev.zones){if(z.bottom<q.top&&z.top>q.bottom){z.gid=q.gid;break;}}}
                if(z.gid<0)z.gid=gid++;
            }
            if(prev&&prev.s===t){prev.zones=zs;}   // سگمنت آخر روی همان کندل
            else segs.push({s:t,e:t+step,zones:zs});
            curZones=zs;
        }
        if(t<1)continue;
        const c=d[t],p=d[t-1],rg=c.high-c.low,body=Math.abs(c.close-c.open);
        const strongBull=c.close>c.open&&rg>0&&body>=0.6*rg;
        const strongBear=c.close<c.open&&rg>0&&body>=0.6*rg;
        let buy=false,sell=false;
        for(const z of curZones){
            // ---- Retest: ورود قیمت به زون از بالا / پایین
            if(s.retest){
                if(p.low>z.top&&c.low<=z.top&&c.high>=z.bottom)labels.push({idx:t,price:c.low,dir:1,text:'🟢 Retest -> Bounce UP'});
                if(p.high<z.bottom&&c.high>=z.bottom&&c.low<=z.top)labels.push({idx:t,price:c.high,dir:-1,text:'🔴 Retest -> Reject DOWN'});
            }
            // ---- Buy: شکست رو به بالا یا رد شدن از زون با کندل قوی
            if(strongBull&&((p.close<=z.top&&c.close>z.top)||(c.low<=z.top&&c.low>=z.bottom&&c.close>z.top)))buy=true;
            if(strongBear&&((p.close>=z.bottom&&c.close<z.bottom)||(c.high>=z.bottom&&c.high<=z.top&&c.close<z.bottom)))sell=true;
        }
        if(s.trend){if(c.close<=ema[t])buy=false;if(c.close>=ema[t])sell=false;}
        if(buy&&sell){buy=false;sell=false;}
        if(buy&&lastDir!==1){signals.push({idx:t,price:c.low,dir:1});lastDir=1;}
        else if(sell&&lastDir!==-1){signals.push({idx:t,price:c.high,dir:-1});lastDir=-1;}
    }
    // پایان سگمنت‌ها
    for(let i=0;i<segs.length;i++){segs[i].e=(i<segs.length-1)?segs[i+1].s:n-1+10;}
    // لیبل حجم: آخرین عضو هر گروه زون
    const lastOfGroup={};
    segs.forEach(function(sg){sg.zones.forEach(function(z){lastOfGroup[z.gid]={seg:sg,z:z};});});
    const volLabels=Object.keys(lastOfGroup).map(function(k){const o=lastOfGroup[k];return {x:o.seg.e,y:(o.z.top+o.z.bottom)/2,vol:o.z.vol};});
    return {n:n,segs:segs,poc:poc,labels:labels.slice(-100),signals:signals,volLabels:volLabels,profile:lastProf,settings:s,markers:[],period:P};
}

class IhRenderer{
    constructor(p,top){this._p=p;this._top=top;}
    draw(target){
        const p=this._p;
        if(!p._chart||!p._series||!p._data)return;
        const r=p._data,s=r.settings,ts=p._chart.timeScale(),ser=p._series,top=this._top;
        target.useMediaCoordinateSpace(function(scope){
            const ctx=scope.context,W=scope.mediaSize.width;
            const rgba=function(hex,a){const h=hex.replace('#','');return 'rgba('+parseInt(h.substr(0,2),16)+','+parseInt(h.substr(2,2),16)+','+parseInt(h.substr(4,2),16)+','+a.toFixed(3)+')';};
            const X=function(i){return ts.logicalToCoordinate(i);};
            const Y=function(v){return (v===undefined||isNaN(v))?null:ser.priceToCoordinate(v);};
            const vr=ts.getVisibleLogicalRange();
            let a=0,b=r.n-1+12;
            if(vr){a=Math.max(0,Math.floor(vr.from)-2);b=Math.ceil(vr.to)+2;}
            const fmtV=function(v){return v>=1e9?(v/1e9).toFixed(2)+'B':v>=1e6?(v/1e6).toFixed(2)+'M':v>=1e3?(v/1e3).toFixed(1)+'K':String(Math.round(v));};
            if(!top){
                // هیت‌مپ فعلی (کل پنجره‌ی Period) با گرادیان از خاکستری تا رنگ داغ
                const pf=r.profile;
                if(pf&&pf.max>0){
                    const xa=X(pf.start),xb=X(r.n-1+10);
                    if(xa!==null&&xb!==null){
                        for(let k=0;k<pf.vols.length;k++){
                            const it=pf.vols[k]/pf.max;
                            if(it<0.12)continue;
                            const y1=Y(pf.wl+k*pf.bs),y2=Y(pf.wl+(k+1)*pf.bs);
                            if(y1===null||y2===null)continue;
                            ctx.fillStyle=it<0.6?'rgba(160,160,160,'+(0.04+0.12*it).toFixed(3)+')':rgba(s.heat,s.opacity*(0.25+0.45*it));
                            ctx.fillRect(Math.max(xa,-5),Math.min(y1,y2),Math.min(xb,W+5)-Math.max(xa,-5),Math.max(1,Math.abs(y2-y1)));
                        }
                    }
                }
                // زون‌های داغ تاریخی (هر سگمنت)
                for(const sg of r.segs){
                    if(sg.e<a||sg.s>b)continue;
                    const x1=X(sg.s),x2=X(sg.e);
                    if(x1===null||x2===null)continue;
                    for(const z of sg.zones){
                        const y1=Y(z.top),y2=Y(z.bottom);
                        if(y1===null||y2===null)continue;
                        ctx.fillStyle=rgba(s.heat,s.opacity*0.45*z.inten);
                        ctx.fillRect(x1,Math.min(y1,y2),Math.max(1,x2-x1),Math.max(1,Math.abs(y2-y1)));
                    }
                }
                return;
            }
            // ---- POC هموارشده
            if(s.showPoc){
                ctx.strokeStyle=s.pocCol;ctx.lineWidth=2;ctx.lineJoin='round';
                ctx.beginPath();let started=false;
                for(let i=Math.max(0,a);i<=Math.min(r.n-1,b);i++){
                    if(isNaN(r.poc[i])){started=false;continue;}
                    const x=X(i),y=Y(r.poc[i]);
                    if(x===null||y===null){started=false;continue;}
                    if(!started){ctx.moveTo(x,y);started=true;}else ctx.lineTo(x,y);
                }
                ctx.stroke();
            }
            // ---- عدد حجم زون‌ها
            if(s.showVol){
                ctx.fillStyle=s.volCol;ctx.font='9px sans-serif';ctx.textAlign='right';ctx.textBaseline='middle';
                for(const L of r.volLabels){
                    const x=X(L.x),y=Y(L.y);
                    if(x===null||y===null||x<0||x>W+40)continue;
                    ctx.fillText(fmtV(L.vol),Math.min(x,W)-3,y);
                }
            }
            // ---- لیبل‌های Retest
            ctx.font='10px sans-serif';ctx.textBaseline='middle';
            for(const L of r.labels){
                if(L.idx<a||L.idx>b)continue;
                const x=X(L.idx),y=Y(L.price);
                if(x===null||y===null)continue;
                ctx.fillStyle=L.dir===1?s.rtUp:s.rtDn;
                ctx.textAlign='center';
                ctx.fillText(L.text,x,L.dir===1?y+12:y-12);
            }
            // ---- سیگنال‌های Buy / Sell
            if(s.sig){
                ctx.textAlign='center';
                for(const S of r.signals){
                    if(S.idx<a||S.idx>b)continue;
                    const x=X(S.idx),y=Y(S.price);
                    if(x===null||y===null)continue;
                    const up=S.dir===1,bw=34,bh=16,gap=7;
                    const y0=up?y+gap:y-gap-bh;
                    ctx.fillStyle=up?s.buy:s.sell;
                    ctx.beginPath();
                    if(ctx.roundRect){ctx.roundRect(x-bw/2,y0,bw,bh,4);}else{ctx.rect(x-bw/2,y0,bw,bh);}
                    ctx.fill();
                    ctx.beginPath();
                    if(up){ctx.moveTo(x-4,y+gap);ctx.lineTo(x,y+2);ctx.lineTo(x+4,y+gap);}
                    else{ctx.moveTo(x-4,y-gap);ctx.lineTo(x,y-2);ctx.lineTo(x+4,y-gap);}
                    ctx.closePath();ctx.fill();
                    ctx.fillStyle='#ffffff';ctx.font='bold 10px sans-serif';
                    ctx.fillText(up?'BUY':'SELL',x,y0+bh/2+0.5);
                }
            }
        });
    }
}
class IhPaneView{
    constructor(p,top){this._p=p;this._top=top;}
    zOrder(){return this._top?'top':'bottom';}
    renderer(){return new IhRenderer(this._p,this._top);}
}
class IhPrimitive{
    constructor(){this._data=null;this._chart=null;this._series=null;this._req=null;this._views=[new IhPaneView(this,false),new IhPaneView(this,true)];}
    attached(param){this._chart=param.chart;this._series=param.series;this._req=param.requestUpdate;}
    detached(){this._chart=null;this._series=null;this._req=null;}
    paneViews(){return this._views;}
    updateAllViews(){}
    setData(r){this._data=r;if(this._req)this._req();}
}

function ihRemove(){
    if(ihPrimitive&&candleSeries){try{candleSeries.detachPrimitive(ihPrimitive);}catch(e){}}
    ihPrimitive=null;
    ihResult=null;
    lzVotes[2]=null;
}

function drawImpulseHM(d){
    if(!chart||!candleSeries||!d||d.length<35){return null;}
    try{
        const s=ihReadSettings();
        ihResult=calcImpulseHM(d,s);
        if(!ihPrimitive){
            ihPrimitive=new IhPrimitive();
            candleSeries.attachPrimitive(ihPrimitive);
        }
        try{
            const ro=chart.timeScale().options().rightOffset;
            if(ro===undefined||ro<6)chart.timeScale().applyOptions({rightOffset:6});
        }catch(e){}
        ihPrimitive.setData(ihResult);
        // رأی P2: آخرین سیگنال Buy/Sell در ۱۰ کندل اخیر
        const last=ihResult.signals.length?ihResult.signals[ihResult.signals.length-1]:null;
        lzVotes[2]=(last&&last.idx>=d.length-10)?(last.dir===1?'long':'short'):null;
        console.log('=== P2 Impulse Heatmap: '+ihResult.segs.length+' سگمنت | '+ihResult.signals.length+' سیگنال ===');
        return ihResult;
    }catch(err){
        console.error('خطای کلی در drawImpulseHM:',err);
        return null;
    }
}

function ihRedraw(){
    if(ihEnabled&&currentCandles.length>0)drawImpulseHM(currentCandles);
}

function toggleImpulseHM(){
    ihEnabled=!ihEnabled;
    const btn=document.getElementById('btnLzRun2');
    if(ihEnabled){
        if(btn){btn.classList.add('active');btn.textContent='⏹ حذف';}
        if(currentCandles.length>0)setTimeout(function(){drawImpulseHM(currentCandles);},50);
    }else{
        if(btn){btn.classList.remove('active');btn.textContent='▶ اجرا';}
        ihRemove();
    }
}

// ==================== گروه Lorentzian: ۷ اندیکاتور P1..P7 ====================
// P4 = اندیکاتور Lorentzian فعلی (toggleProF). بقیه فعلاً خالی‌اند.
const LZ_COUNT=7;
const lzWeights={};   // ضریب هر اندیکاتور (پیش‌فرض 1)
for(let i=1;i<=LZ_COUNT;i++)lzWeights[i]=1;
const lzVotes={};     // نتیجه‌ی آخرین اجرا: {i: 'long'|'short'|null}

// ==================== P5: Pro Scalper (تقریبی - بر اساس توضیحات عمومی؛ کد اصلی invite-only و قفل است) ====================
// Kalman روی hl2 -> سوپرترند با ATR -> سیگنال BUY/SELL روی فلیپ جهت
// باندهای VWMA (روی High/Low با ضریب ATR) -> ناحیه خرید/فروش بیش‌ازحد
// R: بازگشت از باند (قرمز=نزولی، سبز=صعودی) | X: تیک پروفیت وقتی قیمت به باند مقابل می‌رسد
let psEnabled=false;
let psResult=null;
let psSeriesList=[];
let psPriceLines=[];

function psNum(id,def){const e=document.getElementById(id);if(!e)return def;const v=parseFloat(e.value);return isNaN(v)?def:v;}
function psChk(id,def){const e=document.getElementById(id);return e?e.checked:def;}
function psReadSettings(){
    return {Q:psNum('setPsQ',0.01),R:psNum('setPsR',0.5),atrLen:Math.max(2,Math.round(psNum('setPsAtrLen',10))),mult:psNum('setPsMult',3),vLen:Math.max(2,Math.round(psNum('setPsVLen',20))),bMult:psNum('setPsBandMult',1.5),showR:psChk('setPsShowR',true),showX:psChk('setPsShowX',true)};
}

function psKalman(values,Q,R){
    const out=new Array(values.length);
    let x=values[0],p=1;
    for(let i=0;i<values.length;i++){
        const z=values[i];
        if(i===0){out[i]=z;continue;}
        const pp=p+Q;
        const K=pp/(pp+R);
        x=x+K*(z-x);
        p=(1-K)*pp;
        out[i]=x;
    }
    return out;
}

function psAtrArr(d,len){
    const n=d.length,out=new Array(n).fill(NaN);
    let rma=NaN,sum=0;
    for(let i=0;i<n;i++){
        const tr=(i===0)?(d[i].high-d[i].low):Math.max(d[i].high-d[i].low,Math.abs(d[i].high-d[i-1].close),Math.abs(d[i].low-d[i-1].close));
        if(i<len-1){sum+=tr;}
        else if(i===len-1){sum+=tr;rma=sum/len;out[i]=rma;}
        else{rma=(rma*(len-1)+tr)/len;out[i]=rma;}
    }
    return out;
}

function psVwma(vals,vols,len){
    const n=vals.length,out=new Array(n).fill(NaN);
    for(let i=len-1;i<n;i++){
        let sv=0,sw=0;
        for(let j=i-len+1;j<=i;j++){const w=vols[j]>0?vols[j]:1;sv+=vals[j]*w;sw+=w;}
        out[i]=sw>0?sv/sw:NaN;
    }
    return out;
}

function calcProScalper(d,s){
    const n=d.length;
    const res={markers:[],up:[],dn:[],ob:[],os:[],lastSig:null,sigs:[]};
    const s0=s||psReadSettings();
    const Q=s0.Q,R=s0.R,atrLen=s0.atrLen,mult=s0.mult,vLen=s0.vLen,bMult=s0.bMult,showR=s0.showR,showX=s0.showX;
    if(n<Math.max(atrLen,vLen)+5)return res;

    const hl2=d.map(c=>(c.high+c.low)/2);
    const src=psKalman(hl2,Q,R);
    const atr=psAtrArr(d,atrLen);
    const vols=d.map(c=>c.volume||0);
    const vH=psVwma(d.map(c=>c.high),vols,vLen);
    const vL=psVwma(d.map(c=>c.low),vols,vLen);

    // سوپرترند روی منبع Kalman
    let fu=NaN,fl=NaN,dir=1;
    const dirs=new Array(n).fill(0);
    for(let i=0;i<n;i++){
        if(!isFinite(atr[i]))continue;
        const bu=src[i]+mult*atr[i],bl=src[i]-mult*atr[i];
        if(!isFinite(fu)){fu=bu;fl=bl;dir=d[i].close>=src[i]?1:-1;}
        else{
            const pc=d[i-1].close;
            fu=(bu<fu||pc>fu)?bu:fu;
            fl=(bl>fl||pc<fl)?bl:fl;
            if(dir===-1&&d[i].close>fu)dir=1;
            else if(dir===1&&d[i].close<fl)dir=-1;
        }
        dirs[i]=dir;
        const stv=dir===1?fl:fu;
        if(dir===1)res.up.push({time:d[i].time,value:stv});else res.dn.push({time:d[i].time,value:stv});
        // باندهای بیش‌ازحد/کم‌ازحد
        if(isFinite(vH[i])&&isFinite(vL[i])){
            res.ob.push({time:d[i].time,value:vH[i]+bMult*atr[i]});
            res.os.push({time:d[i].time,value:vL[i]-bMult*atr[i]});
        }
    }

    // سیگنال‌ها + R + X (حلقه‌ی ترتیبی تا وضعیت باز را نگه داریم)
    let inOB=false,inOS=false,longAct=false,shortAct=false;
    for(let i=1;i<n;i++){
        if(!isFinite(atr[i])||dirs[i]===0||dirs[i-1]===0)continue;
        const c=d[i],t=c.time;
        const ob=isFinite(vH[i])?vH[i]+bMult*atr[i]:NaN;
        const os=isFinite(vL[i])?vL[i]-bMult*atr[i]:NaN;

        // سیگنال فلیپ سوپرترند
        if(dirs[i]!==dirs[i-1]){
            res.sigs.push({idx:i,dir:dirs[i]===1?1:-1});
            if(dirs[i]===1){
                res.markers.push({time:t,position:'belowBar',color:'#00e676',shape:'arrowUp',text:'PS BUY'});
                res.lastSig={dir:'long',idx:i};
                longAct=true;shortAct=false;
            }else{
                res.markers.push({time:t,position:'aboveBar',color:'#ff1744',shape:'arrowDown',text:'PS SELL'});
                res.lastSig={dir:'short',idx:i};
                shortAct=true;longAct=false;
            }
        }

        // R: بازگشت از باند بیش‌ازحد / کم‌ازحد
        if(isFinite(ob)){
            if(inOB&&c.close<ob){
                if(showR)res.markers.push({time:t,position:'aboveBar',color:'#ff1744',shape:'circle',text:'R'});
                inOB=false;
            }else if(c.close>ob)inOB=true;
        }
        if(isFinite(os)){
            if(inOS&&c.close>os){
                if(showR)res.markers.push({time:t,position:'belowBar',color:'#00e676',shape:'circle',text:'R'});
                inOS=false;
            }else if(c.close<os)inOS=true;
        }

        // X: تیک پروفیت وقتی قیمت به باند مقابل برسد
        if(showX){
            if(longAct&&isFinite(ob)&&c.high>=ob){
                res.markers.push({time:t,position:'aboveBar',color:'#ffd54f',shape:'circle',text:'X'});
                longAct=false;
            }
            if(shortAct&&isFinite(os)&&c.low<=os){
                res.markers.push({time:t,position:'belowBar',color:'#ffd54f',shape:'circle',text:'X'});
                shortAct=false;
            }
        }
    }
    return res;
}

function removeProScalperSeries(){
    psSeriesList.forEach(s=>{try{chart.removeSeries(s);}catch(e){}});
    psSeriesList=[];
    psPriceLines.forEach(p=>{try{candleSeries.removePriceLine(p);}catch(e){}});
    psPriceLines=[];
}

function drawProScalper(d){
    if(!chart||!candleSeries||!d||d.length<10)return null;
    try{
        removeProScalperSeries();
        psResult=calcProScalper(d);
        const line=(color,style)=>chart.addLineSeries({color:color,lineWidth:2,lineStyle:style||0,priceLineVisible:false,lastValueVisible:false,crosshairMarkerVisible:false});
        const su=line('#00e676');su.setData(psResult.up);psSeriesList.push(su);
        const sd=line('#ff1744');sd.setData(psResult.dn);psSeriesList.push(sd);
        if(psChk('setPsBands',true)){
            const ob=line('rgba(255,82,82,0.6)',2);ob.setData(psResult.ob);psSeriesList.push(ob);
            const os=line('rgba(0,230,118,0.6)',2);os.setData(psResult.os);psSeriesList.push(os);
        }
        updateAllMarkers();
        const ls=psResult.lastSig;
        const n=d.length;
        lzVotes[5]=(ls&&ls.idx>=n-10)?ls.dir:null;
        console.log('=== P5 Pro Scalper: '+psResult.markers.length+' نشانگر ===');
        return psResult;
    }catch(err){
        console.error('خطای کلی در drawProScalper:',err);
        return null;
    }
}

function psRedraw(){
    if(psEnabled&&currentCandles.length>0)drawProScalper(currentCandles);
}

function toggleProScalper(){
    psEnabled=!psEnabled;
    const btn=document.getElementById('btnLzRun5');
    if(psEnabled){
        if(btn){btn.classList.add('active');btn.textContent='⏹ حذف';}
        if(currentCandles.length>0)setTimeout(function(){drawProScalper(currentCandles);},50);
    }else{
        if(btn){btn.classList.remove('active');btn.textContent='▶ اجرا';}
        psResult=null;
        removeProScalperSeries();
        lzVotes[5]=null;
        updateAllMarkers();
    }
}

// ==================== P7: Swift Algo X (تقریبی - بر اساس توضیحات عمومی؛ کد اصلی closed-source است) ====================
// فشار جهت‌دار حجمی -> شتاب (EMA سریع - EMA کند) -> نرمال‌سازی با انحراف معیار و ATR -> پروجکشن روی High/Low
// -> EMA مرجع -> باند ATR با ratchet -> BUY/SELL روی فلیپ باند + فیلتر EMA مرجع (+ فیلتر روند اختیاری)
// SL = کف/سقف ساختار اخیر | TP = RR × فاصله SL
let sxEnabled=false;
let sxResult=null;
let sxSeries=[];
let sxPriceLines=[];

function sxReadSettings(){
    const v=function(id,def){const e=document.getElementById(id);if(!e)return def;const x=parseFloat(e.value);return isNaN(x)?def:x;};
    const c=document.getElementById('setSxUseTrend');
    return {
        pressLen:Math.max(1,Math.round(v('setSxPressLen',5))),
        fastLen:Math.max(1,Math.round(v('setSxFast',5))),
        slowLen:Math.max(2,Math.round(v('setSxSlow',20))),
        sdLen:Math.max(2,Math.round(v('setSxSd',50))),
        atrLen:Math.max(2,Math.round(v('setSxAtr',14))),
        refLen:Math.max(1,Math.round(v('setSxRef',21))),
        mult:v('setSxMult',2),
        structLen:Math.max(1,Math.round(v('setSxStruct',10))),
        rr:v('setSxRR',1.5),
        maxSl:v('setSxMaxSl',0),
        useTrend:c?!!c.checked:false,
        trendLen:Math.max(2,Math.round(v('setSxTrendLen',200)))
    };
}

function sxEma(arr,p){
    const n=arr.length,out=new Array(n);
    const k=2/(p+1);
    let e=arr[0];
    for(let i=0;i<n;i++){
        if(i>0)e=arr[i]*k+e*(1-k);
        out[i]=e;
    }
    return out;
}

function calcSwiftAlgoX(d,s){
    const n=d.length;
    const res={sigs:[],markers:[],up:[],dn:[],lastTrade:null};
    const warm=Math.max(s.slowLen,s.sdLen,s.trendLen,s.atrLen,s.refLen)+s.pressLen+5;
    if(n<warm)return res;

    // ۱) فشار جهت‌دار حجمی (بدون حجم، وزن هر کندل ۱ در نظر گرفته می‌شود)
    const vols=d.map(c=>(c.volume>0?c.volume:1));
    const dirVal=d.map((c,i)=>(c.close>=c.open?1:-1)*(c.high-c.low)*vols[i]);
    const press=new Array(n).fill(0);
    let sv=0,sw=0;
    for(let i=0;i<n;i++){
        sv+=dirVal[i];sw+=vols[i];
        if(i>=s.pressLen){sv-=dirVal[i-s.pressLen];sw-=vols[i-s.pressLen];}
        press[i]=(i>=s.pressLen-1&&sw>0)?sv/sw:0;
    }

    // ۲) شتاب: اختلاف EMA سریع و کند فشار
    const fastE=sxEma(press,s.fastLen),slowE=sxEma(press,s.slowLen);
    const spread=fastE.map((v,i)=>v-slowE[i]);

    // ۳) نرمال‌سازی با انحراف معیار خودش و سپس مقیاس ATR
    const atr=psAtrArr(d,s.atrLen);
    const scaled=new Array(n).fill(0);
    let s1=0,s2=0;
    for(let i=0;i<n;i++){
        s1+=spread[i];s2+=spread[i]*spread[i];
        if(i>=s.sdLen){const o=spread[i-s.sdLen];s1-=o;s2-=o*o;}
        if(i>=s.sdLen-1){
            const m=s1/s.sdLen;
            const sd=Math.sqrt(Math.max(0,s2/s.sdLen-m*m));
            const z=sd>0?spread[i]/sd:0;
            scaled[i]=isFinite(atr[i])?z*atr[i]:0;
        }
    }

    // ۴) پروجکشن روی High (صعودی) یا Low (نزولی) و EMA مرجع
    const proj=d.map((c,i)=>(spread[i]>=0?c.high:c.low)+scaled[i]);
    const ref=sxEma(proj,s.refLen);

    // ۵) باند ATR حول مرجع با ratchet (شبیه سوپرترند ولی روی مرجع، نه قیمت)
    const dirs=new Array(n).fill(0),line=new Array(n).fill(NaN);
    let fu=NaN,fl=NaN,dir=1;
    for(let i=0;i<n;i++){
        if(!isFinite(atr[i]))continue;
        const bu=ref[i]+s.mult*atr[i],bl=ref[i]-s.mult*atr[i];
        if(!isFinite(fu)){
            fu=bu;fl=bl;dir=d[i].close>=ref[i]?1:-1;
        }else{
            const pc=d[i-1].close;
            fu=(bu<fu||pc>fu)?bu:fu;
            fl=(bl>fl||pc<fl)?bl:fl;
            if(dir===-1&&d[i].close>fu)dir=1;
            else if(dir===1&&d[i].close<fl)dir=-1;
        }
        dirs[i]=dir;
        line[i]=dir===1?fl:fu;
    }

    // ۶) سیگنال روی فلیپ باند + فیلترها + SL/TP
    const trend=s.useTrend?sxEma(d.map(c=>c.close),s.trendLen):null;
    for(let i=1;i<n;i++){
        if(!dirs[i]||!dirs[i-1]||dirs[i]===dirs[i-1])continue;
        const c=d[i];
        const up=dirs[i]===1;
        if(up&&!(c.close>ref[i]))continue;
        if(!up&&!(c.close<ref[i]))continue;
        if(trend){
            if(up&&c.close<=trend[i])continue;
            if(!up&&c.close>=trend[i])continue;
        }
        let lo=Infinity,hi=-Infinity;
        for(let j=Math.max(0,i-s.structLen+1);j<=i;j++){
            if(d[j].low<lo)lo=d[j].low;
            if(d[j].high>hi)hi=d[j].high;
        }
        const entry=c.close;
        const sl=up?lo:hi;
        const risk=up?entry-sl:sl-entry;
        if(!(risk>0))continue;
        if(s.maxSl>0&&risk/entry*100>s.maxSl)continue;
        const tp=up?entry+s.rr*risk:entry-s.rr*risk;

        let outcome='open',outIdx=-1;
        for(let j=i+1;j<n;j++){
            const x=d[j];
            if(up){
                if(x.low<=sl){outcome='SL';outIdx=j;break;}
                if(x.high>=tp){outcome='TP';outIdx=j;break;}
            }else{
                if(x.high>=sl){outcome='SL';outIdx=j;break;}
                if(x.low<=tp){outcome='TP';outIdx=j;break;}
            }
        }
        const dN=up?1:-1;
        res.sigs.push({idx:i,dir:dN});
        res.markers.push({time:c.time,position:up?'belowBar':'aboveBar',color:up?'#00e676':'#ff1744',shape:up?'arrowUp':'arrowDown',text:up?'SX BUY':'SX SELL'});
        if(outIdx>=0){
            res.markers.push({time:d[outIdx].time,position:outcome==='TP'?'aboveBar':'belowBar',color:outcome==='TP'?'#ffd54f':'#ff5252',shape:'circle',text:outcome});
        }
        res.lastTrade={dir:dN,entry:entry,sl:sl,tp:tp,idx:i,outcome:outcome,outIdx:outIdx};
    }

    // خطوط باند (سبز صعودی / قرمز نزولی) با نقطه‌ی فاصله برای جدا شدن سگمنت‌ها
    for(let i=0;i<n;i++){
        if(!isFinite(line[i])){res.up.push({time:d[i].time});res.dn.push({time:d[i].time});continue;}
        if(dirs[i]===1){res.up.push({time:d[i].time,value:line[i]});res.dn.push({time:d[i].time});}
        else{res.dn.push({time:d[i].time,value:line[i]});res.up.push({time:d[i].time});}
    }
    return res;
}

function removeSwiftSeries(){
    sxSeries.forEach(s=>{try{chart.removeSeries(s);}catch(e){}});
    sxSeries=[];
    sxPriceLines.forEach(p=>{try{candleSeries.removePriceLine(p);}catch(e){}});
    sxPriceLines=[];
}

function drawSwiftAlgo(d){
    if(!chart||!candleSeries||!d||d.length<10)return null;
    try{
        removeSwiftSeries();
        sxResult=calcSwiftAlgoX(d,sxReadSettings());
        const mkS=function(color){return chart.addLineSeries({color:color,lineWidth:2,priceLineVisible:false,lastValueVisible:false,crosshairMarkerVisible:false});};
        const a=mkS('#00e676');a.setData(sxResult.up);sxSeries.push(a);
        const b=mkS('#ff1744');b.setData(sxResult.dn);sxSeries.push(b);
        const lt=sxResult.lastTrade;
        if(lt&&lt.outcome==='open'){
            sxPriceLines.push(candleSeries.createPriceLine({price:lt.entry,color:'#ffffff',lineWidth:1,lineStyle:0,title:'SX ENTRY'}));
            sxPriceLines.push(candleSeries.createPriceLine({price:lt.sl,color:'#ff1744',lineWidth:2,lineStyle:3,title:'SX SL'}));
            sxPriceLines.push(candleSeries.createPriceLine({price:lt.tp,color:'#00e676',lineWidth:1,lineStyle:2,title:'SX TP'}));
        }
        updateAllMarkers();
        console.log('=== P7 Swift Algo X: '+sxResult.sigs.length+' سیگنال ===');
        return sxResult;
    }catch(err){
        console.error('خطای کلی در drawSwiftAlgo:',err);
        return null;
    }
}

function sxRedraw(){
    if(sxEnabled&&currentCandles.length>0)drawSwiftAlgo(currentCandles);
}

function toggleSwiftAlgo(){
    sxEnabled=!sxEnabled;
    const btn=document.getElementById('btnLzRun7');
    if(sxEnabled){
        if(btn){btn.classList.add('active');btn.textContent='⏹ حذف';}
        if(currentCandles.length>0)setTimeout(function(){drawSwiftAlgo(currentCandles);},50);
    }else{
        if(btn){btn.classList.remove('active');btn.textContent='▶ اجرا';}
        sxResult=null;
        removeSwiftSeries();
        updateAllMarkers();
    }
}

// ==================== اجرای همه P1..P7 در پس‌زمینه با امتیاز وزنی ====================
// هر اندیکاتور فقط سیگنال‌هایش را می‌دهد (بدون رسم). وضعیت هر اندیکاتور در هر کندل = جهت آخرین سیگنالش
// (تا وقتی که عمرش از «عمر سیگنال» بیشتر نشده). امتیاز = Σ ضریب × وضعیت. وقتی امتیاز از آستانه عبور کند، سیگنال با امتیاز می‌آید.
let lzAllEnabled=false;
let lzAllResult=null;
let lzAllKey='';

function lzSetWeight(i){
    const e=document.getElementById('lzW'+i);
    const v=e?parseFloat(e.value):NaN;
    lzWeights[i]=isNaN(v)?0:Math.max(0,v);
    lzAllRedraw(false);
}

function lzOpenSettings(i){
    const panel=document.getElementById('settingsPanel');
    const btn=document.getElementById('btnSettings');
    if(!panel.classList.contains('open')){panel.classList.add('open');btn.classList.add('active');}
    const menu=document.getElementById('indicatorMenu');
    if(menu){menu.classList.remove('open');document.getElementById('btnIndicatorMenu').classList.remove('active');}
    const g=document.getElementById('grpP'+i);
    if(!g)return;
    g.scrollIntoView({behavior:'smooth',block:'start'});
    g.style.outline='2px solid #ffd54f';
    setTimeout(function(){g.style.outline='';},1500);
}

function lzCollectSignals(i,d,tfArg){
    try{
        if(i===1)return calcFvgOB(d,fvgReadSettings()).signals.map(s=>({idx:s.idx,dir:s.dir}));
        if(i===2)return calcImpulseHM(d,ihReadSettings()).signals.map(s=>({idx:s.idx,dir:s.dir}));
        if(i===3)return calcMlSt(d,mlstReadSettings()).shapes.map(s=>({idx:s.idx,dir:s.dir}));
        if(i===4){
            const tf=tfArg||currentTimeframe;
            const s=Object.assign({},pfSettings,pfProfileFor(tf),{tf:tf});
            const ed=pfEngineData(d,tf,s);
            return calcProF(ed,s,null).trades.map(t=>({idx:t.entryIdx,dir:t.dir==='long'?1:-1}));
        }
        if(i===5)return calcProScalper(d,psReadSettings()).sigs;
        if(i===6)return calcBrCh(d,brReadSettings()).shapes.map(s=>({idx:s.idx,dir:s.dir}));
        if(i===7)return calcSwiftAlgoX(d,sxReadSettings()).sigs;
    }catch(e){console.error('خطا در محاسبه P'+i+' برای اجرای همه:',e);}
    return [];
}

// ---- تنظیمات اجرای همه: بازه (کندل) و حداقل امتیاز وزنی برای سیگنال ----
function lzAllCfg(){
    const g=function(id,def){const e=document.getElementById(id);const x=e?parseFloat(e.value):NaN;return isNaN(x)?def:x;};
    const sc=document.getElementById('setLzAllStrict');
    return {win:Math.max(1,Math.round(g('setLzAllAge',10))),minW:g('setLzAllThr',4),strict:!!(sc&&sc.checked)};
}

var lzAllNames={1:'P1 FVG/OB',2:'P2 Impulse',3:'P3 ML-ST',4:'P4 Lorentzian',5:'P5 ProScalper',6:'P6 Smart',7:'P7 SwiftAlgoX'};

function lzAllCompute(d,tfArg){
    const n=d.length, cfg=lzAllCfg(), W=cfg.win;
    const longW=new Float64Array(n), shortW=new Float64Array(n);
    const longN=new Int16Array(n), shortN=new Int16Array(n);
    const contrib=[];
    for(let i=1;i<=LZ_COUNT;i++){
        const w=lzWeights[i]||0;
        if(!w)continue;
        const sigs=lzCollectSignals(i,d,tfArg).slice().sort(function(a,b){return a.idx-b.idx;});
        const st=new Int8Array(n);
        let p=0,cur=0,ci=-1e9;
        for(let t=0;t<n;t++){
            while(p<sigs.length&&sigs[p].idx<=t){cur=sigs[p].dir;ci=sigs[p].idx;p++;}
            st[t]=(t-ci<W)?cur:0; // سیگنالِ داخل بازه‌ی W کندل اخیر
            if(st[t]>0){longW[t]+=w;longN[t]++;}
            else if(st[t]<0){shortW[t]+=w;shortN[t]++;}
        }
        contrib.push({i:i,w:w,st:st});
    }
    // سیگنال ترکیبی وقتی می‌آید که امتیاز یک طرف به حداقل برسد و از طرف مقابل بیشتر باشد
    const markers=[],sigs=[];
    let prevL=false,prevS=false;
    for(let t=0;t<n;t++){
        const L=longW[t]>=cfg.minW&&(cfg.strict?shortW[t]===0:longW[t]>shortW[t]);
        const S=shortW[t]>=cfg.minW&&(cfg.strict?longW[t]===0:shortW[t]>longW[t]);
        if(L&&!prevL){
            sigs.push({t:t,dir:1});
            markers.push({time:d[t].time,position:'belowBar',color:'#00e676',shape:'arrowUp',text:'Σ LONG '+longW[t].toFixed(1)});
        }else if(S&&!prevS){
            sigs.push({t:t,dir:-1});
            markers.push({time:d[t].time,position:'aboveBar',color:'#ff1744',shape:'arrowDown',text:'Σ SHORT '+shortW[t].toFixed(1)});
        }
        prevL=L;prevS=S;
    }
    // وینریت: برد اگر بعد از W کندل، قیمت در جهت سیگنال باشد (سیگنال‌های آخرِ داده که W کندل بعدشان نیست کنار گذاشته می‌شوند)
    let tot=0,wins=0;
    for(const s of sigs){
        if(s.t+W>=n)continue;
        tot++;
        const a=d[s.t].close,b=d[s.t+W].close;
        if((s.dir>0&&b>a)||(s.dir<0&&b<a))wins++;
    }
    return {markers:markers,sigs:sigs,longW:longW,shortW:shortW,longN:longN,shortN:shortN,contrib:contrib,
        stats:{tot:tot,wins:wins,rate:tot?wins/tot*100:null},
        last:{score:longW[n-1]-shortW[n-1],states:contrib.map(function(c){return {i:c.i,s:c.st[n-1]};})}};
}

function lzEnsureBoxes(){
    const wrap=document.getElementById('chartWrap');
    if(!wrap)return null;
    wrap.style.position='relative';
    if(!document.getElementById('lzWinBox')){
        const b=document.createElement('div');
        b.id='lzWinBox';
        b.style.cssText='position:absolute;top:8px;left:8px;z-index:20;background:rgba(10,20,30,0.88);color:#cfe3ee;border:1px solid #00838f;border-radius:6px;padding:6px 10px;font-size:12px;direction:rtl;pointer-events:none;display:none;';
        wrap.appendChild(b);
    }
    if(!document.getElementById('lzDetailBox')){
        const b=document.createElement('div');
        b.id='lzDetailBox';
        b.style.cssText='position:absolute;top:8px;right:8px;z-index:21;background:rgba(10,20,30,0.95);color:#cfe3ee;border:1px solid #ffd54f;border-radius:6px;padding:8px 10px;font-size:12px;direction:rtl;min-width:220px;display:none;';
        wrap.appendChild(b);
    }
    return wrap;
}

function lzUpdateWinBox(){
    lzEnsureBoxes();
    const b=document.getElementById('lzWinBox');
    if(!b)return;
    if(!lzAllEnabled||!lzAllResult){b.style.display='none';return;}
    const cfg=lzAllCfg(),s=lzAllResult.stats;
    b.style.display='block';
    b.innerHTML='<b>⚡ اجرای ۷ اندیکاتور</b><br>بازه: '+cfg.win+' کندل | حداقل امتیاز: '+cfg.minW+
        '<br>سیگنال‌ها: '+s.tot+' | برد: '+s.wins+
        '<br>وینریت: <b>'+(s.rate===null?'—':s.rate.toFixed(1)+'٪')+'</b>'+
        '<br><span style="opacity:0.7">برد = قیمت بعد از '+cfg.win+' کندل در جهت سیگنال</span>';
}

function lzShowDetail(idx){
    const box=document.getElementById('lzDetailBox');
    if(!box||!lzAllResult)return;
    const sig=lzAllResult.sigs.find(function(s){return s.t===idx;});
    if(!sig){box.style.display='none';return;}
    const c=currentCandles[idx];
    let longs=0,shorts=0,none=0;
    let rows='';
    for(let i=1;i<=LZ_COUNT;i++){
        const cc=lzAllResult.contrib.find(function(x){return x.i===i;});
        if(!cc){rows+='<div style="opacity:0.5">⚪ '+lzAllNames[i]+': خاموش (ضریب ۰)</div>';none++;continue;}
        const s=cc.st[idx];
        if(s>0){longs++;rows+='<div style="color:#00e676">🟢 '+lzAllNames[i]+' (ض '+cc.w+'): لانگ</div>';}
        else if(s<0){shorts++;rows+='<div style="color:#ff5252">🔴 '+lzAllNames[i]+' (ض '+cc.w+'): شورت</div>';}
        else {none++;rows+='<div style="opacity:0.7">⚪ '+lzAllNames[i]+' (ض '+cc.w+'): هیچی نگفته</div>';}
    }
    const score=sig.dir>0?lzAllResult.longW[idx]:lzAllResult.shortW[idx];
    box.innerHTML='<div style="display:flex;justify-content:space-between;gap:10px;margin-bottom:4px"><b>'+
        (sig.dir>0?'🟢 سیگنال LONG':'🔴 سیگنال SHORT')+' | امتیاز '+score.toFixed(1)+
        '</b><span style="cursor:pointer" onclick="lzCloseDetail()">✕</span></div>'+
        '<div style="opacity:0.7;margin-bottom:6px">'+new Date(c.time*1000).toLocaleString()+'</div>'+
        rows+
        '<div style="margin-top:6px;border-top:1px solid #1a2a3a;padding-top:4px">لانگ: '+longs+' | شورت: '+shorts+' | بی‌نظر: '+none+'</div>';
    box.style.display='block';
}

function lzCloseDetail(){const b=document.getElementById('lzDetailBox');if(b)b.style.display='none';}
let lzAllClickInit=false;
function lzInitClick(){
    lzEnsureBoxes();
    if(lzAllClickInit||!chart)return;
    lzAllClickInit=true;
    chart.subscribeClick(function(param){
        if(!lzAllEnabled||!lzAllResult||!param||param.time===undefined||!currentCandles)return;
        const idx=currentCandles.findIndex(function(c){return c.time===param.time;});
        if(idx<0){const bx=document.getElementById('lzDetailBox');if(bx)bx.style.display='none';return;}
        lzShowDetail(idx);
    });
}

function lzAllRedraw(force){
    if(!lzAllEnabled||!currentCandles||!currentCandles.length)return;
    // فقط کندل‌های بسته‌شده استفاده می‌شوند (کندل در حال شکل‌گیری حذف می‌شود تا وینریت و سیگنال‌ها با هر رفرش تغییر نکنند)
    const d=currentCandles.slice(0,-1);
    if(d.length<50)return;
    const last=d[d.length-1];
    const vals=Array.prototype.map.call(document.querySelectorAll('#settingsPanel input, #settingsPanel select'),function(e){
        return (e.type==='checkbox')?(e.checked?'1':'0'):e.value;
    }).join('|');
    const wk=[1,2,3,4,5,6,7].map(function(i){return lzWeights[i];}).join(',');
    // کلید کش: فقط با بسته‌شدن کندل جدید یا تغییر تنظیمات دوباره محاسبه می‌شود (جلوگیری از گیر کردن هر ۵ ثانیه)
    const key=currentSymbol+'|'+currentTimeframe+'|'+d.length+'|'+last.time+'|'+wk+'|'+vals;
    if(!force&&key===lzAllKey)return;
    lzAllKey=key;
    lzAllResult=lzAllCompute(d);
    updateAllMarkers();
    lzUpdateWinBox();
    const info=document.getElementById('symbolInfo');
    if(info){
        info.textContent='⚡ اجرای همه | امتیاز آخر: '+lzAllResult.last.score.toFixed(2)+' | '+
            lzAllResult.last.states.map(function(s){return 'P'+s.i+':'+(s.s>0?'+':(s.s<0?'-':'0'));}).join(' ');
    }
    console.log('=== اجرای همه: '+lzAllResult.markers.length+' سیگنال امتیازی ===');
}

// ==================== تنظیم ضریب هوشمند و بهینه‌سازی تنظیمات (داده‌ی واقعی، سه‌بخشی، با تأیید نهایی) ====================
// داده: هر تایم‌فریم به اندازه‌ی بازه‌ی زمانی مناسب خودش از سرور گرفته می‌شود (LZ_TUNE_DAYS) و کندل در حال شکل‌گیری حذف می‌شود.
// LZ_TUNE_WARM کندل اول فقط برای گرم شدن اندیکاتورهاست و در شمارش نمی‌آید.
// تقسیم هر تایم‌فریم: ۶۰٪ اول = train (انتخاب) | ۲۰٪ بعد = val (تأیید انتخاب) | ۲۰٪ آخر = holdout (تأیید نهایی).
// holdout هرگز در انتخاب دیده نمی‌شود و فقط در پایان، برای تصمیم نهایی استفاده می‌شود.
// حالت «همه تایم‌فریم‌ها»: انتخاب و تأیید روی همه‌ی تایم‌فریم‌های LZ_TUNE_TFS (تجمیع‌شده)، تأیید نهایی روی holdout همان‌ها.
// حالت «یک تایم‌فریم» (مثلاً 5m): آن تایم‌فریم «تأییدکننده» است. انتخاب فقط از بقیه‌ی تایم‌فریم‌ها (train/val) می‌آید و
// تمام دیتای همان تایم‌فریم فقط برای تأیید نهایی استفاده می‌شود: یعنی می‌سنجیم آیا تنظیمی که روی تایم‌فریم‌های دیگر یاد گرفته شده، وینریت همین تایم‌فریم را بالا می‌برد.
var LZ_TUNE_TFS=['5m','15m','1h','4h','1d'];
// سرور حداکثر ۱۰ هزار کندل در هر درخواست می‌دهد؛ بازه‌ها طوری تنظیم شده‌اند که داخل همین سقف بمانند
var LZ_TUNE_DAYS={'1m':5,'5m':30,'15m':90,'30m':180,'1h':400,'4h':730,'1d':730,'1w':1825};
var LZ_TUNE_WARM=300;
var LZ_TUNE_MIN_N=20;
var lzTuneBusy=false;

// ---- انتخاب تایم‌فریم تمرکز: «all» = لیست پیش‌فرض | انتخاب تکی = آن تایم‌فریم تأییدکننده ----
var LZ_TUNE_TF_FOCUS='all';
function lzTuneTfList(){
    const sel=document.getElementById('lzTuneTfSelect');
    const v=(LZ_TUNE_TF_FOCUS!=='all')?LZ_TUNE_TF_FOCUS:(sel?sel.value:'all');
    if(v==='all')return LZ_TUNE_TFS.slice();
    return [v];
}
function lzTuneTfChanged(){
    const sel=document.getElementById('lzTuneTfSelect');
    LZ_TUNE_TF_FOCUS=sel?sel.value:'all';
    console.log('🕒 تمرکز بهینه‌سازی/تنظیم ضریب روی: '+(LZ_TUNE_TF_FOCUS==='all'?'همه تایم‌فریم‌ها ('+LZ_TUNE_TFS.join(', ')+')':LZ_TUNE_TF_FOCUS+' (تأییدکننده)'));
}
function lzTuneModeInfo(){
    const tfs=lzTuneTfList();
    if(tfs.length===1){
        const x=tfs[0];
        const sel=LZ_TUNE_TFS.filter(function(t){return t!==x;});
        return {confirm:x,selTfs:sel,gateTfs:[x],loadTfs:sel.concat([x])};
    }
    return {confirm:null,selTfs:LZ_TUNE_TFS.slice(),gateTfs:LZ_TUNE_TFS.slice(),loadTfs:LZ_TUNE_TFS.slice()};
}
function lzTuneModeText(mode){
    if(mode.confirm)return 'تأییدکننده: '+mode.confirm+' | انتخاب از: '+mode.selTfs.join(' , ');
    return 'حالت: همه تایم‌فریم‌ها ('+mode.selTfs.join(' , ')+')';
}
function lzTick(){return new Promise(function(r){setTimeout(r,0);});}
function lzTunePct(w,t){return t?(w/t*100).toFixed(1)+'٪ ('+t+')':'—';}

// ---- دیتا: بازه‌ی زمانی واقعی هر تایم‌فریم، بدون کندل در حال شکل‌گیری ----
function lzTuneBars(tf){return Math.ceil((LZ_TUNE_DAYS[tf]||30)*86400/PF_TF_SEC[tf]);}
async function lzTuneFetch(sym,tf,limit){
    const want=limit||Math.min(10000,lzTuneBars(tf)+LZ_TUNE_WARM+5);
    const res=await fetch('/api/candles?symbol='+encodeURIComponent(sym)+'&timeframe='+tf+'&limit='+want);
    const j=await res.json();
    if(!j.success||!j.data||!j.data.length)return null;
    const arr=j.data.filter(function(c){return c&&c.close>0;}).sort(function(a,b){return a.time-b.time;});
    return arr.slice(0,-1); // کندل آخر هنوز بسته نشده و حذف می‌شود
}
// بخش‌بندی زمانی: [start,t1)=train ، [t1,t2)=val ، [t2,end)=holdout ، [start,end)=کل بازه
function lzTuneSplit(tf,d){
    const bars=lzTuneBars(tf);
    const start=Math.max(Math.min(LZ_TUNE_WARM,d.length-1),d.length-bars);
    const span=d.length-start;
    return {tf:tf,d:d,seg:{start:start,t1:start+Math.floor(span*0.6),t2:start+Math.floor(span*0.8),end:d.length}};
}
async function lzTuneLoad(sym,tfs,box,label){
    const out={};
    for(const tf of tfs){
        box.innerHTML='⏳ '+label+': دریافت دیتای '+tf+' ('+(LZ_TUNE_DAYS[tf]||'?')+' روز) ...';
        await lzTick();
        const d=await lzTuneFetch(sym,tf);
        if(d&&d.length>LZ_TUNE_WARM+LZ_TUNE_MIN_N*3)out[tf]=lzTuneSplit(tf,d);
    }
    return out;
}
function lzTunePart(ds,part){
    const s=ds.seg;
    if(part==='train')return [s.start,s.t1];
    if(part==='val')return [s.t1,s.t2];
    if(part==='hold')return [s.t2,s.end];
    return [s.start,s.end];
}
function lzTuneWindowInfo(dsMap){
    return Object.keys(dsMap).map(function(tf){
        const s=dsMap[tf].seg;
        return tf+': '+LZ_TUNE_DAYS[tf]+' روز ('+(s.end-s.start)+' کندل)';
    }).join(' | ');
}

// شمارش برد/باخت سیگنال‌هایی که idx آن‌ها در [from,to) است و W کندل بعدشان داخل همان بازه است
function lzTuneRange(d,sigs,W,from,to){
    let tot=0,wins=0;
    for(const s of sigs){
        if(s.idx<from||s.idx+W>=to||s.idx+W>=d.length)continue;
        tot++;
        const a=d[s.idx].close,b=d[s.idx+W].close;
        if((s.dir>0&&b>a)||(s.dir<0&&b<a))wins++;
    }
    return {tot:tot,wins:wins};
}
// تجمیع چند تایم‌فریم روی یک بخش مشخص (train / val / hold / full)
function lzTuneCount(dsMap,sigsBy,W,tfs,part){
    let tot=0,wins=0;
    for(const tf of tfs){
        const ds=dsMap[tf];
        const pr=lzTunePart(ds,part);
        const r=lzTuneRange(ds.d,sigsBy[tf],W,pr[0],pr[1]);
        tot+=r.tot;wins+=r.wins;
    }
    return {tot:tot,wins:wins,wr:tot?wins/tot*100:null};
}

// همان منطق جمع‌کننده‌ی اجرای همه، ولی با ضریب دلخواه و تایم‌فریم مشخص
function lzTuneCombo(d,weights,W,minW,tf){
    const n=d.length;
    const longW=new Float64Array(n),shortW=new Float64Array(n);
    for(let i=1;i<=LZ_COUNT;i++){
        const w=weights[i]||0;
        if(!w)continue;
        const sigs=lzCollectSignals(i,d,tf).slice().sort(function(a,b){return a.idx-b.idx;});
        let p=0,cur=0,ci=-1e9;
        for(let t=0;t<n;t++){
            while(p<sigs.length&&sigs[p].idx<=t){cur=sigs[p].dir;ci=sigs[p].idx;p++;}
            const st=(t-ci<W)?cur:0;
            if(st>0)longW[t]+=w;
            else if(st<0)shortW[t]+=w;
        }
    }
    const out=[];
    let pL=false,pS=false;
    for(let t=0;t<n;t++){
        const L=longW[t]>=minW&&longW[t]>shortW[t];
        const S=shortW[t]>=minW&&shortW[t]>longW[t];
        if(L&&!pL)out.push({idx:t,dir:1});
        else if(S&&!pS)out.push({idx:t,dir:-1});
        pL=L;pS=S;
    }
    return out;
}

function lzSortSigs(s){return s.slice().sort(function(a,b){return a.idx-b.idx;});}
// نسخه‌ی سریع lzTuneCombo: سیگنال‌ها از قبل محاسبه شده‌اند؛ منطق امتیاز و آستانه دقیقاً همان است
function lzTuneComboFromStore(store,n,weights,W,minW,tf){
    const longW=new Float64Array(n),shortW=new Float64Array(n);
    for(let i=1;i<=LZ_COUNT;i++){
        const w=weights[i]||0;
        if(!w)continue;
        const sigs=store[i][tf];
        let p=0,cur=0,ci=-1e9;
        for(let t=0;t<n;t++){
            while(p<sigs.length&&sigs[p].idx<=t){cur=sigs[p].dir;ci=sigs[p].idx;p++;}
            const st=(t-ci<W)?cur:0;
            if(st>0)longW[t]+=w;
            else if(st<0)shortW[t]+=w;
        }
    }
    const out=[];
    let pL=false,pS=false;
    for(let t=0;t<n;t++){
        const L=longW[t]>=minW&&longW[t]>shortW[t];
        const S=shortW[t]>=minW&&shortW[t]>longW[t];
        if(L&&!pL)out.push({idx:t,dir:1});
        else if(S&&!pS)out.push({idx:t,dir:-1});
        pL=L;pS=S;
    }
    return out;
}

function lzTuneBoxEl(){
    let b=document.getElementById('lzTuneBox');
    if(!b){
        b=document.createElement('div');
        b.id='lzTuneBox';
        b.style.cssText='position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);z-index:100;background:#0d1620;color:#cfe3ee;border:1px solid #00838f;border-radius:8px;padding:10px 12px;font-size:12px;direction:rtl;max-width:92vw;max-height:70vh;overflow:auto;box-shadow:0 4px 20px rgba(0,0,0,0.6);display:none;';
        document.body.appendChild(b);
    }
    return b;
}

function lzTuneClose(){const b=document.getElementById('lzTuneBox');if(b)b.style.display='none';}

// ==================== بهینه‌سازی تنظیمات هر اندیکاتور ====================
// جستجوی coordinate-descent: هر پارامتر را در چند مقدار اطراف مقدار فعلی امتحان می‌کند و فقط اگر
// وینریت train بهتر شود و وینریت val نسبت به تنظیم فعلی پایین‌تر نیاید، می‌پذیرد. در پایان روی بخش نهایی
// (holdout یا کل تایم‌فریم تأییدکننده) با تنظیم فعلی مقایسه می‌شود؛ فقط در صورت بهتر بودن اعمال می‌شود.
var LZ_OPT_SPEC={
    1:[{id:'setFvgMinPct',int:false,min:0.01}],
    2:[{id:'setIhPeriod',int:true,min:5},{id:'setIhSmooth',int:true,min:1},{id:'setIhEma',int:true,min:5}],
    3:[{id:'setMlStAtr',int:true,min:2},{id:'setMlStFact',int:false,min:0.5},{id:'setMlStTrain',int:true,min:10}],
    4:[{id:'setPfMinScore',int:false,min:0},{id:'setPfAdxMin',int:false,min:0},{id:'setPfSlAtr',int:false,min:0.2},{id:'setPfStMult',int:false,min:0.5}],
    5:[{id:'setPsMult',int:false,min:0.5},{id:'setPsVLen',int:true,min:5},{id:'setPsBandMult',int:false,min:0.2},{id:'setPsAtrLen',int:true,min:2}],
    6:[{id:'setBrLen',int:true,min:2},{id:'setBrNormLen',int:true,min:10}],
    7:[{id:'setSxStruct',int:true,min:2},{id:'setSxRR',int:false,min:0.5},{id:'setSxMult',int:false,min:0.5},{id:'setSxSlow',int:true,min:5}]
};
var lzOptBusy=false;
var lzOptLog=[];

function lzOptApplyVals(i,spec,vals){
    spec.forEach(function(s,j){
        const el=document.getElementById(s.id);
        if(el)el.value=String(vals[j]);
    });
    if(i===4&&typeof pfReadSettingsFromUI==='function')pfReadSettingsFromUI();
}

function lzOptFinish(i,spec,vals){
    lzOptApplyVals(i,spec,vals);
    spec.forEach(function(s){
        const el=document.getElementById(s.id);
        if(el&&s.int!==undefined)el.dispatchEvent(new Event('change'));
    });
    if(i===4&&pfEnabled&&currentCandles.length){try{drawProF(currentCandles);}catch(e){console.error(e);}}
    lzAllKey='';
    if(lzAllEnabled)lzAllRedraw(true);
}

async function lzOptimize(i){
    if(lzTuneBusy||lzOptBusy)return;
    lzOptBusy=true;
    const box=lzTuneBoxEl();
    box.style.display='block';
    const spec=LZ_OPT_SPEC[i];
    const name=lzAllNames[i]||('P'+i);
    const closeLink='<span style="cursor:pointer" onclick="lzTuneClose()">بستن</span>';
    if(!spec){box.innerHTML='❌ '+name+' قابل بهینه‌سازی نیست.<br>'+closeLink;lzOptBusy=false;return;}
    const els=spec.map(function(s){return document.getElementById(s.id);});
    if(els.some(function(e){return !e;})){box.innerHTML='❌ ورودی‌های بهینه‌سازی '+name+' پیدا نشدند.<br>'+closeLink;lzOptBusy=false;return;}
    const cur=els.map(function(e){return parseFloat(e.value);});
    if(cur.some(function(x){return isNaN(x);})){box.innerHTML='❌ مقدار ورودی‌های '+name+' عددی نیست.<br>'+closeLink;lzOptBusy=false;return;}
    const origVals=els.map(function(e){return e.value;});
    const sym=currentSymbol,cfg=lzAllCfg(),W=cfg.win,MIN=LZ_TUNE_MIN_N;
    const mode=lzTuneModeInfo();
    const gatePart=mode.confirm?'full':'hold';
    let reason='',applied=false,best=null,base=null,gateB=null,gateN=null,evals=0,dsMap={};
    try{
        dsMap=await lzTuneLoad(sym,mode.loadTfs,box,name);
        const selTfs=mode.selTfs.filter(function(t){return dsMap[t];});
        const gateTfs=mode.gateTfs.filter(function(t){return dsMap[t];});
        if(!selTfs.length||!gateTfs.length){
            lzOptFinish(i,spec,origVals);
            box.innerHTML='❌ دیتای کافی برای بهینه‌سازی '+name+' دریافت نشد.<br>'+closeLink;
            lzOptBusy=false;return;
        }
        const cache={};
        const evalSel=function(vals){
            const key=vals.join(',');
            if(cache[key])return cache[key];
            lzOptApplyVals(i,spec,vals);
            const sigsBy={};
            for(const tf of selTfs)sigsBy[tf]=lzCollectSignals(i,dsMap[tf].d,tf);
            return (cache[key]={vals:vals.slice(),tr:lzTuneCount(dsMap,sigsBy,W,selTfs,'train'),va:lzTuneCount(dsMap,sigsBy,W,selTfs,'val')});
        };
        const evalGate=function(vals){
            lzOptApplyVals(i,spec,vals);
            const sigsBy={};
            for(const tf of gateTfs)sigsBy[tf]=lzCollectSignals(i,dsMap[tf].d,tf);
            return lzTuneCount(dsMap,sigsBy,W,gateTfs,gatePart);
        };

        base=evalSel(cur);
        evals=1;
        if(base.tr.tot<MIN||base.va.tot<MIN){
            reason='سیگنال کافی روی train/val نبود، تنظیمات فعلی حفظ شد';
        }else{
            const feasible=function(e){return e.tr.tot>=MIN&&e.va.tot>=MIN&&e.va.wr>=base.va.wr-1e-9;};
            const norm=function(s,x){return s.int?Math.max(s.min,Math.round(x)):Math.max(s.min,Math.round(x*100)/100);};
            best=base;
            for(let pass=0;pass<2;pass++){
                let improved=false;
                for(let j=0;j<spec.length;j++){
                    const x=best.vals[j];
                    const pool=(Math.abs(x)<1e-9)?[0.5,1,2]:[x*0.5,x*0.75,x*1.25,x*1.5];
                    for(const p of pool){
                        const v=best.vals.slice();
                        v[j]=norm(spec[j],p);
                        if(v[j]===best.vals[j])continue;
                        const e=evalSel(v);evals++;
                        if(feasible(e)&&e.tr.wr>best.tr.wr){best=e;improved=true;}
                        box.innerHTML='⏳ '+name+': جستجوی ضریب‌ها (ارزیابی '+evals+') ...';
                        await lzTick();
                    }
                }
                if(!improved)break;
            }
            if(best===base){
                reason='هیچ تنظیم دیگری روی train و تأیید val بهتر نشد، تنظیمات فعلی حفظ شد';
            }else{
                gateB=evalGate(cur);
                gateN=evalGate(best.vals);
                if(gateB.tot<MIN||gateN.tot<MIN)reason='سیگنال بخش نهایی کافی نبود، تنظیمات فعلی حفظ شد';
                else if(!(gateN.wr>gateB.wr))reason='روی بخش نهایی (داده‌ی ندیده) بهتر نشد، تنظیمات فعلی حفظ شد';
                else{applied=true;reason='اعمال شد: روی train و val و بخش نهایی بهتر شد';}
            }
        }
        const finalVals=applied?best.vals:origVals;
        lzOptFinish(i,spec,finalVals);
        if(applied)lzSaveParams(spec,finalVals);
        lzOptLog.push({i:i,name:name,applied:applied,reason:reason,orig:origVals.join(', '),best:(applied?best.vals:origVals).join(', ')});

        const paramsStr=function(vals){return spec.map(function(s,j){return s.id.replace('set','')+'='+vals[j];}).join(' | ');};
        const gateLbl=mode.confirm?'وینریت تأیید ('+mode.confirm+')':'وینریت نهایی (holdout)';
        box.innerHTML='<div style="display:flex;justify-content:space-between;gap:12px;margin-bottom:6px"><b>🎯 بهینه‌سازی '+name+'</b>'+
            '<span style="cursor:pointer" onclick="lzTuneClose()">✕</span></div>'+
            '<div style="opacity:0.75;margin-bottom:6px">'+lzTuneModeText(mode)+'<br>'+lzTuneWindowInfo(dsMap)+'<br>نماد: '+sym+' | بازه‌ی سیگنال: '+W+' کندل | ارزیابی: '+evals+' ترکیب</div>'+
            '<div>تنظیمات فعلی: '+paramsStr(origVals)+'</div>'+
            (best?'<div>بهترین ترکیب: <span style="color:#ffd54f">'+paramsStr(best.vals)+'</span></div>':'')+
            (base?'<div style="margin-top:6px">وینریت train (فعلی ← بهترین): '+lzTunePct(base.tr.wins,base.tr.tot)+(best?' ← '+lzTunePct(best.tr.wins,best.tr.tot):'')+'</div>'+
                  '<div>وینریت val (فعلی ← بهترین): '+lzTunePct(base.va.wins,base.va.tot)+(best?' ← '+lzTunePct(best.va.wins,best.va.tot):'')+'</div>':'')+
            (gateB?'<div>'+gateLbl+' (فعلی ← بهترین): '+lzTunePct(gateB.wins,gateB.tot)+' ← '+lzTunePct(gateN.wins,gateN.tot)+'</div>':'')+
            '<div style="margin-top:8px;border-top:1px solid #1a2a3a;padding-top:6px;color:'+(applied?'#00e676':'#ffd54f')+'">'+reason+'</div>';
    }catch(err){
        console.error('خطا در بهینه‌سازی '+name+':',err);
        lzOptFinish(i,spec,origVals);
        box.innerHTML='❌ خطا: '+(err&&err.message?err.message:err)+'<br>'+closeLink;
    }
    lzOptBusy=false;
}

// بهینه‌سازی همه‌ی اندیکاتورها پشت‌سرهم؛ هر کدام با همان قاعده اعمال یا حفظ می‌شود
async function lzOptimizeAll(){
    if(lzTuneBusy||lzOptBusy)return;
    lzOptLog=[];
    for(let i=1;i<=LZ_COUNT;i++){
        if(!LZ_OPT_SPEC[i])continue;
        await lzOptimize(i);
    }
    const box=lzTuneBoxEl();
    box.style.display='block';
    let rows='';
    lzOptLog.forEach(function(r){
        rows+='<tr><td style="padding:2px 5px">'+r.name+'</td>'+
            '<td style="padding:2px 5px;font-size:11px">'+r.orig+'</td>'+
            '<td style="padding:2px 5px;font-size:11px;color:#ffd54f">'+r.best+'</td>'+
            '<td style="padding:2px 5px;color:'+(r.applied?'#00e676':'#ffd54f')+'">'+(r.applied?'اعمال شد':'حفظ شد')+'</td></tr>';
    });
    box.innerHTML='<div style="display:flex;justify-content:space-between;gap:12px;margin-bottom:6px"><b>🎯 نتیجه‌ی بهینه‌سازی همه</b>'+
        '<span style="cursor:pointer" onclick="lzTuneClose()">✕</span></div>'+
        '<table style="border-collapse:collapse;width:100%"><tr style="opacity:0.7"><td style="padding:2px 5px">اندیکاتور</td><td style="padding:2px 5px">قبل</td><td style="padding:2px 5px">بهترین</td><td style="padding:2px 5px">وضعیت</td></tr>'+rows+'</table>'+
        '<div style="opacity:0.6;margin-top:6px">هر تنظیم فقط وقتی اعمال شده که روی train، val و بخش نهایی بهتر بوده. تنظیمات قبلی هر اندیکاتور در جدول آمده است.</div>';
}

// ==================== ذخیره‌ی تنظیمات بهینه‌شده و ریست (روی همین دستگاه، بعد از بستن برنامه هم می‌ماند) ====================
var LZ_KEY_PARAMS='lzTunedParams_v1',LZ_KEY_WEIGHTS='lzTunedWeights_v1';
function lzStoreGet(k){try{return JSON.parse(localStorage.getItem(k)||'null');}catch(e){return null;}}
function lzStoreSet(k,v){try{if(v===null)localStorage.removeItem(k);else localStorage.setItem(k,JSON.stringify(v));}catch(e){}}
function lzAllSpecIds(){const out=[];Object.keys(LZ_OPT_SPEC).forEach(function(i){LZ_OPT_SPEC[i].forEach(function(s){out.push(s.id);});});return out;}
// فقط وقتی بهینه‌سازی واقعاً اعمال شده ذخیره می‌شود
function lzSaveParams(spec,vals){
    const cur=lzStoreGet(LZ_KEY_PARAMS)||{};
    spec.forEach(function(s,j){cur[s.id]=String(vals[j]);});
    lzStoreSet(LZ_KEY_PARAMS,cur);
}
function lzSaveWeights(){
    const w={};for(let i=1;i<=LZ_COUNT;i++)w[i]=lzWeights[i];
    lzStoreSet(LZ_KEY_WEIGHTS,w);
}
function lzApplyStoredParams(){
    const cur=lzStoreGet(LZ_KEY_PARAMS);
    if(!cur)return;
    Object.keys(cur).forEach(function(id){const el=document.getElementById(id);if(el)el.value=String(cur[id]);});
    if(typeof pfReadSettingsFromUI==='function'){try{pfReadSettingsFromUI();}catch(e){}}
}
function lzApplyStoredWeights(){
    const w=lzStoreGet(LZ_KEY_WEIGHTS);
    if(!w)return;
    for(let i=1;i<=LZ_COUNT;i++){
        const v=parseFloat(w[i]);
        if(isNaN(v))continue;
        lzWeights[i]=Math.max(0,v);
        const e=document.getElementById('lzW'+i);
        if(e)e.value=String(lzWeights[i]);
    }
}
function lzRestoreTuned(){lzApplyStoredParams();lzApplyStoredWeights();}
// ریست: برگشت به مقدارهای اولیه‌ی همان فایل (value پیش‌فرض HTML)
function lzResetParams(){
    lzAllSpecIds().forEach(function(id){const el=document.getElementById(id);if(el)el.value=el.defaultValue;});
    lzStoreSet(LZ_KEY_PARAMS,null);
    if(typeof pfReadSettingsFromUI==='function'){try{pfReadSettingsFromUI();}catch(e){}}
    lzAllKey='';if(lzAllEnabled)lzAllRedraw(true);
    lzShowResetNote('تنظیمات بهینه‌سازی به حالت اولیه برگشت.');
}
function lzResetWeights(){
    for(let i=1;i<=LZ_COUNT;i++){lzWeights[i]=1;const e=document.getElementById('lzW'+i);if(e)e.value='1';}
    lzStoreSet(LZ_KEY_WEIGHTS,null);
    lzAllKey='';if(lzAllEnabled)lzAllRedraw(true);
    lzShowResetNote('ضریب‌های همه‌ی اندیکاتورها به ۱ برگشت.');
}
function lzShowResetNote(msg){
    const b=lzTuneBoxEl();
    b.style.display='block';
    b.innerHTML='<div style="margin-bottom:6px"><b>♻️ ریست</b></div><div>'+msg+'</div><div style="margin-top:8px;cursor:pointer" onclick="lzTuneClose()">بستن</div>';
}

// ==================== تنظیم ضریب هوشمند ====================
// ضریب هر اندیکاتور از وینریت train آن می‌آید. ترکیب پیشنهادی فقط وقتی جایگزین ضریب‌های فعلی می‌شود
// که هم روی val و هم روی بخش نهایی، وینریت ترکیب هفت اندیکاتور از ضریب‌های فعلی بالاتر باشد.
async function lzSmartTune(){
    if(lzTuneBusy||lzOptBusy)return;
    lzTuneBusy=true;
    const box=lzTuneBoxEl();
    box.style.display='block';
    const sym=currentSymbol;
    const cfg=lzAllCfg(),W=cfg.win,minW=cfg.minW,MIN=LZ_TUNE_MIN_N;
    const mode=lzTuneModeInfo();
    const gatePart=mode.confirm?'full':'hold';
    const closeLink='<span style="cursor:pointer" onclick="lzTuneClose()">بستن</span>';
    let dsMap={};
    try{
        dsMap=await lzTuneLoad(sym,mode.loadTfs,box,'تنظیم ضریب');
        const selTfs=mode.selTfs.filter(function(t){return dsMap[t];});
        const gateTfs=mode.gateTfs.filter(function(t){return dsMap[t];});
        if(!selTfs.length||!gateTfs.length){
            box.innerHTML='❌ دیتای کافی برای تنظیم ضریب دریافت نشد.<br>'+closeLink;
            lzTuneBusy=false;return;
        }

        // ۱) وینریت هر اندیکاتور روی train و val
        const per={},store={};
        const allTfs=Object.keys(dsMap);
        for(let i=1;i<=LZ_COUNT;i++){
            box.innerHTML='⏳ '+lzAllNames[i]+' ...';
            await lzTick();
            store[i]={};
            for(const tf of allTfs)store[i][tf]=lzSortSigs(lzCollectSignals(i,dsMap[tf].d,tf));
            per[i]={tr:lzTuneCount(dsMap,store[i],W,selTfs,'train'),va:lzTuneCount(dsMap,store[i],W,selTfs,'val')};
        }
        // ۲) ضریب پیشنهادی از وینریت train: کمتر از ۴۰٪ = ۰، ۵۰٪ = ۱، ۷۰٪ = ۳ (سقف). داده‌ی ناکافی = ۱
        const newW={};
        for(let i=1;i<=LZ_COUNT;i++){
            const p=per[i].tr;
            newW[i]=(p.tot<MIN)?1:Math.round(Math.max(0,Math.min(3,(p.wr-40)/10))*10)/10;
        }
        // ۳) ضریب‌های فعلی در برابر پیشنهادی: اول val، بعد بخش نهایی
        const curW={};
        for(let i=1;i<=LZ_COUNT;i++)curW[i]=lzWeights[i]||0;
        const ensemble=function(weights,part,tfs){
            const sigsBy={};
            for(const tf of tfs)sigsBy[tf]=lzTuneComboFromStore(store,dsMap[tf].d.length,weights,W,minW,tf);
            return lzTuneCount(dsMap,sigsBy,W,tfs,part);
        };
        const vB=ensemble(curW,'val',selTfs),vN=ensemble(newW,'val',selTfs);
        const gB=ensemble(curW,gatePart,gateTfs),gN=ensemble(newW,gatePart,gateTfs);
        const enough=vB.tot>=MIN&&vN.tot>=MIN&&gB.tot>=MIN&&gN.tot>=MIN;
        let applied=false,reason;
        if(!enough)reason='سیگنال ترکیب کافی نبود، ضریب‌های فعلی حفظ شد';
        else if(!(vN.wr>vB.wr))reason='روی بخش تأیید (val) بهتر نشد، ضریب‌های فعلی حفظ شد';
        else if(!(gN.wr>gB.wr))reason='روی بخش نهایی (داده‌ی ندیده) بهتر نشد، ضریب‌های فعلی حفظ شد';
        else{applied=true;reason='اعمال شد: روی val و بخش نهایی بهتر شد';}

        if(applied){
            for(let i=1;i<=LZ_COUNT;i++){
                lzWeights[i]=newW[i];
                const e=document.getElementById('lzW'+i);
                if(e)e.value=newW[i];
            }
            lzSaveWeights();
            lzAllKey='';
            if(lzAllEnabled)lzAllRedraw(true);
        }

        const pct=lzTunePct;
        let rows='';
        for(let i=1;i<=LZ_COUNT;i++){
            rows+='<tr><td style="padding:2px 6px">'+lzAllNames[i]+'</td>'+
                '<td style="padding:2px 6px">'+pct(per[i].tr.wins,per[i].tr.tot)+'</td>'+
                '<td style="padding:2px 6px">'+pct(per[i].va.wins,per[i].va.tot)+'</td>'+
                '<td style="padding:2px 6px;color:#ffd54f"><b>'+curW[i]+' ← '+newW[i]+'</b></td></tr>';
        }
        box.innerHTML='<div style="display:flex;justify-content:space-between;gap:12px;margin-bottom:6px"><b>🎯 نتیجه‌ی تنظیم ضریب هوشمند</b>'+
            '<span style="cursor:pointer" onclick="lzTuneClose()">✕</span></div>'+
            '<div style="opacity:0.75;margin-bottom:6px">'+lzTuneModeText(mode)+'<br>'+lzTuneWindowInfo(dsMap)+'<br>نماد: '+sym+' | بازه: '+W+' کندل</div>'+
            '<table style="border-collapse:collapse;width:100%"><tr style="opacity:0.7"><td style="padding:2px 6px">اندیکاتور</td><td style="padding:2px 6px">وینریت train</td><td style="padding:2px 6px">وینریت val</td><td style="padding:2px 6px">ضریب (فعلی ← جدید)</td></tr>'+rows+'</table>'+
            '<div style="margin-top:8px;border-top:1px solid #1a2a3a;padding-top:6px">ترکیب هفت اندیکاتور (فعلی ← جدید):<br>'+
            '• روی val: '+pct(vB.wins,vB.tot)+' ← '+pct(vN.wins,vN.tot)+'<br>'+
            '• روی '+(mode.confirm?'تأیید ('+mode.confirm+')':'بخش نهایی (holdout)')+': '+pct(gB.wins,gB.tot)+' ← '+pct(gN.wins,gN.tot)+'</div>'+
            '<div style="margin-top:6px;color:'+(applied?'#00e676':'#ffd54f')+'">'+reason+'</div>';
    }catch(err){
        console.error('خطا در تنظیم ضریب هوشمند:',err);
        box.innerHTML='❌ خطا: '+(err&&err.message?err.message:err)+'<br>'+closeLink;
    }
    lzTuneBusy=false;
}

// ==================== فیلتر وینریت: دو تعریف برد + جستجوی سخت‌گیری روی train، سنجش روی test ====================
// تعریف A: بعد از W کندل قیمت در جهت سیگنال است.
// تعریف B: معامله با حد ضرر (کف/سقف ساختار) و حد سود (RR×ریسک) سنجیده می‌شود؛ اگر هیچکدام زده نشد تا انتهای بخش، باخت حساب می‌شود.
var LZ_TRADE={rr:1.5,struct:10,minTrades:20,slAtr:0,atrLen:14};

function lzWinSim(d,sigs,W,from,to){
    let aT=0,aW=0,bT=0,bW=0;
    const n=d.length;
    const atrArr=LZ_TRADE.slAtr>0?psAtrArr(d,LZ_TRADE.atrLen):null;
    for(const s of sigs){
        const t=s.idx,dir=s.dir;
        if(t<from||t>=to)continue;
        if(t+W<to&&t+W<n){
            aT++;
            const a=d[t].close,b=d[t+W].close;
            if((dir>0&&b>a)||(dir<0&&b<a))aW++;
        }
        let lo=Infinity,hi=-Infinity;
        for(let j=Math.max(0,t-LZ_TRADE.struct+1);j<=t;j++){
            if(d[j].low<lo)lo=d[j].low;
            if(d[j].high>hi)hi=d[j].high;
        }
        const entry=d[t].close;
        const sl=(atrArr&&isFinite(atrArr[t]))?(dir>0?entry-LZ_TRADE.slAtr*atrArr[t]:entry+LZ_TRADE.slAtr*atrArr[t]):(dir>0?lo:hi);
        const risk=dir>0?entry-sl:sl-entry;
        if(!(risk>0))continue;
        const tp=dir>0?entry+LZ_TRADE.rr*risk:entry-LZ_TRADE.rr*risk;
        const end=Math.min(n-1,to-1);
        let res=0;
        for(let j=t+1;j<=end;j++){
            const x=d[j];
            if(dir>0){
                if(x.low<=sl){res=-1;break;}
                if(x.high>=tp){res=1;break;}
            }else{
                if(x.high>=sl){res=-1;break;}
                if(x.low<=tp){res=1;break;}
            }
        }
        if(res===0)continue;
        bT++;
        if(res===1)bW++;
    }
    return {A:{tot:aT,wins:aW},B:{tot:bT,wins:bW}};
}

// جمع‌کننده با سیگنال‌های از پیش‌محاسبه‌شده و حالت سخت‌گیرانه (فقط وقتی طرف مقابل صفر باشد)
function lzComboFromSigs(n,sigsByInd,W,minW,strict){
    const longW=new Float64Array(n),shortW=new Float64Array(n);
    for(let i=1;i<=LZ_COUNT;i++){
        const w=(lzWeights[i]!==undefined?lzWeights[i]:1);
        if(!w||!sigsByInd[i])continue;
        const sigs=sigsByInd[i];
        let p=0,cur=0,ci=-1e9;
        for(let t=0;t<n;t++){
            while(p<sigs.length&&sigs[p].idx<=t){cur=sigs[p].dir;ci=sigs[p].idx;p++;}
            const st=(t-ci<W)?cur:0;
            if(st>0)longW[t]+=w;
            else if(st<0)shortW[t]+=w;
        }
    }
    const out=[];
    let pL=false,pS=false;
    for(let t=0;t<n;t++){
        const L=longW[t]>=minW&&(strict?shortW[t]===0:longW[t]>shortW[t]);
        const S=shortW[t]>=minW&&(strict?longW[t]===0:shortW[t]>longW[t]);
        if(L&&!pL)out.push({idx:t,dir:1});
        else if(S&&!pS)out.push({idx:t,dir:-1});
        pL=L;pS=S;
    }
    return out;
}

async function lzWinFilter(){
    if(lzTuneBusy||lzOptBusy)return;
    lzTuneBusy=true;
    const box=lzTuneBoxEl();
    box.style.display='block';
    const sym=currentSymbol,W=lzAllCfg().win;
    const rrEl=document.getElementById('setLzAllRR'),slEl=document.getElementById('setLzAllSlAtr');
    LZ_TRADE.rr=rrEl?Math.max(0.1,parseFloat(rrEl.value)||1.5):1.5;
    LZ_TRADE.slAtr=slEl?Math.max(0,parseFloat(slEl.value)||0):0;
    try{
        const data={};
        for(const tf of lzTuneTfList()){
            box.innerHTML='⏳ دریافت دیتای '+tf+' ...';
            await new Promise(function(r){setTimeout(r,0);});
            const d=await lzTuneFetch(sym,tf,3000);
            if(d&&d.length>=200){
                const sigsByInd={};
                for(let i=1;i<=LZ_COUNT;i++){
                    box.innerHTML='⏳ '+tf+' | سیگنال '+(lzAllNames[i]||('P'+i))+' ...';
                    await new Promise(function(r){setTimeout(r,0);});
                    sigsByInd[i]=lzCollectSignals(i,d,tf).slice().sort(function(a,b){return a.idx-b.idx;});
                }
                data[tf]={d:d,sigs:sigsByInd,split:Math.floor(d.length*0.7)};
            }
        }
        const tfs=Object.keys(data);
        if(!tfs.length){
            box.innerHTML='❌ دیتایی دریافت نشد.<br><span style="cursor:pointer" onclick="lzTuneClose()">بستن</span>';
            lzTuneBusy=false;return;
        }
        const settings=[];
        [2,3,4,5,6].forEach(function(m){[false,true].forEach(function(s){settings.push({minW:m,strict:s});});});
        for(const st of settings){
            st.trA=0;st.trAW=0;st.trB=0;st.trBW=0;st.teA=0;st.teAW=0;st.teB=0;st.teBW=0;
            for(const tf of tfs){
                const D=data[tf];
                const sigs=lzComboFromSigs(D.d.length,D.sigs,W,st.minW,st.strict);
                const tr=lzWinSim(D.d,sigs,W,0,D.split);
                const te=lzWinSim(D.d,sigs,W,D.split,D.d.length);
                st.trA+=tr.A.tot;st.trAW+=tr.A.wins;st.trB+=tr.B.tot;st.trBW+=tr.B.wins;
                st.teA+=te.A.tot;st.teAW+=te.A.wins;st.teB+=te.B.tot;st.teBW+=te.B.wins;
            }
            box.innerHTML='⏳ سنجش سخت‌گیری '+st.minW+(st.strict?' (هم‌جهت)':'')+' ...';
            await new Promise(function(r){setTimeout(r,0);});
        }
        const pick=function(key,tot){
            let best=null;
            settings.forEach(function(s){
                if(s[tot]<LZ_TRADE.minTrades)return;
                if(!best||s[key]/s[tot]>best[key]/best[tot])best=s;
            });
            return best;
        };
        const bestB=pick('trBW','trB');
        const bestA=pick('trAW','trA');
        const pct=function(w,t){return t?(w/t*100).toFixed(1)+'٪ ('+t+')':'—';};
        // اعمال: سخت‌گیرِ انتخاب‌شده با تعریف B روی train
        if(bestB){
            const e=document.getElementById('setLzAllThr');if(e)e.value=String(bestB.minW);
            const c=document.getElementById('setLzAllStrict');if(c)c.checked=bestB.strict;
            lzAllKey='';
            if(lzAllEnabled)lzAllRedraw(true);
        }
        let rows='';
        settings.forEach(function(s){
            const mark=(bestB===s?' ◀ اعمال شد':'')+(bestA===s?' (بهترین A)':'');
            rows+='<tr><td style="padding:2px 5px">'+s.minW+(s.strict?' هم‌جهت':'')+'</td>'+
                '<td style="padding:2px 5px">'+pct(s.trAW,s.trA)+'</td><td style="padding:2px 5px">'+pct(s.teAW,s.teA)+'</td>'+
                '<td style="padding:2px 5px">'+pct(s.trBW,s.trB)+'</td><td style="padding:2px 5px">'+pct(s.teBW,s.teB)+'</td>'+
                '<td style="padding:2px 5px;opacity:0.8">'+mark+'</td></tr>';
        });
        const verdict=function(s,key,tot){
            if(!s)return 'تعداد معامله‌ی کافی در train نبود';
            const t=s['te'+key.slice(2)]; const tw=s['te'+key.slice(2)+'W']; const tt=s[tot.replace('tr','te')];
            return tt?(tw/tt*100>=60?'✅ روی test به ۶۰٪ رسید':'❌ روی test به ۶۰٪ نرسید'):'معامله‌ی کافی روی test نبود';
        };
        box.innerHTML='<div style="display:flex;justify-content:space-between;gap:12px;margin-bottom:6px"><b>🎯 فیلتر وینریت ('+sym+')</b>'+
            '<span style="cursor:pointer" onclick="lzTuneClose()">✕</span></div>'+
            '<div style="opacity:0.75;margin-bottom:6px">تایم‌فریم‌ها: '+tfs.join(' , ')+' | بازه: '+W+' کندل | '+(LZ_TRADE.slAtr>0?'حد ضرر: '+LZ_TRADE.slAtr+' ATR':'حد ضرر: ساختار '+LZ_TRADE.struct+' کندل')+' | ریوارد: '+LZ_TRADE.rr+'</div>'+
            '<table style="border-collapse:collapse;width:100%;font-size:11px"><tr style="opacity:0.7"><td style="padding:2px 5px">حداقل امتیاز</td><td style="padding:2px 5px">A train</td><td style="padding:2px 5px">A test</td><td style="padding:2px 5px">B train</td><td style="padding:2px 5px">B test</td><td></td></tr>'+rows+'</table>'+
            '<div style="margin-top:8px;border-top:1px solid #1a2a3a;padding-top:6px">'+
            (bestB?'اعمال‌شده (بر اساس B روی train): حداقل امتیاز '+bestB.minW+(bestB.strict?'، هم‌جهت':'')+'<br>'+
                'تعریف B روی test: '+pct(bestB.teBW,bestB.teB)+' → '+verdict(bestB,'trB','trB')+'<br>'+
                'تعریف A روی test: '+pct(bestB.teAW,bestB.teA)+' → '+verdict(bestB,'trA','trA')
                :'هیچ تنظیمی معامله‌ی کافی در train نداشت.')+
            '</div>'+
            '<div style="opacity:0.6;margin-top:6px">عددهای test ملاک واقعی‌اند. اگر زیر ۶۰٪ است، با این هفت اندیکاتور و این داده به ۶۰٪ نرسیدیم و هیچ تنظیمی این را تضمین نمی‌کند.</div>';
    }catch(err){
        console.error('خطا در فیلتر وینریت:',err);
        box.innerHTML='❌ خطا: '+(err&&err.message?err.message:err)+'<br><span style="cursor:pointer" onclick="lzTuneClose()">بستن</span>';
    }
    lzTuneBusy=false;
}

function lzRunAll(){
    lzAllEnabled=!lzAllEnabled;
    const btn=document.getElementById('btnLzAll');
    if(lzAllEnabled){
        if(btn){btn.classList.add('active');btn.textContent='⏹ توقف اجرای همه';}
        lzInitClick();
        lzAllRedraw(true);
    }else{
        if(btn){btn.classList.remove('active');btn.textContent='🚀 اجرای همه ۷ اندیکاتور (پس‌زمینه)';}
        lzAllResult=null;
        lzAllKey='';
        updateAllMarkers();
        lzUpdateWinBox();
        const dt=document.getElementById('lzDetailBox');if(dt)dt.style.display='none';
    }
}

function lzRunSingle(i){
    if(i===1)return toggleFvgOB();
    if(i===2)return toggleImpulseHM();
    if(i===3)return toggleMlSt();
    if(i===5)return toggleProScalper();
    if(i===7)return toggleSwiftAlgo();
    if(i===6)return toggleBrCh();
    /* TODO: اجرای تکی بقیه */ console.log('lzRunSingle',i);
}

function toggleProF(){
    pfEnabled=!pfEnabled;
    const btn=document.getElementById('btnPf');
    if(pfEnabled){
        btn.classList.add('active');
        btn.textContent='⏹ حذف';
        if(currentCandles.length>0){
            setTimeout(function(){ drawProF(currentCandles); },180);
        }
    }else{
        btn.classList.remove('active');
        btn.textContent='▶ اجرا';
        removeProF();
        updateAllMarkers();
    }
}

// ---------- بک‌تست اختصاصی: معاملات دقیقاً طبق منطق خود اندیکاتور (حد ضرر، TP1 جزئی، TP2، تریلینگ، فیلتر رژیم و تایید تایم‌فریم) ----------
function btRunPf(d,startIdx,o,htf,tf,sOver){
    const s=Object.assign({},pfSettings,pfProfileFor(tf||currentTimeframe),sOver||{},{tf:tf||currentTimeframe});
    const ed=pfEngineData(d,s.tf,s);
    const r=calcProF(ed,s,htf);
    const fee=(o.feePct||0)/100;
    const trades=[];
    r.trades.forEach(function(t){
        if(t.entryIdx<startIdx)return;
        if(o.longOnly&&t.dir==='short')return;
        const gross=t.R*t.risk/t.entry;
        trades.push({dir:t.dir,entryIdx:t.entryIdx,exitIdx:t.exitIdx,entry:t.entry,exit:t.exitPrice,ret:(gross-2*fee)*100,bars:t.exitIdx-t.entryIdx,reason:pfOutcomeFa(t.outcome),note:'PF '+t.type,open:t.open});
    });
    return btAggregate(d,trades,startIdx,trades.length);
}

// ---------- حفظ زوم و تنظیمات نمودار بعد از رفرش (خودکار هر ۵ ثانیه و رفرش کامل صفحه) ----------
function zoomLogicalToTime(d,x){
    const last=d.length-1;
    if(last<1)return d[0].time;
    const step=(d[last].time-d[0].time)/last;
    const idx=Math.round(x);
    if(idx<0)return d[0].time+idx*step;
    if(idx>last)return d[last].time+(idx-last)*step;
    return d[idx].time;
}
function zoomTimeToLogical(d,t){
    const last=d.length-1;
    if(last<1)return 0;
    const step=(d[last].time-d[0].time)/last;
    if(t<=d[0].time)return (t-d[0].time)/step;
    if(t>=d[last].time)return last+(t-d[last].time)/step;
    let lo=0,hi=last;
    while(hi-lo>1){const mid=(lo+hi)>>1;if(d[mid].time<=t)lo=mid;else hi=mid;}
    const span=d[hi].time-d[lo].time;
    return lo+(span>0?(t-d[lo].time)/span:0);
}
function zoomCapture(d){
    try{
        if(!chart||!d||d.length<2)return null;
        const lr=chart.timeScale().getVisibleLogicalRange();
        if(!lr)return null;
        const last=d.length-1;
        return {fromT:zoomLogicalToTime(d,lr.from),toT:zoomLogicalToTime(d,lr.to),edge:lr.to>=last-0.5,rightOff:lr.to-last,width:lr.to-lr.from};
    }catch(e){return null;}
}
function zoomApply(rec,d){
    try{
        if(!rec||!d||d.length<2)return false;
        let from,to;
        if(rec.edge){
            to=(d.length-1)+rec.rightOff;
            from=to-rec.width;
        }else{
            from=zoomTimeToLogical(d,rec.fromT);
            to=zoomTimeToLogical(d,rec.toT);
        }
        if(!isFinite(from)||!isFinite(to)||to-from<1)return false;
        // اگر بازه ذخیره‌شده کاملاً خارج از دیتای فعلی است، نادیده بگیر
        if(to<0||from>d.length+50)return false;
        chart.timeScale().setVisibleLogicalRange({from:from,to:to});
        return true;
    }catch(e){return false;}
}
function zoomKey(sym,tf){return 'chartZoom|'+sym+'|'+tf;}
function zoomReadStored(sym,tf){
    try{const r=localStorage.getItem(zoomKey(sym,tf));return r?JSON.parse(r):null;}catch(e){return null;}
}
let _zoomSaveTimer=null;
function zoomScheduleSave(){
    if(_zoomSaveTimer)clearTimeout(_zoomSaveTimer);
    _zoomSaveTimer=setTimeout(function(){
        try{
            const rec=zoomCapture(currentCandles);
            if(rec&&isFinite(rec.fromT)&&isFinite(rec.toT))localStorage.setItem(zoomKey(currentSymbol,currentTimeframe),JSON.stringify(rec));
        }catch(e){}
    },500);
}
function sessionSave(limit){
    try{localStorage.setItem('chartSession',JSON.stringify({symbol:currentSymbol,timeframe:currentTimeframe,limit:limit}));}catch(e){}
}
function sessionRestore(){
    try{
        const raw=localStorage.getItem('chartSession');
        if(!raw)return;
        const s=JSON.parse(raw);
        if(s.symbol&&typeof s.symbol==='string')currentSymbol=s.symbol;
        if(s.timeframe&&['1m','5m','15m','30m','1h','4h','1d'].indexOf(s.timeframe)>=0){
            currentTimeframe=s.timeframe;
            document.querySelectorAll('.tf-btn').forEach(function(b){b.classList.toggle('active',b.dataset.tf===s.timeframe);});
        }
        if(s.limit){
            const ls=document.getElementById('limitSelect');
            if(ls){const pv=ls.value;ls.value=s.limit;if(ls.value!==String(s.limit))ls.value=pv;}
        }
    }catch(e){}
}

function toggleBacktestPanel(){
    const m=document.getElementById('btModal');
    const open=!m.classList.contains('open');
    m.classList.toggle('open',open);
    if(open){
        const inp=document.getElementById('btSymbol');
        if(!inp.value)inp.value=currentSymbol;
        const dl=document.getElementById('btSymbolList');
        if(dl.childElementCount!==allSymbolsList.length){
            dl.innerHTML=allSymbolsList.map(s=>'<option value="'+s+'">').join('');
        }
        const tfSel=document.getElementById('btTimeframe');
        if(!tfSel.dataset.touched && BT_TF_SEC[currentTimeframe])tfSel.value=currentTimeframe;
        const menu=document.getElementById('indicatorMenu');
        if(menu){menu.classList.remove('open');document.getElementById('btnIndicatorMenu').classList.remove('active');}
    }
}

// سوئینگ‌های تاییدشده بدون ریپینت: پیوت i-right فقط وقتی در کندل i اعلام می‌شود که right کندل بعدش بسته شده باشد
function btConfirmedSwingSignals(d,left,right){
    const sig=[]; let lastType=null;
    for(let i=left+right;i<d.length;i++){
        const p=i-right; let isH=true,isL=true;
        for(let j=p-left;j<=i;j++){
            if(j===p)continue;
            if(d[j].high>=d[p].high)isH=false;
            if(d[j].low<=d[p].low)isL=false;
        }
        if(isH && lastType!=='high'){sig.push({idx:i,dir:'short',note:'سقف سوئینگ'});lastType='high';}
        else if(isL && lastType!=='low'){sig.push({idx:i,dir:'long',note:'کف سوئینگ'});lastType='low';}
    }
    return sig;
}

function btMarkersToSignals(d,markers,map){
    const ti={}; d.forEach((c,i)=>{ti[c.time]=i;});
    const out=[];
    (markers||[]).forEach(m=>{
        const base=m.baseText||m.text; const dir=map[base];
        if(dir && ti[m.time]!==undefined)out.push({idx:ti[m.time],dir:dir,note:base});
    });
    return out.sort((a,b)=>a.idx-b.idx);
}

function btLzSigs(i,d,o){
    const n=d.length,out=[];
    (lzCollectSignals(i,d,o.tf)||[]).forEach(function(s){
        if(!s||s.idx===undefined||s.idx<0||s.idx>=n)return;
        const up=(s.dir===1||s.dir==='long'||s.dir>0);
        out.push({idx:s.idx,dir:up?'long':'short',note:lzAllNames[i]});
    });
    return out.sort(function(a,b){return a.idx-b.idx;});
}

function btPNote(ind){
    if(/^p[1-7]$/.test(ind))return 'سیگنال‌ها دقیقاً همان سیگنال‌هایی‌اند که اندیکاتور روی چارت می‌دهد (ورود روی close همان کندل، بدون نگاه به آینده). چون این اندیکاتورها فقط رویداد می‌دهند، معامله تا سیگنال مخالف یا «خروج زمانی» باز می‌ماند.';
    if(ind==='pall')return 'سیگنال ترکیبی با ضریب‌ها و آستانه‌ی فعلی «اجرای همه» (Σ ضریب × وضعیت اندیکاتورها). ورود روی close کندلی که امتیاز به آستانه می‌رسد.';
    return '';
}

function btGenerateSignals(ind,d,startIdx,o){
    const ti={}; d.forEach((c,i)=>{ti[c.time]=i;});
    const pm=/^p([1-7])$/.exec(ind);
    if(pm)return btLzSigs(parseInt(pm[1],10),d,o);
    if(ind==='pall'){
        return lzAllCompute(d,o.tf).sigs.map(function(s){return {idx:s.t,dir:s.dir>0?'long':'short',note:'Σ ترکیب'};});
    }
    if(ind==='alpha')return btMarkersToSignals(d,calcAlphaRibbon(d,alphaSettings).markers,{'BUY':'long','SELL':'short','EXIT':'exit'});
    if(ind==='multilayer')return btMarkersToSignals(d,calcMultiLayer(d,multiLayerSettings).markers,{'ML-BUY':'long','ML-SELL':'short','ML-CLOSE':'exit'});
    if(ind==='zones')return btConfirmedSwingSignals(d,zonesSettings.pivotLeft||5,zonesSettings.pivotRight||5);
    if(ind==='fan')return btConfirmedSwingSignals(d,fanSettings.pivotLeft||5,fanSettings.pivotRight||5);
    if(ind==='signalfilter'){
        const data=calcSignalFilterData(d,signalFilterSettings);
        const th=signalFilterSettings.strongScore||2;
        const sig=[]; let state=0;
        for(let i=0;i<d.length;i++){
            const sc=signalFilterScoreAtIndex(data,i,d[i].close);
            if(sc>=th && state!==1){sig.push({idx:i,dir:'long',note:'امتیاز +'+sc});state=1;}
            else if(sc<=-th && state!==-1){sig.push({idx:i,dir:'short',note:'امتیاز '+sc});state=-1;}
            else if(Math.abs(sc)<th && state!==0 && Math.sign(sc)!==state){sig.push({idx:i,dir:'exit',note:'افت امتیاز'});state=0;}
        }
        return sig;
    }
    if(ind==='structure'){
        const right=5;
        const r=calcMarketStructure(d,{pivotLeft:5,pivotRight:right});
        const sig=[];
        r.boxes.forEach(b=>{
            let idx=ti[b.to]; const from=ti[b.from];
            if(idx===undefined||from===undefined)return;
            idx=Math.max(idx,from+right); // سقف/کف قبلی باید قبل از شکست تایید شده باشد
            if(idx<d.length)sig.push({idx:idx,dir:b.type==='bull'?'long':'short',note:'BOS '+(b.type==='bull'?'صعودی':'نزولی')});
        });
        return sig.sort((a,b)=>a.idx-b.idx);
    }
    if(ind==='aipath'){
        const closes=d.map(c=>c.close);
        const H=Math.max(2,o.aiH||10);
        const maxTests=150;
        const step=Math.max(H,Math.ceil((d.length-1-startIdx)/maxTests));
        const sig=[];
        for(let t=Math.max(startIdx,120);t<d.length-1;t+=step){
            const fc=analogForecast(closes.slice(0,t+1),H,aiPathSettings.analogK||7,1.0);
            const mv=fc.mult[H-1]-1;
            if(mv===0)continue;
            sig.push({idx:t,dir:mv>0?'long':'short',note:'پیش‌بینی '+(mv*100).toFixed(2)+'%'});
            if(t+H<d.length)sig.push({idx:t+H,dir:'exit',note:'پایان افق'});
        }
        return sig;
    }
    return [];
}

function btSimulate(d,signals,startIdx,o){
    const fee=(o.feePct||0)/100, sl=(o.slPct||0)/100, tp=(o.tpPct||0)/100;
    const trades=[]; let pos=null;
    const byIdx={}; signals.forEach(s=>{(byIdx[s.idx]=byIdx[s.idx]||[]).push(s);});
    function close(i,price,reason){
        const g=pos.dir==='long'?price/pos.entry-1:pos.entry/price-1;
        const net=(1+g)*(1-fee)*(1-fee)-1;
        trades.push({dir:pos.dir,entryIdx:pos.idx,exitIdx:i,entry:pos.entry,exit:price,ret:net*100,bars:i-pos.idx,reason:reason,note:pos.note});
        pos=null;
    }
    for(let i=startIdx;i<d.length;i++){
        const c=d[i];
        if(pos && i>pos.idx){ // حد ضرر قبل از حد سود چک می‌شود (فرض محافظه‌کارانه)
            if(pos.dir==='long'){
                if(sl&&c.low<=pos.entry*(1-sl))close(i,pos.entry*(1-sl),'حد ضرر');
                else if(tp&&c.high>=pos.entry*(1+tp))close(i,pos.entry*(1+tp),'حد سود');
            }else{
                if(sl&&c.high>=pos.entry*(1+sl))close(i,pos.entry*(1+sl),'حد ضرر');
                else if(tp&&c.low<=pos.entry*(1-tp))close(i,pos.entry*(1-tp),'حد سود');
            }
        }
        if(pos && o.holdBars && i>pos.idx && i-pos.idx>=o.holdBars)close(i,c.close,'خروج زمانی');
        const ss=byIdx[i]; if(!ss)continue;
        for(const s of ss){
            if(s.dir==='exit'){ if(pos)close(i,c.close,'سیگنال خروج'); continue; }
            if(pos && pos.dir===s.dir)continue;
            if(pos)close(i,c.close,'سیگنال مخالف');
            if(s.dir==='short' && o.longOnly)continue;
            pos={dir:s.dir,idx:i,entry:c.close,note:s.note};
        }
    }
    if(pos){ close(d.length-1,d[d.length-1].close,'باز (پایان دوره)'); trades[trades.length-1].open=true; }

    return btAggregate(d,trades,startIdx,signals.filter(s=>s.idx>=startIdx&&s.dir!=='exit').length);
}

function btAggregate(d,trades,startIdx,sigCount){
    const st={trades:trades,n:trades.length,signals:sigCount};
    let eq=1,peak=1,mdd=0,gp=0,gl=0,wins=0,bars=0,longN=0,best=-Infinity,worst=Infinity;
    const curve=[{t:d[startIdx].time,v:0}];
    trades.forEach(t=>{
        eq*=1+t.ret/100; peak=Math.max(peak,eq); mdd=Math.max(mdd,1-eq/peak);
        if(t.ret>0){wins++;gp+=t.ret;}else gl+=-t.ret;
        bars+=t.bars; if(t.dir==='long')longN++;
        best=Math.max(best,t.ret); worst=Math.min(worst,t.ret);
        curve.push({t:d[t.exitIdx].time,v:(eq-1)*100});
    });
    st.total=(eq-1)*100; st.mdd=mdd*100;
    st.winRate=st.n?wins/st.n*100:0;
    st.avg=st.n?trades.reduce((a,t)=>a+t.ret,0)/st.n:0;
    st.pf=gl>0?gp/gl:(gp>0?Infinity:0);
    st.avgBars=st.n?bars/st.n:0;
    st.longN=longN; st.shortN=st.n-longN;
    st.best=st.n?best:0; st.worst=st.n?worst:0;
    st.buyHold=(d[d.length-1].close/d[startIdx].close-1)*100;
    st.curve=curve;
    return st;
}

function btDrawCurve(canvas,curve,buyHoldPct){
    const dpr=window.devicePixelRatio||1;
    const W=canvas.clientWidth||900,H=canvas.clientHeight||180;
    canvas.width=W*dpr;canvas.height=H*dpr;
    const g=canvas.getContext('2d');g.scale(dpr,dpr);g.clearRect(0,0,W,H);
    if(curve.length<2){g.fillStyle='#667788';g.font='12px Tahoma';g.fillText('معامله‌ای برای رسم نیست',W/2-60,H/2);return;}
    const vals=curve.map(p=>p.v).concat([0,buyHoldPct]);
    let mn=Math.min(...vals),mx=Math.max(...vals); if(mx-mn<1e-9){mx+=1;mn-=1;}
    const pad=20,t0=curve[0].t,t1=curve[curve.length-1].t||t0+1;
    const X=t=>pad+(W-2*pad)*(t-t0)/((t1-t0)||1), Y=v=>H-pad-(H-2*pad)*(v-mn)/(mx-mn);
    g.strokeStyle='#33475b';g.setLineDash([4,4]);g.beginPath();g.moveTo(pad,Y(0));g.lineTo(W-pad,Y(0));g.stroke();
    g.strokeStyle='#ff9800';g.beginPath();g.moveTo(pad,Y(0));g.lineTo(W-pad,Y(buyHoldPct));g.stroke();g.setLineDash([]);
    g.strokeStyle=curve[curve.length-1].v>=0?'#00c853':'#ff5252';g.lineWidth=2;g.beginPath();
    curve.forEach((p,i)=>{const x=X(p.t),y=Y(p.v); i?g.lineTo(x,y):g.moveTo(x,y);}); g.stroke();
    g.fillStyle='#8899aa';g.font='10px Tahoma';
    g.fillText(mx.toFixed(1)+'%',4,pad-6);g.fillText(mn.toFixed(1)+'%',4,H-4);
    g.fillStyle='#ff9800';g.fillText('Buy & Hold',W-80,12);g.fillStyle='#00c853';g.fillText('استراتژی',W-150,12);
}

function btRender(res,meta,d){
    const pc=v=>(v>=0?'+':'')+v.toFixed(2)+'%';
    const cls=v=>v>=0?'pos':'neg';
    const prec=d[d.length-1].close<1?6:(d[d.length-1].close<100?4:2);
    const fd=t=>{try{return new Date(t*1000).toLocaleString('fa-IR',{year:'2-digit',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'});}catch(e){return t;}};
    let verdict,vcol;
    if(res.n<10){verdict='⚠️ تعداد معاملات خیلی کم است ('+res.n+')، نتیجه از نظر آماری معتبر نیست. بازه را طولانی‌تر یا تایم‌فریم را کوچک‌تر کن.';vcol='#ff9800';}
    else if(res.total>0 && res.pf>=1.3 && res.total>res.buyHold){verdict='✅ در این بازه سودده بوده و از Buy & Hold بهتر عمل کرده.';vcol='#00c853';}
    else if(res.total>0 && res.pf>=1){verdict='⚠️ سودده ولی ضعیف'+(res.total<=res.buyHold?' و از Buy & Hold عقب‌تر':'')+'.';vcol='#ffd54f';}
    else {verdict='❌ در این بازه ضررده بوده.';vcol='#ff5252';}
    const notes={
        zones:'سیگنال‌ها = برگشت سوئینگ زیگزاگ، با تاخیر تایید '+(zonesSettings.pivotRight||5)+' کندلی (نسخه بدون ریپینت؛ نمایش روی چارت ریپینت دارد و خوش‌بینانه‌تر به نظر می‌رسد).',
        fan:'سیگنال‌ها = برگشت سوئینگ‌های Fan، با تاخیر تایید '+(fanSettings.pivotRight||5)+' کندلی (بدون ریپینت).',
        structure:'ورود روی کندل شکست ساختار (BOS)، فقط بعد از تایید سقف/کف قبلی. معامله تا BOS مخالف باز می‌ماند.',
        signalfilter:'ورود وقتی امتیاز فیلتر به ±'+(signalFilterSettings.strongScore||2)+' برسد، خروج وقتی امتیاز افت کند.',
        aipath:'Walk-forward: در هر نقطه فقط دیتای گذشته دیده می‌شود، طبق جهت پیش‌بینی '+meta.aiH+' کندل معامله می‌شود.',
        pf:'ورود روی close کندل سیگنال (بدون ریپینت). Lorentzian: ورود روی فلیپ سیگنال ML با تایید کرنل؛ خروج بعد از ۴ کندل یا با فلیپ زودهنگام سیگنال مخالف (بدون حد ضرر، مثل نسخه اصلی). سود/زیان درصدی با کارمزد حساب می‌شود و حد ضرر/سود درصدی فرم نادیده گرفته می‌شود.',
        alpha:'ورود روی BUY/SELL، خروج روی EXIT یا سیگنال مخالف (با تنظیمات فعلی اندیکاتور).',
        multilayer:'ورود روی ML-BUY/ML-SELL، خروج روی ML-CLOSE یا سیگنال مخالف (با تنظیمات فعلی اندیکاتور).'
    };
    let h='<div class="btVerdict" style="border-color:'+vcol+';color:'+vcol+';">'+verdict+'</div>';
    h+='<div class="btNote">📌 '+BT_NAMES[meta.ind]+' | '+meta.symbol+' | '+meta.tf+' | '+meta.days+' روز گذشته ('+meta.periodCandles+' کندل تست + '+meta.warmup+' کندل گرم‌کردن'+(meta.cut?' | ⚠️ دیتای کامل در دسترس نبود، بازه کوتاه‌تر شد':'')+')<br>ℹ️ '+(notes[meta.ind]||btPNote(meta.ind)||'')+' کارمزد '+meta.fee+'٪ هر طرف لحاظ شده. نتیجه‌ی گذشته تضمین آینده نیست.</div>';
    const card=(k,v,c)=>'<div class="btCard"><div class="k">'+k+'</div><div class="v '+(c||'')+'">'+v+'</div></div>';
    h+='<div class="btGrid">'+
        card('سود/زیان کل',pc(res.total),cls(res.total))+
        card('Buy & Hold',pc(res.buyHold),cls(res.buyHold))+
        card('تعداد معاملات',res.n+' ('+res.longN+' خرید / '+res.shortN+' فروش)')+
        card('درصد برد',res.winRate.toFixed(1)+'%',res.winRate>=50?'pos':'neg')+
        card('Profit Factor',res.pf===Infinity?'∞':res.pf.toFixed(2),res.pf>=1?'pos':'neg')+
        card('میانگین هر معامله',pc(res.avg),cls(res.avg))+
        card('حداکثر افت (Drawdown)','-'+res.mdd.toFixed(2)+'%','neg')+
        card('بهترین / بدترین',pc(res.best)+' / '+pc(res.worst))+
        card('میانگین مدت معامله',res.avgBars.toFixed(1)+' کندل')+
    '</div>';
    h+='<canvas id="btCurve"></canvas>';
    if(res.n){
        h+='<div class="btTableWrap"><table><thead><tr><th>#</th><th>جهت</th><th>ورود</th><th>قیمت ورود</th><th>خروج</th><th>قیمت خروج</th><th>سود/زیان</th><th>کندل</th><th>دلیل خروج</th></tr></thead><tbody>';
        res.trades.slice().reverse().slice(0,300).forEach((t,k)=>{
            h+='<tr><td>'+(res.n-k)+'</td><td class="'+(t.dir==='long'?'pos':'neg')+'">'+(t.dir==='long'?'خرید':'فروش')+'</td><td>'+fd(d[t.entryIdx].time)+'</td><td>'+t.entry.toFixed(prec)+'</td><td>'+fd(d[t.exitIdx].time)+'</td><td>'+t.exit.toFixed(prec)+'</td><td class="'+cls(t.ret)+'">'+pc(t.ret)+'</td><td>'+t.bars+'</td><td>'+t.reason+'</td></tr>';
        });
        h+='</tbody></table></div>';
    }
    document.getElementById('btResult').innerHTML=h;
    btDrawCurve(document.getElementById('btCurve'),res.curve,res.buyHold);
}

async function runIndicatorBacktest(){
    const btn=document.getElementById('btRun'), status=document.getElementById('btStatus');
    const ind=document.getElementById('btIndicator').value;
    const symbol=(document.getElementById('btSymbol').value||currentSymbol).trim().toUpperCase();
    const tf=document.getElementById('btTimeframe').value;
    const days=parseInt(document.getElementById('btPeriod').value)||90;
    const o={
        feePct:Math.max(0,parseFloat(document.getElementById('btFee').value)||0),
        slPct:Math.max(0,parseFloat(document.getElementById('btSl').value)||0),
        tpPct:Math.max(0,parseFloat(document.getElementById('btTp').value)||0),
        aiH:Math.max(2,parseInt(document.getElementById('btAiH').value)||10),
        longOnly:document.getElementById('btLongOnly').checked,
        holdBars:Math.max(0,parseInt(document.getElementById('btHold').value)||0),
        tf:tf
    };
    let periodCandles=Math.ceil(days*86400/BT_TF_SEC[tf]);
    let cut=false;
    if(periodCandles+BT_WARMUP>BT_MAX_CANDLES){periodCandles=BT_MAX_CANDLES-BT_WARMUP;cut=true;}
    btn.disabled=true;
    document.getElementById('btResult').innerHTML='';
    status.textContent='⏳ در حال دریافت '+(periodCandles+BT_WARMUP)+' کندل '+symbol+' '+tf+' ...'+(cut?' (بازه به حداکثر '+BT_MAX_CANDLES+' کندل محدود شد)':'');
    try{
        const res=await fetch(`/api/candles?symbol=${encodeURIComponent(symbol)}&timeframe=${tf}&limit=${periodCandles+BT_WARMUP}`);
        const data=await res.json();
        if(!data.success||!data.data||data.data.length<150)throw new Error(data.error||'دیتای کافی دریافت نشد');
        const d=data.data.filter(c=>c&&c.close>0).sort((a,b)=>a.time-b.time);
        const startTime=d[d.length-1].time-days*86400;
        let startIdx=d.findIndex(c=>c.time>=startTime);
        if(startIdx<0)startIdx=0;
        if(startIdx<Math.min(BT_WARMUP,Math.floor(d.length/3))){startIdx=Math.min(BT_WARMUP,Math.floor(d.length/3));cut=true;}
        status.textContent='⚙️ محاسبه سیگنال‌ها و شبیه‌سازی معاملات روی '+d.length+' کندل ...';
        await new Promise(r=>setTimeout(r,30));
        const t0=performance.now();
        let result;
        if(ind==='pf'){
            const htfBt=await pfBtHtf(symbol,tf,d,Object.assign({},pfSettings,{tf:tf}));
            if(pfSettings.htfMode!=='off'&&(htfBt.failed.length||!htfBt.tfs.length)&&pfResolveHtfList(tf,pfSettings).length){status.textContent='⚠️ دیتای تایم‌فریم تایید کامل نیامد؛ بک‌تست با تایید ناقص انجام می‌شود';}
            result=btRunPf(d,startIdx,o,htfBt,tf);
        }
        else if(ind==='mybot'){result=btRunMyBot(d,startIdx,o);}
        else{const signals=btGenerateSignals(ind,d,startIdx,o);result=btSimulate(d,signals,startIdx,o);}
        const btMeta={ind:ind,symbol:symbol,tf:tf,days:days,periodCandles:d.length-startIdx,warmup:startIdx,cut:cut,fee:o.feePct,aiH:o.aiH};
        if(ind==='mybot')btRenderMyBot(result,btMeta,d);
        else btRender(result,btMeta,d);
        status.textContent='✅ انجام شد در '+((performance.now()-t0)/1000).toFixed(2)+' ثانیه | منبع دیتا: '+(data.exchange||'-')+(data.note?' | '+data.note:'');
    }catch(e){
        console.error('خطای بک‌تست:',e);
        status.textContent='❌ خطا: '+e.message;
    }finally{
        btn.disabled=false;
    }
}

// ---------- بک‌تست و مقایسه‌ی همه‌ی P1..P7 + ترکیب وزنی، روی یک دیتای یکسان؛ ۶۰٪ اول = «آموزش»، ۴۰٪ آخر = «تست دیده‌نشده» ----------
let lzCmpRows=null;
async function runLzCompareBacktest(){
    const btn=document.getElementById('btCmpP'),status=document.getElementById('btStatus');
    const symbol=(document.getElementById('btSymbol').value||currentSymbol).trim().toUpperCase();
    const tf=document.getElementById('btTimeframe').value;
    const days=parseInt(document.getElementById('btPeriod').value)||90;
    const o={
        feePct:Math.max(0,parseFloat(document.getElementById('btFee').value)||0),
        slPct:Math.max(0,parseFloat(document.getElementById('btSl').value)||0),
        tpPct:Math.max(0,parseFloat(document.getElementById('btTp').value)||0),
        aiH:10,
        longOnly:document.getElementById('btLongOnly').checked,
        holdBars:Math.max(0,parseInt(document.getElementById('btHold').value)||0),
        tf:tf
    };
    let periodCandles=Math.ceil(days*86400/BT_TF_SEC[tf]);
    let cut=false;
    if(periodCandles+BT_WARMUP>BT_MAX_CANDLES){periodCandles=BT_MAX_CANDLES-BT_WARMUP;cut=true;}
    btn.disabled=true;
    document.getElementById('btResult').innerHTML='';
    status.textContent='⏳ دریافت '+(periodCandles+BT_WARMUP)+' کندل '+symbol+' '+tf+' ...';
    try{
        const res=await fetch(`/api/candles?symbol=${encodeURIComponent(symbol)}&timeframe=${tf}&limit=${periodCandles+BT_WARMUP}`);
        const data=await res.json();
        if(!data.success||!data.data||data.data.length<150)throw new Error(data.error||'دیتای کافی دریافت نشد');
        const d=data.data.filter(c=>c&&c.close>0).sort((a,b)=>a.time-b.time);
        const out=lzCompareOnCandles(d,days,o);
        lzCmpRows=out.rows;
        lzCompareRender(out,symbol,tf,days,o,data);
        status.textContent='✅ انجام شد | منبع دیتا: '+(data.exchange||'-')+(cut?' | بازه به حداکثر کندل مجاز محدود شد':'');
    }catch(e){
        console.error('خطای مقایسه‌ی بک‌تست:',e);
        status.textContent='❌ خطا: '+e.message;
    }finally{
        btn.disabled=false;
    }
}

function lzCompareOnCandles(d,days,o){
    const startTime=d[d.length-1].time-days*86400;
    let startIdx=d.findIndex(c=>c.time>=startTime);
    if(startIdx<0)startIdx=0;
    const minStart=Math.min(BT_WARMUP,Math.floor(d.length/3));
    if(startIdx<minStart)startIdx=minStart;
    const splitIdx=startIdx+Math.floor((d.length-startIdx)*0.6);
    const keys=['p1','p2','p3','p4','p5','p6','p7','pall'];
    const rows=[];
    keys.forEach(function(k){
        let full=null,oos=null,err=null;
        try{
            const sigs=btGenerateSignals(k,d,startIdx,o);
            full=btSimulate(d,sigs,startIdx,o);
            oos=btSimulate(d,sigs,splitIdx,o);
        }catch(e){err=e.message;console.error('بک‌تست '+k+':',e);}
        rows.push({key:k,i:/^p[1-7]$/.test(k)?parseInt(k.slice(1),10):0,name:BT_NAMES[k],full:full,oos:oos,err:err});
    });
    return {rows:rows,startIdx:startIdx,splitIdx:splitIdx,d:d,
        bhFull:(d[d.length-1].close/d[startIdx].close-1)*100,bhOos:(d[d.length-1].close/d[splitIdx].close-1)*100};
}

function lzCompareRender(out,symbol,tf,days,o,data){
    const pc=v=>(v>=0?'+':'')+v.toFixed(2)+'%';
    const cls=v=>v>=0?'pos':'neg';
    const pfx=v=>v===Infinity?'∞':v.toFixed(2);
    const d=out.d;
    const fd=t=>{try{return new Date(t*1000).toLocaleDateString('fa-IR');}catch(e){return t;}};
    let h='<div class="btNote">📌 '+symbol+' | '+tf+' | '+days+' روز | آموزش: '+fd(d[out.startIdx].time)+' تا '+fd(d[out.splitIdx].time)+' ، تست دیده‌نشده: '+fd(d[out.splitIdx].time)+' تا '+fd(d[d.length-1].time)+'<br>ℹ️ همه‌ی اندیکاتورها با یک دیتا، یک کارمزد ('+o.feePct+'٪ هر طرف)'+(o.holdBars?'، خروج زمانی '+o.holdBars+' کندل':'، خروج با سیگنال مخالف')+(o.slPct?'، حد ضرر '+o.slPct+'٪':'')+(o.tpPct?'، حد سود '+o.tpPct+'٪':'')+' اجرا شده‌اند. Buy&Hold کل: '+pc(out.bhFull)+' | تست: '+pc(out.bhOos)+'. ستون‌های «تست» تنها عددی‌اند که برای آینده معنی دارند؛ عدد «کل» شامل بازه‌ای است که می‌شود تنظیمات را روی آن خوب کرد.</div>';
    h+='<div class="btTableWrap"><table><thead><tr><th>اندیکاتور</th><th>معاملات</th><th>برد٪</th><th>سود کل</th><th>PF</th><th>افت</th><th>معاملات تست</th><th>برد٪ تست</th><th>سود تست</th><th>PF تست</th></tr></thead><tbody>';
    const sorted=out.rows.slice().sort(function(a,b){const x=a.oos?a.oos.total:-1e9,y=b.oos?b.oos.total:-1e9;return y-x;});
    sorted.forEach(function(r){
        if(r.err||!r.full){h+='<tr><td>'+r.name+'</td><td colspan="9" class="neg">خطا: '+(r.err||'-')+'</td></tr>';return;}
        const f=r.full,t=r.oos;
        h+='<tr><td>'+r.name+'</td><td>'+f.n+'</td><td class="'+(f.winRate>=50?'pos':'neg')+'">'+f.winRate.toFixed(1)+'</td><td class="'+cls(f.total)+'">'+pc(f.total)+'</td><td class="'+(f.pf>=1?'pos':'neg')+'">'+pfx(f.pf)+'</td><td class="neg">-'+f.mdd.toFixed(1)+'%</td>'+
          '<td>'+t.n+'</td><td class="'+(t.winRate>=50?'pos':'neg')+'">'+t.winRate.toFixed(1)+'</td><td class="'+cls(t.total)+'">'+pc(t.total)+'</td><td class="'+(t.pf>=1?'pos':'neg')+'">'+pfx(t.pf)+'</td></tr>';
    });
    h+='</tbody></table></div>';
    const few=out.rows.filter(function(r){return r.oos&&r.oos.n<8;}).map(function(r){return r.name;});
    if(few.length)h+='<div class="btNote">⚠️ تعداد معاملات بخش تست کمتر از ۸ است برای: '+few.join('، ')+' ؛ نتیجه‌شان از نظر آماری قابل اتکا نیست. بازه را بلندتر یا تایم‌فریم را کوچک‌تر کن.</div>';
    h+='<button onclick="lzCmpApplyWeights()" style="margin-top:8px">⚖️ اعمال ضریب پیشنهادی (۲ / ۱ / ۰ بر اساس PF بخش تست)</button>';
    h+='<div class="btNote">ℹ️ ضریب پیشنهادی: PF تست ≥ 1.2 و سود مثبت → ۲، PF تست ≥ 1 → ۱، وگرنه ۰ (در ترکیب شرکت نمی‌کند). چون از همان بخش تست استفاده می‌کند، بعد از اعمال حتماً روی یک بازه/ارز دیگر هم بسنج.</div>';
    document.getElementById('btResult').innerHTML=h;
}

function lzCmpApplyWeights(){
    if(!lzCmpRows)return;
    lzCmpRows.forEach(function(r){
        if(!r.i||!r.oos)return;
        const t=r.oos;
        const w=(t.n>=5&&t.pf>=1.2&&t.total>0)?2:((t.n>=5&&t.pf>=1&&t.total>=0)?1:0);
        lzWeights[r.i]=w;
        const e=document.getElementById('lzW'+r.i);if(e)e.value=w;
    });
    if(typeof lzAllRedraw==='function'&&lzAllEnabled)lzAllRedraw(true);
    const st=document.getElementById('btStatus');
    if(st)st.textContent='✅ ضریب‌ها اعمال شد: '+lzCmpRows.filter(r=>r.i).map(r=>'P'+r.i+'='+lzWeights[r.i]).join(' ');
}

// ---------- مقایسه Pro F روی همه تایم‌فریم‌ها با بازه زمانی یکسان (برای اینکه ضعف/قوت هر تایم‌فریم با دیتای واقعی دیده شود) ----------
async function runPfTfScan(){
    const btn=document.getElementById('btScanPf'),runBtn=document.getElementById('btRun'),status=document.getElementById('btStatus');
    const symbol=(document.getElementById('btSymbol').value||currentSymbol).trim().toUpperCase();
    const days=parseInt(document.getElementById('btPeriod').value)||90;
    const o={feePct:Math.max(0,parseFloat(document.getElementById('btFee').value)||0),longOnly:document.getElementById('btLongOnly').checked};
    const tfs=['5m','15m','30m','1h','4h','1d'];
    const variants=[
        {name:'🧠 تنظیمات فعلی',s:Object.assign({},pfSettings)},
        {name:'Supertrend قدیمی (متعادل)',s:Object.assign({},pfSettings,PF_PRESETS.balanced,{minRiskAtr:0.8,setup:'trend'})}
    ];
    btn.disabled=true;runBtn.disabled=true;
    document.getElementById('btResult').innerHTML='';
    const rows=[];
    try{
        for(let q=0;q<tfs.length;q++){
            const tf=tfs[q];
            let periodCandles=Math.ceil(days*86400/BT_TF_SEC[tf]);
            if(periodCandles+BT_WARMUP>BT_MAX_CANDLES)periodCandles=BT_MAX_CANDLES-BT_WARMUP;
            status.textContent='⏳ ('+(q+1)+'/'+tfs.length+') دریافت و محاسبه '+symbol+' '+tf+' ...';
            let d;
            try{
                const res=await fetch('/api/candles?symbol='+encodeURIComponent(symbol)+'&timeframe='+tf+'&limit='+(periodCandles+BT_WARMUP));
                const data=await res.json();
                if(!data.success||!data.data||data.data.length<150)throw new Error('دیتا کافی نیست');
                d=data.data.filter(function(c){return c&&c.close>0;}).sort(function(a,b){return a.time-b.time;});
            }catch(e){rows.push({tf:tf,err:String(e&&e.message||e)});continue;}
            const startTime=d[d.length-1].time-days*86400;
            let startIdx=d.findIndex(function(c){return c.time>=startTime;});
            if(startIdx<0)startIdx=0;
            if(startIdx<Math.min(BT_WARMUP,Math.floor(d.length/3)))startIdx=Math.min(BT_WARMUP,Math.floor(d.length/3));
            const realDays=(d[d.length-1].time-d[startIdx].time)/86400;
            const vs=variants.slice();
            if(PF_TF_PROFILES[tf])vs.push({name:'🧬 پروفایل ذخیره‌شده',s:Object.assign({},pfSettings,PF_TF_PROFILES[tf])});
            for(let v=0;v<vs.length;v++){
                const s=Object.assign({},vs[v].s,{tf:tf});
                let htf={biases:[],tfs:[],waiting:[],failed:[]};
                if(s.htfMode!=='off'&&s.setup!=='lorentzian')htf=await pfBtHtf(symbol,tf,d,s);
                await new Promise(function(r){setTimeout(r,10);});
                const r=btRunPf(d,startIdx,o,htf,tf,vs[v].s);
                rows.push({tf:tf,v:v,name:vs[v].name,days:realDays,res:r});
            }
        }
        const pc=function(x){return (x>=0?'+':'')+x.toFixed(1)+'%';};
        let h='<div class="btNote">📌 Pro F | '+symbol+' | بازه درخواستی '+days+' روز (اگر تایم‌فریم کوچک بود و سقف '+BT_MAX_CANDLES+' کندل رسید، بازه واقعی در ستون «روز» دیده می‌شود) | کارمزد '+o.feePct+'٪ هر طرف. هر ردیف با تعداد معامله کم (زیر ۱۵) از نظر آماری قابل اتکا نیست.</div>';
        h+='<div class="btTableWrap"><table><thead><tr><th>TF</th><th>نسخه</th><th>روز</th><th>معامله</th><th>برد٪</th><th>PF</th><th>سود/زیان</th><th>Buy&amp;Hold</th><th>افت</th></tr></thead><tbody>';
        const win={};
        rows.forEach(function(x){
            if(x.err){h+='<tr><td>'+x.tf+'</td><td colspan="8">❌ '+x.err+'</td></tr>';return;}
            const r=x.res;
            win[x.name]=win[x.name]||0;
            if(r.total>0)win[x.name]++;
            h+='<tr><td>'+x.tf+'</td><td>'+x.name+'</td><td>'+x.days.toFixed(0)+'</td><td'+(r.n<15?' style="color:#ff9800"':'')+'>'+r.n+'</td><td class="'+(r.winRate>=50?'pos':'neg')+'">'+r.winRate.toFixed(0)+'</td><td class="'+(r.pf>=1?'pos':'neg')+'">'+(r.pf===Infinity?'∞':r.pf.toFixed(2))+'</td><td class="'+(r.total>=0?'pos':'neg')+'">'+pc(r.total)+'</td><td>'+pc(r.buyHold)+'</td><td class="neg">-'+r.mdd.toFixed(1)+'%</td></tr>';
        });
        h+='</tbody></table></div>';
        h+='<div class="btVerdict" style="border-color:#ffd54f;color:#ffd54f;">سودده بودن: '+Object.keys(win).map(function(k){return k+' در '+win[k]+' از '+tfs.length;}).join(' | ')+'</div>';
        document.getElementById('btResult').innerHTML=h;
        status.textContent='✅ مقایسه کامل شد';
    }catch(e){
        console.error('خطای مقایسه تایم‌فریم‌ها:',e);
        status.textContent='❌ خطا: '+(e&&e.message||e);
    }finally{
        btn.disabled=false;runBtn.disabled=false;
    }
}

// ---------- بهینه‌ساز Walk-Forward (دو فولد): انتخاب بهترین موتور/تنظیم هر تایم‌فریم + تست روی دیتای دیده‌نشده ----------
function pfPick(trades,a,b,longOnly){
    return trades.filter(function(t){return !t.open&&t.entryIdx>=a&&t.entryIdx<b&&!(longOnly&&t.dir==='short');});
}
function pfStatList(list,feePct){
    const fee=feePct/100;
    let eq=1,peak=1,mdd=0,gp=0,gl=0,w=0;
    list.forEach(function(t){
        const ret=(t.R*t.risk/t.entry-2*fee)*100;
        eq*=1+ret/100;if(eq>peak)peak=eq;mdd=Math.max(mdd,1-eq/peak);
        if(ret>0){w++;gp+=ret;}else gl+=-ret;
    });
    const n=list.length;
    return {n:n,total:(eq-1)*100,mdd:mdd*100,pf:gl>0?gp/gl:(gp>0?Infinity:0),win:n?w/n*100:0};
}
function pfBuildOptCombos(){
    const out=[];
    [2,3,4].forEach(function(a){[2,3.5,5].forEach(function(b){['all','flip'].forEach(function(c){[0,30].forEach(function(e){[1,2].forEach(function(f){
        out.push({setup:'trend',stMult:a,chMult:b,entryMode:c,tp1Pct:e,minRiskAtr:f});
    });});});});});
    [3,7].forEach(function(rl){[15,25].forEach(function(lo){['with','none'].forEach(function(tm){[0,2].forEach(function(bb){
        [{m:'atr',t:1},{m:'atr',t:1.8},{m:'mean',t:1}].forEach(function(ex){[2,3.5].forEach(function(sa){
            out.push({setup:'revert',rv_rsiLen:rl,rv_rsiLo:lo,rv_trendMode:tm,rv_bbK:bb,rv_exitMode:ex.m,rv_tgtAtr:ex.t,rv_stopAtr:sa});
        });});
    });});});});
    return out;
}
function pfDescribeParams(p){
    if(p.setup==='revert')return 'REV | RSI'+p.rv_rsiLen+'<'+p.rv_rsiLo+' | '+(p.rv_trendMode==='with'?'هم‌جهت روند':'بدون روند')+(p.rv_bbK>0?' | BB'+p.rv_bbK:'')+' | '+(p.rv_exitMode==='mean'?'خروج میانگین':'هدف '+p.rv_tgtAtr+'ATR')+' | SL '+p.rv_stopAtr+'ATR';
    return 'TREND | ST'+p.stMult+' CH'+p.chMult+' | '+p.entryMode+' | TP1:'+p.tp1Pct+'%';
}
window.pfLastOpt=[];
async function runPfTfOptimize(){
    const btn=document.getElementById('btOptPf'),b1=document.getElementById('btRun'),b2=document.getElementById('btScanPf'),status=document.getElementById('btStatus');
    const symbol=(document.getElementById('btSymbol').value||currentSymbol).trim().toUpperCase();
    const days=parseInt(document.getElementById('btPeriod').value)||90;
    const feePct=Math.max(0,parseFloat(document.getElementById('btFee').value)||0);
    const longOnly=document.getElementById('btLongOnly').checked;
    const tfs=['5m','15m','30m','1h','4h','1d'];
    const combos=pfBuildOptCombos();
    btn.disabled=true;b1.disabled=true;b2.disabled=true;
    document.getElementById('btResult').innerHTML='';
    const rows=[];
    try{
        for(let q=0;q<tfs.length;q++){
            const tf=tfs[q];
            let periodCandles=Math.ceil(days*86400/BT_TF_SEC[tf]);
            if(periodCandles+BT_WARMUP>BT_MAX_CANDLES)periodCandles=BT_MAX_CANDLES-BT_WARMUP;
            status.textContent='⏳ ('+(q+1)+'/'+tfs.length+') دریافت '+symbol+' '+tf+' ...';
            let d;
            try{
                const res=await fetch('/api/candles?symbol='+encodeURIComponent(symbol)+'&timeframe='+tf+'&limit='+(periodCandles+BT_WARMUP));
                const data=await res.json();
                if(!data.success||!data.data||data.data.length<150)throw new Error('دیتا کافی نیست');
                d=data.data.filter(function(c){return c&&c.close>0;}).sort(function(a,b){return a.time-b.time;});
            }catch(e){rows.push({tf:tf,err:String(e&&e.message||e)});continue;}
            const startTime=d[d.length-1].time-days*86400;
            let startIdx=d.findIndex(function(c){return c.time>=startTime;});
            if(startIdx<0)startIdx=0;
            if(startIdx<Math.min(BT_WARMUP,Math.floor(d.length/3)))startIdx=Math.min(BT_WARMUP,Math.floor(d.length/3));
            const n=d.length,L=n-startIdx;
            const s1=startIdx+Math.floor(L*0.5),s2=startIdx+Math.floor(L*0.75);
            const realDays=(d[n-1].time-d[startIdx].time)/86400;
            const base=Object.assign({},pfSettings,{tf:tf});
            const ed=pfEngineData(d,tf,base);
            const rb=calcProF(ed,Object.assign({},base),null);
            const baseOos=pfStatList(pfPick(rb.trades,s1,n,longOnly),feePct);
            const cache=[];
            for(let k=0;k<combos.length;k++){
                const r=calcProF(ed,Object.assign({},base,combos[k]),null);
                cache.push({p:combos[k],tr:r.trades});
                if(k%8===7){status.textContent='🧬 ('+(q+1)+'/'+tfs.length+') '+tf+' | '+(k+1)+'/'+combos.length;await new Promise(function(r2){setTimeout(r2,0);});}
            }
            const pickBest=function(a,b,minN){
                let best=null;
                cache.forEach(function(c){
                    const st=pfStatList(pfPick(c.tr,a,b,longOnly),feePct);
                    if(st.n<minN)return;
                    const sc=st.total/Math.max(5,st.mdd);
                    if(!best||sc>best.sc)best={c:c,st:st,sc:sc};
                });
                return best;
            };
            const f1=pickBest(startIdx,s1,8),f2=pickBest(startIdx,s2,10),fin=pickBest(startIdx,n,12);
            if(!f1||!f2||!fin){rows.push({tf:tf,days:realDays,err:'معامله کافی نبود - بازه را طولانی‌تر کن',baseOos:baseOos});continue;}
            const lB=pfPick(f1.c.tr,s1,s2,longOnly),lC=pfPick(f2.c.tr,s2,n,longOnly);
            const oosB=pfStatList(lB,feePct),oosC=pfStatList(lC,feePct),oos=pfStatList(lB.concat(lC),feePct);
            const ok=oos.n>=20&&oos.pf>=1.25&&oos.total>0&&(oosB.n<5||oosB.pf>=1)&&(oosC.n<5||oosC.pf>=1)&&fin.st.pf>=1.1;
            rows.push({tf:tf,days:realDays,params:fin.c.p,oos:oos,oosB:oosB,oosC:oosC,full:fin.st,baseOos:baseOos,ok:ok});
        }
        window.pfLastOpt=rows;
        const pc=function(x){return (x>=0?'+':'')+x.toFixed(1)+'%';};
        const pf=function(x){return x===Infinity?'∞':x.toFixed(2);};
        let h='<div class="btNote">🧬 '+symbol+' | بازه '+days+' روز | کارمزد '+feePct+'٪ هر طرف | '+combos.length+' ترکیب (موتور روندی + موتور بازگشت به میانگین) برای هر تایم‌فریم. تست = دو فولد Walk-Forward روی دیتایی که موقع انتخاب تنظیم دیده نشده؛ فقط همین ستون معیار واقعی است.</div>';
        h+='<div class="btTableWrap"><table><thead><tr><th>TF</th><th>روز</th><th>تنظیم نهایی</th><th>تست دیده‌نشده (معامله / برد٪ / PF / سود)</th><th>کل بازه (برد٪ / PF)</th><th>تنظیم فعلی در تست</th><th>نتیجه</th></tr></thead><tbody>';
        rows.forEach(function(x){
            if(x.err){h+='<tr><td>'+x.tf+'</td><td>'+(x.days?x.days.toFixed(0):'-')+'</td><td colspan="5">❌ '+x.err+'</td></tr>';return;}
            h+='<tr><td>'+x.tf+'</td><td>'+x.days.toFixed(0)+'</td><td>'+pfDescribeParams(x.params)+'</td>'+
              '<td class="'+(x.oos.total>=0?'pos':'neg')+'">'+x.oos.n+' / '+x.oos.win.toFixed(0)+' / '+pf(x.oos.pf)+' / '+pc(x.oos.total)+'</td>'+
              '<td>'+x.full.win.toFixed(0)+' / '+pf(x.full.pf)+'</td>'+
              '<td>'+x.baseOos.n+' / '+x.baseOos.win.toFixed(0)+' / '+pf(x.baseOos.pf)+' / '+pc(x.baseOos.total)+'</td>'+
              '<td>'+(x.ok?'✅ تایید':'⚠️ لبه قابل اتکا نیست')+'</td></tr>';
        });
        h+='</tbody></table></div>';
        const okN=rows.filter(function(x){return x.ok;}).length;
        h+='<div class="btVerdict" style="border-color:'+(okN?'#00c853':'#ff9800')+';color:'+(okN?'#00c853':'#ff9800')+';">'+okN+' از '+tfs.length+' تایم‌فریم در تست دیده‌نشده تایید شد (شرط: حداقل ۲۰ معامله، PF حداقل ۱.۲۵، سود مثبت و هر دو فولد غیرمنفی).</div>';
        h+='<div style="margin-top:8px"><button onclick="pfApplyOptProfiles()">✅ ذخیره پروفایل تایم‌فریم‌های تاییدشده</button> <button onclick="pfClearProfiles()">🗑️ پاک کردن پروفایل‌ها</button></div>';
        document.getElementById('btResult').innerHTML=h;
        status.textContent='✅ بهینه‌سازی تمام شد';
    }catch(e){
        console.error('خطای بهینه‌ساز:',e);
        status.textContent='❌ خطا: '+(e&&e.message||e);
    }finally{
        btn.disabled=false;b1.disabled=false;b2.disabled=false;
    }
}
function pfApplyOptProfiles(){
    const rows=window.pfLastOpt||[];let k=0;
    rows.forEach(function(x){if(x.ok&&x.params){PF_TF_PROFILES[x.tf]=Object.assign({},x.params);k++;}});
    pfSaveProfiles();
    const st=document.getElementById('btStatus');
    if(st)st.textContent=k?('✅ پروفایل '+k+' تایم‌فریم ذخیره شد و روی چارت اعمال می‌شود'):'⚠️ هیچ تایم‌فریمی تایید نشده بود؛ چیزی ذخیره نشد';
    if(pfEnabled&&currentCandles.length)drawProF(currentCandles);
}
function pfClearProfiles(){
    PF_TF_PROFILES={};pfSaveProfiles();
    const st=document.getElementById('btStatus');
    if(st)st.textContent='🗑️ پروفایل‌ها پاک شد';
    if(pfEnabled&&currentCandles.length)drawProF(currentCandles);
}
document.addEventListener('change',function(e){ if(e.target&&e.target.id==='btTimeframe')e.target.dataset.touched='1'; });
document.addEventListener('keydown',function(e){ if(e.key==='Escape'){const m=document.getElementById('btModal'); if(m&&m.classList.contains('open'))toggleBacktestPanel();} });

// ==================== بک‌تست MyBot (همان منطق calcMyBot + شبیه‌سازی هج simMyBot، سود/زیان به دلار) ====================
function btRunMyBot(d,startIdx,o){
    const cfg=Object.assign({},mbSettings,{visibleFrom:d[startIdx].time});
    const res=calcMyBot(d,cfg);
    let sigs=res.signals;
    if(o.longOnly)sigs=sigs.filter(function(x){return x.dir==='buy';});
    const sim=simMyBot(d,sigs,cfg);
    return {mybot:true,res:res,sim:sim,nSignals:sigs.length,buyHold:(d[d.length-1].close/d[startIdx].close-1)*100,startIdx:startIdx};
}

function btDrawUsdCurve(canvas,eq){
    const dpr=window.devicePixelRatio||1;
    const W=canvas.clientWidth||900,H=canvas.clientHeight||180;
    canvas.width=W*dpr;canvas.height=H*dpr;
    const g=canvas.getContext('2d');g.scale(dpr,dpr);g.clearRect(0,0,W,H);
    if(!eq||eq.length<2){g.fillStyle='#667788';g.font='12px Tahoma';g.fillText('معامله‌ای برای رسم نیست',W/2-60,H/2);return;}
    const step=Math.max(1,Math.ceil(eq.length/700));
    const pts=eq.filter(function(p,i){return i%step===0||i===eq.length-1;});
    const vals=pts.map(function(p){return p.value;}).concat([0]);
    let mn=Math.min.apply(null,vals),mx=Math.max.apply(null,vals); if(mx-mn<1e-9){mx+=1;mn-=1;}
    const pad=20,t0=pts[0].time,t1=pts[pts.length-1].time;
    const X=function(t){return pad+(W-2*pad)*(t-t0)/((t1-t0)||1);}, Y=function(v){return H-pad-(H-2*pad)*(v-mn)/(mx-mn);};
    g.strokeStyle='#33475b';g.setLineDash([4,4]);g.beginPath();g.moveTo(pad,Y(0));g.lineTo(W-pad,Y(0));g.stroke();g.setLineDash([]);
    g.strokeStyle=pts[pts.length-1].value>=0?'#00c853':'#ff5252';g.lineWidth=2;g.beginPath();
    pts.forEach(function(p,i){const x=X(p.time),y=Y(p.value); if(i)g.lineTo(x,y); else g.moveTo(x,y);}); g.stroke();
    g.fillStyle='#8899aa';g.font='10px Tahoma';
    g.fillText(mbFmtUsd(mx),4,pad-6);g.fillText(mbFmtUsd(mn),4,H-4);
    g.fillStyle='#00c853';g.fillText('Equity (دلار)',W-90,12);
}

function btRenderMyBot(r,meta,d){
    const sim=r.sim;
    const cls=function(v){return v>=0?'pos':'neg';};
    const fd=function(t){try{return new Date(t*1000).toLocaleString('fa-IR',{year:'2-digit',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'});}catch(e){return t;}};
    const wr=sim.closed?(sim.wins/sim.closed*100):0;
    let verdict,vcol;
    if(sim.nChains<10){verdict='⚠️ تعداد زنجیره‌ی معاملات خیلی کم است ('+sim.nChains+')، نتیجه از نظر آماری معتبر نیست. بازه را طولانی‌تر یا تایم‌فریم را 5m کن.';vcol='#ff9800';}
    else if(sim.net>0 && sim.maxDD<Math.abs(sim.net)*1.5){verdict='✅ در این بازه سودده بوده (خالص '+mbFmtUsd(sim.net)+').';vcol='#00c853';}
    else if(sim.net>0){verdict='⚠️ سودده ولی با افت equity بزرگ ('+mbFmtUsd(-sim.maxDD)+').';vcol='#ffd54f';}
    else{verdict='❌ در این بازه ضررده بوده ('+mbFmtUsd(sim.net)+').';vcol='#ff5252';}
    let h='<div class="btVerdict" style="border-color:'+vcol+';color:'+vcol+';">'+verdict+'</div>';
    h+='<div class="btNote">📌 '+BT_NAMES.mybot+' | '+meta.symbol+' | '+meta.tf+' | '+meta.days+' روز گذشته ('+meta.periodCandles+' کندل تست + '+meta.warmup+' کندل گرم‌کردن'+(meta.cut?' | ⚠️ دیتای کامل در دسترس نبود، بازه کوتاه‌تر شد':'')+')'+
        '<br>ℹ️ سیگنال‌ها با همان منطق MyBot.mq5 (SMA 15/100/200/250 + فیلترهای کندلی) و مدیریت هج (معامله‌ی جبرانی ۱ و ۲) شبیه‌سازی شده‌اند. سود/زیان به دلار و «معادل GBPUSD» است (در نمادهای دیگر آستانه‌ها با قیمت مقیاس می‌شوند). اسپرد/سواپ/مارجین لحاظ نشده، پس کارمزد و حد ضرر/سود فرم نادیده گرفته می‌شود. ربات برای تایم‌فریم 5m طراحی شده.'+
        (meta.tf!=='5m'?'<br>⚠️ تایم‌فریم انتخابی 5m نیست؛ نتیجه با رفتار واقعی ربات فرق دارد.':'')+'</div>';
    const card=function(k,v,c){return '<div class="btCard"><div class="k">'+k+'</div><div class="v '+(c||'')+'">'+v+'</div></div>';};
    h+='<div class="btGrid">'+
        card('خالص (بسته + شناور)',mbFmtUsd(sim.net),cls(sim.net))+
        card('سود/ضرر بسته‌شده',mbFmtUsd(sim.realized),cls(sim.realized))+
        card('شناور فعلی',mbFmtUsd(sim.floating),cls(sim.floating))+
        card('سیگنال‌ها',r.nSignals+' ('+r.res.signals.filter(function(x){return x.dir==='buy';}).length+' خرید / '+r.res.signals.filter(function(x){return x.dir==='sell';}).length+' فروش)')+
        card('زنجیره‌ها',sim.nChains+' (بسته '+sim.closed+' | باز '+sim.open+')')+
        card('با جبرانی ۱ / ۲',sim.withH1+' / '+sim.withH2)+
        card('درصد برد (زنجیره‌های بسته)',wr.toFixed(1)+'%',wr>=50?'pos':'neg')+
        card('بدترین افت equity','-$'+sim.maxDD.toFixed(0),'neg')+
        card('بدترین زنجیره‌ی بسته',mbFmtUsd(sim.worstChain),'neg')+
        card('Buy & Hold (قیمت)',(r.buyHold>=0?'+':'')+r.buyHold.toFixed(2)+'%',cls(r.buyHold))+
    '</div>';
    h+='<canvas id="btCurve"></canvas>';
    if(sim.trades.length){
        h+='<div class="btTableWrap"><table><thead><tr><th>#</th><th>جهت</th><th>ورود</th><th>قیمت ورود</th><th>هج</th><th>خروج</th><th>سود/زیان</th></tr></thead><tbody>';
        sim.trades.slice().reverse().slice(0,500).forEach(function(t,k){
            h+='<tr><td>'+(sim.trades.length-k)+'</td><td class="'+(t.dir==='buy'?'pos':'neg')+'">'+(t.dir==='buy'?'خرید':'فروش')+'</td><td>'+fd(t.openTime)+'</td><td>'+mbFmtPrice(t.entry)+'</td><td>'+(t.h?('H'+t.h):'-')+'</td><td>'+(t.done?fd(t.endTime):'باز')+'</td><td class="'+cls(t.pnl)+'">'+mbFmtUsd(t.pnl)+(t.done?'':' *')+'</td></tr>';
        });
        h+='</tbody></table></div>';
        if(sim.trades.length>500)h+='<div class="btNote">۵۰۰ معامله‌ی آخر نمایش داده شد.</div>';
        h+='<div class="btNote">ستاره = هنوز باز (سود/زیان شناور تا آخرین کندل)</div>';
    }
    document.getElementById('btResult').innerHTML=h;
    btDrawUsdCurve(document.getElementById('btCurve'),sim.equity);
}

// ==================== موتور پیش‌بینی Analog (غیرتصادفی) ====================
// ورودی: آرایه قیمت‌های بسته شدن (فقط گذشته) | خروجی: ضریب قیمت نسبت به آخرین کلوز برای H کندل آینده
// روش: پیدا کردن K الگوی تاریخی با بیشترین شباهت شکلی (همبستگی روی بازده‌های z-score) به آخرین W کندل
// و میانگین وزن‌دار ادامه‌ی واقعی آنها، هم‌مقیاس‌شده با نوسان فعلی. بدون هیچ عدد تصادفی.
function analogForecast(closes, H, K, volMult){
    volMult=volMult||1.0; K=Math.max(3,Math.min(10,K||7));
    const rets=[];
    for(let i=1;i<closes.length;i++){ rets.push(Math.log(closes[i]/closes[i-1])); }
    const W=Math.max(12, Math.min(40, Math.floor(rets.length/8)));
    const zNorm=arr=>{
        let m=0; for(const v of arr) m+=v; m/=arr.length;
        let q=0; for(const v of arr) q+=(v-m)*(v-m);
        const sd=Math.sqrt(q/arr.length)||1e-12;
        return {z:arr.map(v=>(v-m)/sd), sd:sd};
    };
    const mult=[];
    let info={method:'analog', matches:0, confidence:0, expectedMovePct:0, window:W};
    const maxStart=rets.length-W-H;
    if(maxStart>=K*2){
        const curN=zNorm(rets.slice(-W));
        const cands=[];
        for(let s=0;s<=maxStart;s++){
            const wn=zNorm(rets.slice(s,s+W));
            let c=0; for(let i=0;i<W;i++) c+=curN.z[i]*wn.z[i];
            cands.push({s:s, c:c/W, sd:wn.sd});
        }
        cands.sort((a,b)=>b.c-a.c);
        const picked=[];
        for(const c of cands){
            if(c.c<=0)break;
            if(picked.every(p=>Math.abs(p.s-c.s)>=Math.floor(W/2)))picked.push(c);
            if(picked.length>=K)break;
        }
        if(picked.length>=2){
            const avg=new Array(H).fill(0); let wSum=0;
            for(const p of picked){
                const w=p.c*p.c, scale=curN.sd/(p.sd||1e-12);
                for(let k=0;k<H;k++) avg[k]+=w*rets[p.s+W+k]*scale;
                wSum+=w;
            }
            let cum=0;
            for(let k=0;k<H;k++){ cum+=(avg[k]/wSum)*volMult; mult.push(Math.exp(cum)); }
            info.matches=picked.length;
            info.confidence=picked.reduce((a,p)=>a+p.c,0)/picked.length;
        }
    }
    if(!mult.length){
        // Fallback: رگرسیون خطی روی لگاریتم قیمت با شیب میرا
        const n=Math.min(50, closes.length);
        const ys=closes.slice(-n).map(v=>Math.log(v));
        const xm=(n-1)/2, ym=ys.reduce((a,b)=>a+b,0)/n;
        let num=0,den=0; for(let i=0;i<n;i++){num+=(i-xm)*(ys[i]-ym);den+=(i-xm)*(i-xm);}
        const slope=den?num/den:0;
        let cum=0;
        for(let k=1;k<=H;k++){ cum+=slope*Math.pow(0.97,k)*volMult; mult.push(Math.exp(cum)); }
        info.method='regression';
    }
    info.expectedMovePct=(mult[mult.length-1]-1)*100;
    return {mult:mult, info:info};
}

// ==================== بک‌تست Walk-Forward (بدون نگاه به آینده) ====================
// در هر نقطه‌ی تست t فقط از کندل‌های 0..t استفاده می‌شود، H کندل بعد پیش‌بینی و با واقعیت مقایسه می‌شود.
// معیارها: درصد درستی جهت، خطای میانگین مطلق (MAE٪)، مقایسه با پیش‌بینی ساده «قیمت ثابت» (Naive)،
// همبستگی حرکت پیش‌بینی‌شده با حرکت واقعی، و سود/زیان فرضی اگر طبق جهت پیش‌بینی معامله می‌شد.
function runAiBacktest(d, opts){
    opts=opts||aiPathSettings;
    const closes=d.map(c=>c.close);
    const H=Math.max(3, Math.min(opts.backtestHorizon||10, opts.projectionBars||40));
    const minHist=Math.max(200, Math.floor(closes.length*0.4));
    const lastT=closes.length-1-H;
    const res={tests:0, H:H, hitRate:null, mae:null, naiveMae:null, skill:null, corr:null, pnl:null, reason:''};
    if(lastT-minHist<20){ res.reason='کندل کافی نیست (حداقل ~۵۰۰ کندل لازم است)'; return res; }
    const maxTests=opts.backtestMaxTests||80;
    const stride=Math.max(1, Math.floor((lastT-minHist)/maxTests));
    let hits=0, dirN=0, ae=0, nae=0, pnl=0; const P=[], A=[];
    for(let t=minHist; t<=lastT; t+=stride){
        const fc=analogForecast(closes.slice(0,t+1), H, opts.analogK||7, 1.0);
        const pred=Math.log(fc.mult[H-1]);
        const act=Math.log(closes[t+H]/closes[t]);
        P.push(pred); A.push(act);
        ae+=Math.abs(pred-act); nae+=Math.abs(act);
        if(pred!==0 && act!==0){ dirN++; if(Math.sign(pred)===Math.sign(act)) hits++; }
        pnl+=Math.sign(pred)*act;
        res.tests++;
    }
    const n=res.tests;
    const mp=P.reduce((a,b)=>a+b,0)/n, ma=A.reduce((a,b)=>a+b,0)/n;
    let cov=0,vp=0,va=0; for(let i=0;i<n;i++){cov+=(P[i]-mp)*(A[i]-ma);vp+=(P[i]-mp)**2;va+=(A[i]-ma)**2;}
    res.hitRate=dirN?hits/dirN*100:null;
    res.mae=ae/n*100; res.naiveMae=nae/n*100;
    res.skill=nae?(1-ae/nae)*100:null;
    res.corr=(vp&&va)?cov/Math.sqrt(vp*va):0;
    res.pnl=(Math.exp(pnl)-1)*100;
    return res;
}

// شامل: زیگزاگ هارمونیک X-A-B-C-D (آبی) + مسیر موج‌دار پیش‌بینی آینده قیمت (زرد، شبیه تصویر ۱) +
// اهداف فیبوناچی با برچسب درصد مثل 180%/600% (سبز، شبیه تصویر ۲) + باکس سفارش با ورود/TP1-3/SL (شبیه پنل Crypto User)
function calcAiPricePath(d, opts){
    opts=opts||aiPathSettings;
    const left=opts.pivotLeft||5, right=opts.pivotRight||5;
    const projBars=opts.projectionBars||40;
    const volMult=opts.volMult||1.0;
    const atrStopMult=opts.atrStopMult||1.5;
    const fibLevels=(opts.fibLevels&&opts.fibLevels.length)?opts.fibLevels:[127.2,161.8,200,261.8,423.6,600];
    const result={markers:[], zigzagLines:[], forecast:[], forecastColor:'#ffd700', fibTargets:[], setup:null};
    if(!d||d.length<left+right+10)return result;

    // ---- زیگزاگ هارمونیک (پیوت‌های سقف/کف) ----
    const rawPivots=[];
    for(let i=left;i<d.length-right;i++){
        let isHigh=true,isLow=true;
        for(let j=i-left;j<=i+right;j++){
            if(j===i)continue;
            if(d[j].high>=d[i].high)isHigh=false;
            if(d[j].low<=d[i].low)isLow=false;
        }
        if(isHigh)rawPivots.push({time:d[i].time,price:d[i].high,type:'high',index:i});
        else if(isLow)rawPivots.push({time:d[i].time,price:d[i].low,type:'low',index:i});
    }
    const zz=[];
    for(const p of rawPivots){
        if(zz.length===0){zz.push(p);continue;}
        const last=zz[zz.length-1];
        if(last.type===p.type){
            if((p.type==='high'&&p.price>last.price)||(p.type==='low'&&p.price<last.price))zz[zz.length-1]=p;
        }else zz.push(p);
    }
    for(let i=1;i<zz.length;i++){
        result.zigzagLines.push([{time:zz[i-1].time,value:zz[i-1].price},{time:zz[i].time,value:zz[i].price}]);
    }
    const labels=['X','A','B','C','D','E'];
    const lastPivots=zz.slice(-6);
    lastPivots.forEach((p,i)=>{
        result.markers.push({time:p.time, position:p.type==='high'?'aboveBar':'belowBar', color:'#2962ff', shape:'circle', text:labels[i]||''});
    });
    if(zz.length<2)return result;

    // ---- بایاس روند با EMA سریع/کند ----
    const emaFast=calcEMA(d,20), emaSlow=calcEMA(d,50);
    const lastClose=d[d.length-1].close;
    const fV=emaFast.length?emaFast[emaFast.length-1].value:lastClose;
    const sV=emaSlow.length?emaSlow[emaSlow.length-1].value:lastClose;
    const bias=fV>=sV?'bull':'bear';

    // ---- اهداف فیبوناچی بر اساس آخرین موج زیگزاگ ----
    const B=zz[zz.length-1], A=zz[zz.length-2];
    const magnitude=Math.abs(B.price-A.price);
    const direction=bias==='bull'?1:-1;
    const entry=lastClose;

    const atrArr=calcATR(d,14);
    const atr=atrArr.length?atrArr[atrArr.length-1].value:(magnitude/10||entry*0.01);

    const fibTargets=fibLevels.map(lv=>({level:lv, price:entry+direction*magnitude*(lv/100)}))
        .sort((a,b)=>direction>0?a.price-b.price:b.price-a.price);
    result.fibTargets=fibTargets;

    const stopPrice=entry-direction*atr*atrStopMult;
    result.setup={dir:bias, entry:entry, stop:stopPrice,
        tp1:fibTargets[0]?fibTargets[0].price:null,
        tp2:fibTargets[1]?fibTargets[1].price:null,
        tp3:fibTargets[2]?fibTargets[2].price:null};
    result.markers.push({
        time:d[d.length-1].time,
        position:bias==='bull'?'belowBar':'aboveBar',
        color:bias==='bull'?'#00c853':'#ff1744',
        shape:bias==='bull'?'arrowUp':'arrowDown',
        text:bias==='bull'?'BUY':'SELL'
    });

    // ---- مسیر پیش‌بینی واقعی و غیرتصادفی (موتور مشترک با بک‌تست) ----
    const closes=d.map(c=>c.close);
    const step=d.length>=2?(d[d.length-1].time-d[d.length-2].time):60;
    const fc=analogForecast(closes, Math.max(5,projBars), opts.analogK||7, volMult);
    const path=[{time:d[d.length-1].time,value:lastClose}];
    fc.mult.forEach((m,k)=>path.push({time:d[d.length-1].time+step*(k+1), value:lastClose*m}));
    result.forecast=path;
    result.forecastInfo=fc.info;
    result.forecastColor='#ffd700';

    return result;
}

function removeAiPricePathSeries(){
    aiPathZigzagSeriesList.forEach(s=>{try{chart.removeSeries(s);}catch(e){}});
    aiPathZigzagSeriesList=[];
    if(aiPathForecastSeries){try{chart.removeSeries(aiPathForecastSeries);}catch(e){}aiPathForecastSeries=null;}
    aiPathPriceLines.forEach(pl=>{try{candleSeries.removePriceLine(pl);}catch(e){}});
    aiPathPriceLines=[];
}

function hideAiTradeCard(){
    const card=document.getElementById('aiTradeCard');
    if(card){card.classList.remove('show');card.innerHTML='';}
}

let aiBacktestResult=null;
function aiBacktestHtml(){
    const fi=aiPathResult&&aiPathResult.forecastInfo;
    let h='<div class="aiTitle" style="margin-top:8px;">📊 بک‌تست پیش‌بینی</div>';
    if(fi){
        h+='<div class="aiRow"><span>روش</span><span>'+(fi.method==='analog'?'Analog ('+fi.matches+' الگو)':'رگرسیون')+'</span></div>';
        if(fi.method==='analog')h+='<div class="aiRow"><span>شباهت الگوها</span><span>'+(fi.confidence*100).toFixed(0)+'%</span></div>';
        h+='<div class="aiRow"><span>حرکت مورد انتظار</span><span>'+(fi.expectedMovePct>=0?'+':'')+fi.expectedMovePct.toFixed(2)+'%</span></div>';
    }
    const b=aiBacktestResult;
    if(!b){ h+='<div class="aiRow"><span>در حال محاسبه...</span></div>'; return h; }
    if(!b.tests){ h+='<div class="aiRow"><span style="color:#ff9800;">'+b.reason+'</span></div>'; return h; }
    const col=(v,good)=>'<span style="color:'+(v>=good?'#00c853':'#ff5252')+';font-weight:bold;">';
    h+='<div class="aiRow"><span>تعداد تست</span><span>'+b.tests+' (افق '+b.H+' کندل)</span></div>'+
       '<div class="aiRow"><span>درستی جهت</span>'+col(b.hitRate,55)+b.hitRate.toFixed(1)+'%</span></div>'+
       '<div class="aiRow"><span>خطای میانگین</span><span>'+b.mae.toFixed(2)+'%</span></div>'+
       '<div class="aiRow"><span>خطای Naive</span><span>'+b.naiveMae.toFixed(2)+'%</span></div>'+
       '<div class="aiRow"><span>مهارت نسبت به Naive</span>'+col(b.skill,0)+(b.skill>=0?'+':'')+b.skill.toFixed(1)+'%</span></div>'+
       '<div class="aiRow"><span>همبستگی</span>'+col(b.corr,0.1)+b.corr.toFixed(2)+'</span></div>'+
       '<div class="aiRow"><span>سود فرضی طبق جهت</span>'+col(b.pnl,0)+(b.pnl>=0?'+':'')+b.pnl.toFixed(1)+'%</span></div>';
    let verdict='❌ قابل اعتماد نیست';
    if(b.hitRate>=55 && b.skill>0 && b.corr>0.1) verdict='✅ لبه آماری دارد';
    else if(b.hitRate>=52 || b.corr>0.05) verdict='⚠️ ضعیف، با احتیاط';
    h+='<div class="aiRow"><span>نتیجه</span><span style="font-weight:bold;">'+verdict+'</span></div>';
    return h;
}

function updateAiTradeCard(setup){
    const card=document.getElementById('aiTradeCard');
    if(!card)return;
    if(!setup){hideAiTradeCard();return;}
    const dirFa=setup.dir==='bull'?'<span class="aiBuy">خرید (BUY)</span>':'<span class="aiSell">فروش (SELL)</span>';
    const prec=setup.entry<1?6:(setup.entry<100?4:2);
    const fmt=v=>v===null||v===undefined?'-':v.toFixed(prec);
    card.innerHTML=
        '<div class="aiTitle">🤖 AI Trade Setup | '+currentSymbol+'</div>'+
        '<div class="aiRow"><span>نوع سفارش</span>'+dirFa+'</div>'+
        '<div class="aiRow"><span>ورود</span><span>'+fmt(setup.entry)+'</span></div>'+
        '<div class="aiRow"><span>TP1</span><span class="aiTp">'+fmt(setup.tp1)+'</span></div>'+
        '<div class="aiRow"><span>TP2</span><span class="aiTp">'+fmt(setup.tp2)+'</span></div>'+
        '<div class="aiRow"><span>TP3</span><span class="aiTp">'+fmt(setup.tp3)+'</span></div>'+
        '<div class="aiRow"><span>SL</span><span class="aiSl">'+fmt(setup.stop)+'</span></div>'+
        aiBacktestHtml();
    card.classList.add('show');
}

function drawAiPricePath(d){
    if(!chart||!candleSeries)return null;
    try{
        removeAiPricePathSeries();
        aiPathResult=calcAiPricePath(d, aiPathSettings);

        aiPathResult.zigzagLines.forEach(line=>{
            const s=chart.addLineSeries({color:'#2962ff',lineWidth:1,priceLineVisible:false,lastValueVisible:false,crosshairMarkerVisible:false});
            s.setData(line);
            aiPathZigzagSeriesList.push(s);
        });

        if(aiPathResult.forecast.length>1){
            aiPathForecastSeries=chart.addLineSeries({color:aiPathResult.forecastColor,lineWidth:2,priceLineVisible:false,lastValueVisible:false,crosshairMarkerVisible:false});
            aiPathForecastSeries.setData(aiPathResult.forecast);
        }

        aiPathResult.fibTargets.forEach(t=>{
            aiPathPriceLines.push(candleSeries.createPriceLine({price:t.price,color:'#4caf50',lineWidth:1,lineStyle:2,title:t.level+'% → '+t.price.toPrecision(6)}));
        });
        if(aiPathResult.setup){
            aiPathPriceLines.push(candleSeries.createPriceLine({price:aiPathResult.setup.entry,color:'#ffffff',lineWidth:1,lineStyle:0,title:'ORDER'}));
            aiPathPriceLines.push(candleSeries.createPriceLine({price:aiPathResult.setup.stop,color:'#ff1744',lineWidth:2,lineStyle:3,title:'SL'}));
        }

        updateAllMarkers();
        aiBacktestResult=null;
        updateAiTradeCard(aiPathResult.setup);
        // بک‌تست کمی بعد اجرا می‌شود تا رسم نمودار کند نشود
        const btCandles=d;
        setTimeout(function(){
            try{
                if(!aiPathEnabled||btCandles!==currentCandles)return;
                const t0=performance.now();
                aiBacktestResult=runAiBacktest(btCandles, aiPathSettings);
                console.log('=== بک‌تست AI: '+aiBacktestResult.tests+' تست | درستی جهت '+(aiBacktestResult.hitRate!==null?aiBacktestResult.hitRate.toFixed(1)+'%':'-')+' | '+(performance.now()-t0).toFixed(0)+'ms ===');
                if(aiPathResult)updateAiTradeCard(aiPathResult.setup);
            }catch(e){console.error('خطای بک‌تست:',e);}
        },60);
        console.log('=== AI Price Path: '+aiPathResult.zigzagLines.length+' خط هارمونیک | '+aiPathResult.fibTargets.length+' هدف فیبوناچی | بایاس: '+(aiPathResult.setup?aiPathResult.setup.dir:'-')+' ===');
        return aiPathResult;
    }catch(err){
        console.error('خطای کلی در drawAiPricePath:',err);
        return null;
    }
}

function toggleAiPricePath(){
    aiPathEnabled=!aiPathEnabled;
    const btn=document.getElementById('btnAiPath');
    if(aiPathEnabled){
        btn.classList.add('active');
        btn.textContent='🤖 حذف اندیکاتور AI Price Path';
        if(currentCandles.length>0){
            setTimeout(function(){ drawAiPricePath(currentCandles); },220);
        }
    }else{
        btn.classList.remove('active');
        btn.textContent='🤖 اعمال اندیکاتور AI Price Path';
        aiPathResult=null;
        removeAiPricePathSeries();
        updateAllMarkers();
        hideAiTradeCard();
    }
}

// ==================== اندیکاتور MyBot Signals (مرحله ۱: پورت منطق ورود ربات MetaTrader یعنی MyBot.mq5) ====================
// منطق ورود ربات (۴ میانگین SMA + فیلترهای کندلی) روی کندل‌های چارت اجرا می‌شود و سیگنال خرید/فروش با TP/SL رسم می‌شود.
// نکته‌ی نام‌گذاری: در کد MQL ربات، maValues=SMA15 | maValues100=SMA100 | maValues400=SMA200 | maValues200=SMA250 (اسم‌ها گمراه‌کننده‌اند).
// آستانه‌های ربات برای GBPUSD (قیمت حدود 1.27) نوشته شده‌اند؛ در حالت percent همه‌ی آن‌ها متناسب با قیمت هر نماد مقیاس می‌شوند.
// ربات برای M5 طراحی شده است؛ روی تایم‌فریم 5m بهترین تطابق را دارد.
// مدیریت پوزیشن ربات (هج/جبران ضرر) در این مرحله پیاده نشده و در مرحله‌های بعد اضافه می‌شود.
let mbEnabled=false;
let mbResult=null;
let mbMaSeries=[];
let mbPriceLines=[];
let mbSettings={
    maFast:15, maMid:100, maSlow:200, maLong:250,
    scaleMode:'percent',      // percent: آستانه‌ها بر اساس قیمت مقیاس می‌شوند | absolute: عددهای خام ربات (فقط فارکس)
    refPrice:1.27,            // قیمت مرجع آستانه‌های ربات (GBPUSD)
    gateSec:600,              // ربات فقط یک بار در هر کندل M10 اجازه‌ی ورود دارد (sellopen/sellopen2)
    lateMonth:11,             // از این ماه به بعد (نوامبر و دسامبر) شرط‌های خرید متفاوت است
    buyOffset:0.00006, sellOffset:0.00004,
    bullWin:23, bullMax:13,   // خرید: تعداد کندل صعودی در 23 کندل قبل باید کمتر از 13 باشد
    bearWin:29, bearMax:17,   // فروش: تعداد کندل نزولی در 29 کندل قبل باید کمتر از 17 باشد
    bodyWin:11,               // فروش: جمع بدنه‌ی 11 کندل قبل
    th:{
        fmGap:0.0003,
        buyGapA:0.00026,
        buyGapB:0.0006, buyMidSlB:0.0001, buyMoveMin:-0.003, buyMoveMax:0.001,
        sellSlLg:0.0001, sellMidLg:0.0003, sellMidSl3:0.0001, sellBodyMin:-0.0015, sellBodyMax:0.003
    },
    buyTP:0.001, buySL:0.2, sellTP:0.001, sellSL:0.05,   // معادل 100/20000/100/5000 پوینت در MQL
    showMA:true, showSL:false,
    // ---------- مرحله ۲: شبیه‌سازی مدیریت پوزیشن ربات (معامله‌ی جبرانی/هج) ----------
    // سود و زیان به دلار و «معادل GBPUSD» حساب می‌شود: هر 1.0 واحد قیمت برای 1 لات = 100000 دلار (در حالت percent با قیمت نماد مقیاس می‌شود)
    sim:{
        enabled:true, unit:100000, showEquity:true, showHedgeMarkers:true,
        showTradeLines:true, showExitMarkers:true, maxTradeLines:40,   // خط ورود→خروج و مارکر سود/زیان برای آخرین N معامله
        // lots: لات پوزیشن اصلی | h1Lots/h2Lots: لات معامله‌ی جبرانی اول/دوم
        // h1Trig: ضرر شناور (دلار) پوزیشن اصلی که معامله‌ی جبرانی اول را باز می‌کند | h2Trig: ضرر معامله‌ی جبرانی اول که دومی را باز می‌کند
        // closeSum: جمع سود شناور زنجیره بالاتر از این شد همه بسته می‌شوند | h1Alone: سود خودِ معامله‌ی جبرانی اول (فقط خرید) برای بستن اصلی+جبرانی
        // hTP/hSL: فاصله‌ی TP/SL معامله‌های جبرانی (معادل 10000 و 5000 پوینت)
        buy:{lots:0.2, h1Lots:0.22, h2Lots:0.25, h1Trig:-40, h2Trig:-50, closeSum:10, h1Alone:30, hTP:0.1, hSL:0.05},
        sell:{lots:0.1, h1Lots:0.2, h2Lots:0.25, h1Trig:-50, h2Trig:-20, closeSum:10, h1Alone:null, hTP:0.1, hSL:0.05}
    }
};
let mbEqSeries=null;
let mbTradeSeries=[];
let mbTradeSig='';

function mbSMA(closes,p){
    const n=closes.length, out=new Array(n).fill(NaN);
    let sum=0;
    for(let i=0;i<n;i++){
        sum+=closes[i];
        if(i>=p)sum-=closes[i-p];
        if(i>=p-1)out[i]=sum/p;
    }
    return out;
}

function calcMyBot(d,settings){
    const s=settings||mbSettings, th=s.th;
    const result={markers:[],signals:[],ma:{fast:[],mid:[],slow:[],long:[]},buys:0,sells:0,tpHits:0,slHits:0,open:0,lastSignal:null};
    const n=d?d.length:0;
    const warm=Math.max(s.maLong,s.maSlow,s.maMid,s.maFast)+16;
    if(n<=warm)return result;
    const closes=d.map(c=>c.close);
    const f=mbSMA(closes,s.maFast), m=mbSMA(closes,s.maMid), sl=mbSMA(closes,s.maSlow), lg=mbSMA(closes,s.maLong);
    const vis=s.visibleFrom||0;   // فقط از این زمان به بعد روی چارت نشان داده می‌شود؛ قبلش فقط برای گرم‌شدن میانگین‌هاست
    const mk=function(arr,p){const o=[];for(let i=p-1;i<n;i++){if(d[i].time>=vis)o.push({time:d[i].time,value:arr[i]});}return o;};
    result.ma.fast=mk(f,s.maFast);
    result.ma.mid=mk(m,s.maMid);
    result.ma.slow=mk(sl,s.maSlow);
    result.ma.long=mk(lg,s.maLong);

    const abs=Math.abs;
    let up1=false, up2=false, sellopen=false, sellopen2=false, prevBucket=null;

    function addSignal(dir,i,k){
        if(d[i].time<vis)return;
        const c=d[i], entry=c.close;
        const tp=dir==='buy'?entry+s.buyTP*k:entry-s.sellTP*k;
        const stop=dir==='buy'?entry-s.buySL*k:entry+s.sellSL*k;
        let outcome='open', mae=0;
        for(let j=i+1;j<n;j++){
            const x=d[j];
            const adverse=dir==='buy'?(entry-x.low)/entry:(x.high-entry)/entry;
            if(adverse>mae)mae=adverse;
            const hitSL=dir==='buy'?x.low<=stop:x.high>=stop;
            const hitTP=dir==='buy'?x.high>=tp:x.low<=tp;
            if(hitSL){outcome='sl';break;}
            if(hitTP){outcome='tp';break;}
        }
        const sig={dir:dir,time:c.time,index:i,entry:entry,tp:tp,sl:stop,outcome:outcome,mae:mae,k:k};
        result.signals.push(sig);
        if(dir==='buy')result.buys++;else result.sells++;
        if(outcome==='tp')result.tpHits++;else if(outcome==='sl')result.slHits++;else result.open++;
        const mark=outcome==='tp'?' ✓':(outcome==='sl'?' ✗':'');
        result.markers.push({
            time:c.time,
            position:dir==='buy'?'belowBar':'aboveBar',
            color:dir==='buy'?'#00e676':'#ff5252',
            shape:dir==='buy'?'arrowUp':'arrowDown',
            text:(dir==='buy'?'MB-BUY':'MB-SELL')+mark
        });
        result.lastSignal=sig;
    }

    for(let i=0;i<n;i++){
        const c=d[i];
        const bucket=Math.floor(c.time/s.gateSec);
        if(prevBucket!==null && bucket!==prevBucket){sellopen=true;sellopen2=true;}
        prevBucket=bucket;
        if(i<warm)continue;
        const k=(s.scaleMode==='percent')?(c.close/s.refPrice):1;

        // ---------- خرید: عبور SMA15 از بالای SMA250 (+ آفست) ----------
        if(sellopen2){
            if(f[i]>lg[i]+s.buyOffset*k){
                if(!up2){
                    up2=true;
                    let bull=0;
                    for(let j=1;j<=s.bullWin;j++){ if(d[i-j].open<d[i-j].close)bull++; }
                    const month=new Date(c.time*1000).getUTCMonth()+1;
                    const common=bull<s.bullMax && abs(f[i-6]-m[i-6])>th.fmGap*k && sl[i]<lg[i];
                    let ok=false;
                    if(month<s.lateMonth){
                        ok=common && abs(lg[i]-sl[i])>th.buyGapA*k;
                    }else{
                        const move=closes[i]-closes[i-10];
                        ok=common && move>th.buyMoveMin*k && move<th.buyMoveMax*k
                            && abs(m[i]-sl[i])>th.buyMidSlB*k && abs(lg[i]-sl[i])>th.buyGapB*k
                            && m[i-5]<sl[i-5];
                    }
                    if(ok){addSignal('buy',i,k);sellopen2=false;}
                }
            }else if(up2){
                up2=false;
                sellopen2=false;
            }
        }

        // ---------- فروش: بازگشت SMA15 به زیر SMA100 (+ آفست) بعد از قرار گرفتن بالای آن ----------
        if(sellopen){
            if(f[i]>m[i]+s.sellOffset*k){
                if(!up1)up1=true;
            }else if(up1){
                up1=false;
                let body=0, bear=0;
                for(let j=1;j<=s.bodyWin;j++){ body+=d[i-j].close-d[i-j].open; }
                for(let j=1;j<=s.bearWin;j++){ if(d[i-j].close<d[i-j].open)bear++; }
                const ok=bear<s.bearMax && body>th.sellBodyMin*k && body<th.sellBodyMax*k
                    && abs(f[i-6]-m[i-6])>th.fmGap*k
                    && abs(sl[i]-lg[i])>th.sellSlLg*k && abs(m[i]-lg[i])>th.sellMidLg*k
                    && abs(m[i-3]-sl[i-3])>th.sellMidSl3*k
                    && m[i]>sl[i] && sl[i]>lg[i] && m[i-15]<f[i-15];
                if(ok)addSignal('sell',i,k);
                sellopen=false;
            }
        }
    }
    return result;
}


// ==================== شبیه‌سازی مدیریت پوزیشن ربات روی کندل‌ها ====================
// هر سیگنال یک «زنجیره» است: پوزیشن اصلی + حداکثر دو معامله‌ی جبرانی هم‌جهت (میانگین‌گیری).
// مسیر قیمت داخل هر کندل: صعودی O→L→H→C ، نزولی O→H→L→C ؛ شرط‌ها روی قیمت دقیق برخورد (نه فقط کلوز) اعمال می‌شوند.
// فرض‌ها: اسپرد و سواپ صفر | مارجین/استاپ‌اوت لحاظ نمی‌شود | اگر یکی از پایه‌ها با TP/SL بسته شود، بقیه فقط با TP/SL خودشان مدیریت می‌شوند.
function simMyBot(d,signals,settings){
    const s=settings||mbSettings, sm=s.sim, U=sm.unit;
    const n=d.length, vis=s.visibleFrom||0;
    const out={enabled:true,trades:[],nChains:0,closed:0,open:0,withH1:0,withH2:0,wins:0,losses:0,realized:0,floating:0,net:0,
               minEquity:0,maxDD:0,worstChain:0,equity:[],hedgeMarkers:[],bySignal:new Map()};
    if(!signals||!signals.length)return out;
    const sigs=signals.slice().sort(function(a,b){return a.index-b.index;});
    const live=[], all=[];
    let curTime=0, peak=0;

    function pnlOf(pos,P){return pos.dir*(P-pos.entry)*pos.lots*U/pos.k;}
    function anyOpen(ch){return (ch.legs.main&&ch.legs.main.open)||(ch.legs.mk1&&ch.legs.mk1.open)||(ch.legs.mk2&&ch.legs.mk2.open);}
    function closePos(pos,P){
        if(!pos.open)return;
        pos.open=false;
        const v=pnlOf(pos,P);
        pos.pnl=v;
        pos.closeTime=curTime;
        pos.closeP=P;
        out.realized+=v;
        pos.chain.pnl+=v;
        if(!anyOpen(pos.chain)){
            pos.chain.done=true;
            pos.chain.endTime=curTime;
            const i=live.indexOf(pos.chain);
            if(i>=0)live.splice(i,1);
        }
    }
    function newPos(ch,role,lots,P,tp,sl,time){
        const pos={chain:ch,role:role,dir:ch.dir,lots:lots,entry:P,k:ch.k,tp:tp,sl:sl,open:true,c:false,openTime:time,closeTime:null,closeP:null,pnl:0};
        ch.legs[role]=pos;
        return pos;
    }
    function openHedge(ch,role,P){
        const cfg=ch.cfg, k=ch.k;
        const lots=role==='mk1'?cfg.h1Lots:cfg.h2Lots;
        const tp=ch.dir>0?P+cfg.hTP*k:P-cfg.hTP*k;
        const sl=ch.dir>0?P-cfg.hSL*k:P+cfg.hSL*k;
        newPos(ch,role,lots,P,tp,sl,curTime);
        out.hedgeMarkers.push({time:curTime,dir:ch.dir>0?'buy':'sell',level:role==='mk1'?1:2});
    }
    function openChain(sig){
        const ch={dir:sig.dir==='buy'?1:-1,k:sig.k,cfg:sm[sig.dir],legs:{},pnl:0,done:false,sig:sig};
        newPos(ch,'main',ch.cfg.lots,sig.entry,sig.tp,sig.sl,sig.time);
        live.push(ch);
        all.push(ch);
    }
    // قوانین فعال یک زنجیره؛ هر قانون: fn(P) خطی نسبت به قیمت، آستانه، جهت (ge/le) و عملی که در قیمت برخورد انجام می‌شود
    function buildRules(ch){
        const cfg=ch.cfg, L=ch.legs, m=L.main, a=L.mk1, b=L.mk2, r=[];
        [m,a,b].forEach(function(p){
            if(!p||!p.open)return;
            r.push({fn:function(P){return P;},thr:p.tp,op:p.dir>0?'ge':'le',act:function(Pt){closePos(p,Pt);}});
            r.push({fn:function(P){return P;},thr:p.sl,op:p.dir>0?'le':'ge',act:function(Pt){closePos(p,Pt);}});
        });
        if(m&&m.open&&a&&a.open){
            r.push({fn:function(P){return pnlOf(m,P)+pnlOf(a,P);},thr:cfg.closeSum,op:'ge',act:function(Pt){closePos(m,Pt);closePos(a,Pt);}});
            if(cfg.h1Alone!==null&&cfg.h1Alone!==undefined){
                r.push({fn:function(P){return pnlOf(a,P);},thr:cfg.h1Alone,op:'ge',act:function(Pt){closePos(m,Pt);closePos(a,Pt);}});
            }
        }
        if(m&&m.open&&a&&a.open&&b&&b.open){
            r.push({fn:function(P){return pnlOf(m,P)+pnlOf(a,P)+pnlOf(b,P);},thr:cfg.closeSum,op:'ge',act:function(Pt){closePos(m,Pt);closePos(a,Pt);closePos(b,Pt);}});
        }
        if(m&&m.open&&!m.c&&!a){
            r.push({fn:function(P){return pnlOf(m,P);},thr:cfg.h1Trig,op:'le',act:function(Pt){m.c=true;openHedge(ch,'mk1',Pt);}});
        }
        if(a&&a.open&&!a.c&&!b){
            r.push({fn:function(P){return pnlOf(a,P);},thr:cfg.h2Trig,op:'le',act:function(Pt){a.c=true;openHedge(ch,'mk2',Pt);}});
        }
        return r;
    }
    function crossP(r,Pc,Pb){
        const ok=function(v){return r.op==='ge'?v>=r.thr:v<=r.thr;};
        const fa=r.fn(Pc);
        if(ok(fa))return Pc;
        const fb=r.fn(Pb);
        if(!ok(fb))return null;
        const t=(r.thr-fa)/(fb-fa);
        return Pc+(Pb-Pc)*Math.min(1,Math.max(0,t));
    }
    function floatingAt(P){
        let f=0;
        for(let i=0;i<live.length;i++){
            const L=live[i].legs;
            ['main','mk1','mk2'].forEach(function(role){ if(L[role]&&L[role].open)f+=pnlOf(L[role],P); });
        }
        return f;
    }
    function walk(Pc,Pb){
        for(let guard=0;guard<400;guard++){
            let best=null,bestDist=Infinity,bestPt=0;
            for(let i=0;i<live.length;i++){
                const rules=buildRules(live[i]);
                for(let q=0;q<rules.length;q++){
                    const Pt=crossP(rules[q],Pc,Pb);
                    if(Pt===null)continue;
                    const dist=Math.abs(Pt-Pc);
                    if(dist<bestDist-1e-12){best=rules[q];bestDist=dist;bestPt=Pt;}
                }
            }
            if(!best)return;
            best.act(bestPt);
            Pc=bestPt;
        }
    }
    function track(P){
        const eq=out.realized+floatingAt(P);
        if(eq<out.minEquity)out.minEquity=eq;
        if(eq>peak)peak=eq;
        if(peak-eq>out.maxDD)out.maxDD=peak-eq;
        return eq;
    }

    const first=sigs[0].index;
    for(let i=0;i<=first&&i<n;i++){ if(d[i].time>=vis)out.equity.push({time:d[i].time,value:0}); }
    let prevClose=d[first].close, ptr=0;
    for(let j=first+1;j<n;j++){
        while(ptr<sigs.length&&sigs[ptr].index<j){openChain(sigs[ptr]);ptr++;}
        const c=d[j];
        curTime=c.time;
        const path=c.close>=c.open?[c.open,c.low,c.high,c.close]:[c.open,c.high,c.low,c.close];
        let Pc=prevClose;
        for(let q=0;q<path.length;q++){
            walk(Pc,path[q]);
            Pc=path[q];
            track(Pc);
        }
        prevClose=c.close;
        out.equity.push({time:c.time,value:out.realized+floatingAt(c.close)});
    }
    // سیگنالی که روی آخرین کندل باشد هنوز زنجیره‌اش ساخته نشده؛ همچنان باز حساب می‌شود
    while(ptr<sigs.length){openChain(sigs[ptr]);ptr++;}
    const lastP=d[n-1].close;
    out.floating=floatingAt(lastP);
    out.net=out.realized+out.floating;
    all.forEach(function(ch){
        out.nChains++;
        if(ch.legs.mk1)out.withH1++;
        if(ch.legs.mk2)out.withH2++;
        const h=ch.legs.mk2?2:(ch.legs.mk1?1:0);
        if(ch.done){
            out.closed++;
            if(ch.pnl>=0)out.wins++;else out.losses++;
            if(ch.pnl<out.worstChain)out.worstChain=ch.pnl;
        }else{
            out.open++;
        }
        out.bySignal.set(ch.sig,{pnl:ch.pnl,done:ch.done,h:h});
        let total=ch.pnl;
        const legs=[];
        ['main','mk1','mk2'].forEach(function(role){
            const p=ch.legs[role];
            if(!p)return;
            let lp=p.pnl;
            if(p.open){lp=pnlOf(p,lastP);total+=lp;}
            legs.push({role:role,lots:p.lots,entry:p.entry,openTime:p.openTime,closeTime:p.open?null:p.closeTime,closeP:p.open?null:p.closeP,pnl:lp});
        });
        out.trades.push({dir:ch.sig.dir,openTime:ch.sig.time,entry:ch.sig.entry,h:h,done:ch.done,endTime:ch.done?ch.endTime:null,pnl:total,legs:legs});
    });
    return out;
}

function mbFmtUsd(v){return (v>=0?'+':'-')+'$'+Math.abs(v).toFixed(0);}

// جایگزین کردن متن مارکرها با نتیجه‌ی شبیه‌سازی (سود/ضرر زنجیره + سطح معامله‌ی جبرانی) و افزودن مارکر معامله‌های جبرانی
function mbApplySimMarkers(res,sim){
    const out=[];
    res.signals.forEach(function(sg){
        const info=sim.bySignal.get(sg);
        let mark='', h='';
        if(info){
            if(info.done)mark=info.pnl>=0?' ✓':' ✗';
            if(info.h)h=' H'+info.h;
        }
        out.push({
            time:sg.time,
            position:sg.dir==='buy'?'belowBar':'aboveBar',
            color:sg.dir==='buy'?'#00e676':'#ff5252',
            shape:sg.dir==='buy'?'arrowUp':'arrowDown',
            text:(sg.dir==='buy'?'MB-BUY':'MB-SELL')+mark+h
        });
    });
    if(mbSettings.sim.showHedgeMarkers){
        sim.hedgeMarkers.forEach(function(hm){
            out.push({
                time:hm.time,
                position:hm.dir==='buy'?'belowBar':'aboveBar',
                color:hm.level===1?'#ff9800':'#ff1744',
                shape:'circle',
                text:'H'+hm.level
            });
        });
    }
    if(mbSettings.sim.showExitMarkers){
        sim.trades.slice(-mbSettings.sim.maxTradeLines).forEach(function(t){
            if(!t.done)return;
            out.push({time:t.endTime,position:'inBar',color:t.pnl>=0?'#00e676':'#ff5252',shape:'square',text:mbFmtUsd(t.pnl)});
        });
    }
    res.markers=out;
}

function mbToggleCard(){
    const card=document.getElementById('mbCard');
    if(card)card.classList.toggle('mini');
}

function updateMyBotCard(sim){
    const card=document.getElementById('mbCard');
    if(!card)return;
    if(!sim||!mbEnabled||!sim.nChains){
        card.classList.remove('show');
        card.innerHTML='';
        if(sim&&mbEnabled&&!sim.nChains){
            card.innerHTML='<div class="mbTitle" onclick="mbToggleCard()">🧠 MyBot — شبیه‌سازی</div><div class="mbBody">سیگنالی در این بازه نبود</div>';
            card.classList.add('show');
        }
        return;
    }
    const wr=sim.closed?Math.round(sim.wins/sim.closed*100)+'٪':'-';
    const cls=function(v){return v>=0?'mbPos':'mbNeg';};
    let h='<div class="mbTitle" onclick="mbToggleCard()">🧠 MyBot — شبیه‌سازی (دلار، معادل GBPUSD)</div><div class="mbBody">';
    h+='<div class="aiRow"><span>زنجیره‌ها</span><span>'+sim.nChains+' (بسته '+sim.closed+' | باز '+sim.open+')</span></div>';
    h+='<div class="aiRow"><span>با جبرانی ۱ / ۲</span><span>'+sim.withH1+' / '+sim.withH2+'</span></div>';
    h+='<div class="aiRow"><span>نرخ برد زنجیره‌های بسته</span><span>'+wr+'</span></div>';
    h+='<div class="aiRow"><span>سود/ضرر بسته‌شده</span><span class="'+cls(sim.realized)+'">'+mbFmtUsd(sim.realized)+'</span></div>';
    h+='<div class="aiRow"><span>شناور فعلی</span><span class="'+cls(sim.floating)+'">'+mbFmtUsd(sim.floating)+'</span></div>';
    h+='<div class="aiRow"><span>خالص</span><span class="'+cls(sim.net)+'">'+mbFmtUsd(sim.net)+'</span></div>';
    h+='<div class="aiRow"><span>بدترین افت equity</span><span class="mbNeg">'+mbFmtUsd(-sim.maxDD)+'</span></div>';
    h+='<div class="aiRow"><span>بدترین زنجیره‌ی بسته</span><span class="mbNeg">'+mbFmtUsd(sim.worstChain)+'</span></div>';
    h+='<div class="mbLink" onclick="mbOpenTrades()">📋 لیست معامله‌ها ('+sim.nChains+')</div>';
    h+='</div>';
    card.innerHTML=h;
    card.classList.add('show');
}

function mbClearTradeLines(){
    mbTradeSeries.forEach(function(sr){try{chart.removeSeries(sr);}catch(e){}});
    mbTradeSeries=[];
    mbTradeSig='';
}

// خط ورود→خروج هر پایه‌ی معامله: سبز=سودده، قرمز=ضررده، زرد=هنوز باز | پایه‌ی اصلی ممتد، معامله‌های جبرانی خط‌چین
function mbDrawTradeLines(d,sim){
    const ss=mbSettings.sim;
    if(!ss.showTradeLines||!sim||!sim.trades.length){mbClearTradeLines();return;}
    const list=sim.trades.slice(-ss.maxTradeLines);
    const lastT=d[d.length-1].time, lastP=d[d.length-1].close;
    const step=d.length>1?d[d.length-1].time-d[d.length-2].time:60;
    let sg=list.map(function(t){
        return t.openTime+':'+(t.done?1:0)+':'+(t.pnl>=0?1:0)+':'+t.legs.map(function(l){return l.openTime+'-'+(l.closeTime||0);}).join(',');
    }).join('|');
    if(list.some(function(t){return !t.done;}))sg+='@'+lastT;
    if(sg===mbTradeSig&&mbTradeSeries.length)return;
    mbClearTradeLines();
    mbTradeSig=sg;
    list.forEach(function(t){
        const col=!t.done?'#ffd54f':(t.pnl>=0?'#00e676':'#ff5252');
        t.legs.forEach(function(l){
            if(l.openTime>=lastT&&l.closeTime===null)return;
            let t2=l.closeTime!==null?l.closeTime:lastT;
            const p2=l.closeTime!==null?l.closeP:lastP;
            if(t2<=l.openTime)t2=l.openTime+step;
            const sr=chart.addLineSeries({color:col,lineWidth:l.role==='main'?2:1,lineStyle:l.role==='main'?0:2,priceLineVisible:false,lastValueVisible:false,crosshairMarkerVisible:false});
            sr.setData([{time:l.openTime,value:l.entry},{time:t2,value:p2}]);
            mbTradeSeries.push(sr);
        });
    });
}

function mbPad2(x){return (x<10?'0':'')+x;}
function mbFmtTime(t){
    const x=new Date(t*1000);
    return mbPad2(x.getMonth()+1)+'/'+mbPad2(x.getDate())+' '+mbPad2(x.getHours())+':'+mbPad2(x.getMinutes());
}
function mbFmtPrice(p){return p>=100?p.toFixed(2):p.toFixed(5);}

function mbOpenTrades(){
    const m=document.getElementById('mbTradesModal'), body=document.getElementById('mbTradesBody');
    if(!m||!body)return;
    const sim=mbResult&&mbResult.sim;
    if(!sim||!sim.trades.length){
        body.innerHTML='<div style="padding:14px;text-align:center;">معامله‌ای در این بازه نبود</div>';
    }else{
        let h='<table><thead><tr><th>#</th><th>ورود</th><th>جهت</th><th>قیمت</th><th>هج</th><th>خروج</th><th>سود/زیان</th></tr></thead><tbody>';
        const rows=sim.trades.slice().reverse().slice(0,300);
        rows.forEach(function(t,i){
            const no=sim.trades.length-i;
            const cls=t.pnl>=0?'mbPos':'mbNeg';
            h+='<tr onclick="mbGoTo('+t.openTime+')">';
            h+='<td>'+no+'</td><td>'+mbFmtTime(t.openTime)+'</td>';
            h+='<td class="'+(t.dir==='buy'?'mbPos':'mbNeg')+'">'+(t.dir==='buy'?'خرید':'فروش')+'</td>';
            h+='<td>'+mbFmtPrice(t.entry)+'</td><td>'+(t.h?('H'+t.h):'-')+'</td>';
            h+='<td>'+(t.done?mbFmtTime(t.endTime):'باز')+'</td>';
            h+='<td class="'+cls+'">'+mbFmtUsd(t.pnl)+(t.done?'':' *')+'</td></tr>';
        });
        h+='</tbody></table>';
        if(sim.trades.length>300)h+='<div style="padding:6px;text-align:center;">۳۰۰ معامله‌ی آخر نمایش داده شد</div>';
        h+='<div style="padding:6px;text-align:center;color:#8fa6b8;">ستاره = هنوز باز (سود/زیان شناور) | لمس هر ردیف = رفتن به آن نقطه‌ی چارت</div>';
        body.innerHTML=h;
    }
    m.classList.add('open');
}
function mbCloseTrades(){
    const m=document.getElementById('mbTradesModal');
    if(m)m.classList.remove('open');
}
function mbGoTo(t){
    try{
        mbCloseTrades();
        const d=currentCandles;
        if(!d||!d.length)return;
        const step=d.length>1?d[1].time-d[0].time:60;
        const from=Math.max(d[0].time,t-60*step), to=Math.min(d[d.length-1].time,t+120*step);
        chart.timeScale().setVisibleRange({from:from,to:to});
    }catch(e){console.error('خطا در رفتن به معامله:',e);}
}

function removeMyBotSeries(){
    mbMaSeries.forEach(function(s){try{chart.removeSeries(s);}catch(e){}});
    mbMaSeries=[];
    if(mbEqSeries){try{chart.removeSeries(mbEqSeries);}catch(e){}mbEqSeries=null;}
    mbClearTradeLines();
    removeMyBotPriceLines();
    updateMyBotCard(null);
}

function removeMyBotPriceLines(){
    mbPriceLines.forEach(function(pl){try{candleSeries.removePriceLine(pl);}catch(e){}});
    mbPriceLines=[];
}

function updateMyBotButton(){
    const btn=document.getElementById('btnMyBot');
    if(!btn)return;
    if(!mbEnabled){
        btn.classList.remove('active');
        btn.textContent='🧠 اعمال اندیکاتور MyBot (سیگنال ربات MT5)';
        return;
    }
    btn.classList.add('active');
    const r=mbResult;
    btn.textContent='🧠 حذف اندیکاتور MyBot'+(r?' (خرید '+r.buys+' | فروش '+r.sells+(r.sim?' | خالص '+mbFmtUsd(r.sim.net):'')+')':'');
}

// SMA250 به حدود 270 کندل قبل از اولین کندل نمایش‌داده‌شده نیاز دارد؛ پس تاریخچه‌ی اضافه جدا گرفته و کش می‌شود
let mbHistCache={key:'',candles:[]};
let mbBusy=false;
async function mbGetWarmup(d){
    const s=mbSettings;
    const need=Math.max(s.maLong,s.maSlow,s.maMid,s.maFast)+20;
    const key=currentSymbol+'|'+currentTimeframe;
    const first=d[0].time;
    let older=(mbHistCache.key===key)?mbHistCache.candles.filter(function(c){return c.time<first;}):[];
    if(older.length<need){
        const res=await fetch('/api/candles?symbol='+encodeURIComponent(currentSymbol)+'&timeframe='+encodeURIComponent(currentTimeframe)+'&limit='+(d.length+need+10));
        const data=await res.json();
        if(data && data.success && data.data && data.data.length){
            mbHistCache={key:key,candles:data.data};
            older=data.data.filter(function(c){return c.time<first;});
        }
    }
    return older.slice(-need);
}

async function drawMyBot(d){
    if(!chart||!candleSeries||!d||!d.length)return null;
    if(mbBusy)return null;
    mbBusy=true;
    try{
        let warm=[];
        try{ warm=await mbGetWarmup(d); }catch(e){ console.error('خطا در دریافت تاریخچه‌ی گرم‌کردن MyBot:',e); }
        if(!mbEnabled||d!==currentCandles)return null;   // در حین دریافت، اندیکاتور خاموش شده یا دیتای جدیدتری آمده
        removeMyBotPriceLines();
        const full=warm.concat(d);
        const cfg=Object.assign({},mbSettings,{visibleFrom:d[0].time});
        mbResult=calcMyBot(full,cfg);
        mbResult.sim=null;
        if(mbSettings.sim.enabled){
            try{
                mbResult.sim=simMyBot(full,mbResult.signals,cfg);
                mbApplySimMarkers(mbResult,mbResult.sim);
            }catch(e){ console.error('خطای شبیه‌سازی MyBot:',e); mbResult.sim=null; }
        }

        if(mbSettings.showMA){
            const defs=[['fast','#ffeb3b'],['mid','#42a5f5'],['slow','#ab47bc'],['long','#ff7043']];
            if(mbMaSeries.length!==defs.length){
                mbMaSeries.forEach(function(s){try{chart.removeSeries(s);}catch(e){}});
                mbMaSeries=defs.map(function(p){
                    return chart.addLineSeries({color:p[1],lineWidth:1,priceLineVisible:false,lastValueVisible:false,crosshairMarkerVisible:false});
                });
            }
            defs.forEach(function(p,idx){ mbMaSeries[idx].setData(mbResult.ma[p[0]]); });
        }else if(mbMaSeries.length){
            mbMaSeries.forEach(function(s){try{chart.removeSeries(s);}catch(e){}});
            mbMaSeries=[];
        }

        const ls=mbResult.lastSignal;
        if(ls && ls.outcome==='open'){
            const tag=ls.dir==='buy'?'MB-BUY':'MB-SELL';
            mbPriceLines.push(candleSeries.createPriceLine({price:ls.entry,color:'#ffffff',lineWidth:1,lineStyle:2,title:tag+' ENTRY'}));
            mbPriceLines.push(candleSeries.createPriceLine({price:ls.tp,color:'#00e676',lineWidth:1,lineStyle:3,title:'MB-TP'}));
            if(mbSettings.showSL){
                mbPriceLines.push(candleSeries.createPriceLine({price:ls.sl,color:'#ff1744',lineWidth:1,lineStyle:3,title:'MB-SL'}));
            }
        }

        // منحنی equity روی یک مقیاس مستقل در پایین چارت
        if(mbResult.sim && mbSettings.sim.showEquity && mbResult.sim.equity.length){
            if(!mbEqSeries){
                mbEqSeries=chart.addLineSeries({color:'#00e5ff',lineWidth:2,priceScaleId:'mbEq',priceLineVisible:false,lastValueVisible:false,crosshairMarkerVisible:false});
                try{chart.priceScale('mbEq').applyOptions({scaleMargins:{top:0.8,bottom:0.02},visible:false});}catch(e){}
            }
            mbEqSeries.setData(mbResult.sim.equity);
        }else if(mbEqSeries){
            try{chart.removeSeries(mbEqSeries);}catch(e){}
            mbEqSeries=null;
        }
        mbDrawTradeLines(d,mbResult.sim);
        updateMyBotCard(mbResult.sim);
        updateAllMarkers();
        updateMyBotButton();
        console.log('=== MyBot: '+mbResult.buys+' خرید | '+mbResult.sells+' فروش'+(mbResult.sim?' | خالص شبیه‌سازی: '+mbFmtUsd(mbResult.sim.net):'')+' ===');
        return mbResult;
    }catch(err){
        console.error('خطای کلی در drawMyBot:',err);
        return null;
    }finally{
        mbBusy=false;
    }
}

function toggleMyBot(){
    mbEnabled=!mbEnabled;
    if(mbEnabled){
        updateMyBotButton();
        if(currentCandles.length>0){
            setTimeout(function(){ drawMyBot(currentCandles); },50);
        }
    }else{
        mbResult=null;
        removeMyBotSeries();
        updateAllMarkers();
        updateMyBotButton();
    }
}

// ==================== هشدار صوتی جدید برای سیگنال Multi-Layer — یک زنگ اعلان شفاف و خوشایند شبیه اپ‌های حرفه‌ای ====================
// این هشدار شامل:
//   ۱) یک آکورد زنگوله‌ای دلنشین (شبیه صدای اعلان iOS/بانکی) با نت‌های هارمونیک C6-E6-G6-C7
//   ۲) صدای «ping» نرم قبل از آکورد برای جلب توجه بدون آزاردهنده بودن
//   ۳) تکرار ملایم هر ۲.۲ ثانیه (به‌جای آژیر پیوسته) تا کاربر اذیت نشود ولی متوجه هشدار بشود
//   ۴) ویبره کوتاه و ملایم موبایل (در صورت پشتیبانی)
function startAlertSound(){
    stopAlertSound();
    try{
        alertAudioCtx=new (window.AudioContext||window.webkitAudioContext)();

        // یک نت زنگوله‌ای با صدای sine + هارمونیک ملایم، شبیه صدای ناقوس/چایم
        function makeChimeNote(freq, start, duration, volume){
            const osc=alertAudioCtx.createOscillator();
            const osc2=alertAudioCtx.createOscillator();
            const gain=alertAudioCtx.createGain();
            osc.type='sine';
            osc2.type='sine';
            osc.frequency.setValueAtTime(freq, start);
            osc2.frequency.setValueAtTime(freq*2, start); // هارمونیک اکتاو بالاتر برای غنای صدا
            const g2=alertAudioCtx.createGain();
            g2.gain.setValueAtTime(volume*0.25, start);
            g2.gain.exponentialRampToValueAtTime(0.0001, start+duration);
            osc2.connect(g2);g2.connect(alertAudioCtx.destination);

            gain.gain.setValueAtTime(0.0001, start);
            gain.gain.exponentialRampToValueAtTime(volume, start+0.03);
            gain.gain.exponentialRampToValueAtTime(0.0001, start+duration);
            osc.connect(gain);gain.connect(alertAudioCtx.destination);

            osc.start(start);osc.stop(start+duration+0.05);
            osc2.start(start);osc2.stop(start+duration+0.05);
        }

        // یک «ping» نرم و کوتاه قبل از آکورد اصلی
        function makePing(freq, start, duration, volume){
            const osc=alertAudioCtx.createOscillator();
            const gain=alertAudioCtx.createGain();
            osc.type='triangle';
            osc.frequency.setValueAtTime(freq, start);
            gain.gain.setValueAtTime(0.0001, start);
            gain.gain.exponentialRampToValueAtTime(volume, start+0.015);
            gain.gain.exponentialRampToValueAtTime(0.0001, start+duration);
            osc.connect(gain);gain.connect(alertAudioCtx.destination);
            osc.start(start);osc.stop(start+duration+0.05);
        }

        function playPattern(){
            if(!alertAudioCtx)return;
            const t=alertAudioCtx.currentTime;
            // پینگ نرم اولیه برای جلب توجه بدون شوک
            makePing(1568, t+0.00, 0.12, 0.18); // G6

            // آکورد زنگوله‌ای دلنشین: C6 - E6 - G6 - C7 (آرپژ صعودی نرم)
            makeChimeNote(1046.5, t+0.14, 0.55, 0.28); // C6
            makeChimeNote(1318.5, t+0.26, 0.55, 0.26); // E6
            makeChimeNote(1568.0, t+0.38, 0.60, 0.26); // G6
            makeChimeNote(2093.0, t+0.52, 0.75, 0.24); // C7
        }

        playPattern();
        // تکرار ملایم هر ۲.۲ ثانیه تا کاربر تایید کند
        alertAudioTimer=setInterval(playPattern, 2200);

        // ویبره کوتاه و ملایم (در صورت پشتیبانی)
        if(navigator.vibrate){
            try{
                navigator.vibrate([80,60,80]);
                if(!window._vibTimer){
                    window._vibTimer=setInterval(function(){
                        try{navigator.vibrate([80,60,80]);}catch(e){}
                    },2200);
                }
            }catch(e){}
        }
    }catch(e){console.error('خطا در پخش صدای هشدار:',e);}
}

function stopAlertSound(){
    if(alertAudioTimer){clearInterval(alertAudioTimer);alertAudioTimer=null;}
    if(window._vibTimer){clearInterval(window._vibTimer);window._vibTimer=null;}
    if(navigator.vibrate){try{navigator.vibrate(0);}catch(e){}}
    if(alertAudioCtx){try{alertAudioCtx.close();}catch(e){}alertAudioCtx=null;}
}

function showSignalAlertBanner(text, sym, tf){
    let banner=document.getElementById('signalAlertBanner');
    if(!banner){
        banner=document.createElement('div');
        banner.id='signalAlertBanner';
        banner.style.cssText='position:fixed;top:0;left:0;right:0;z-index:9999;background:linear-gradient(90deg,#1565c0,#7b1fa2,#1565c0);color:#fff;padding:16px 20px;display:flex;justify-content:space-between;align-items:center;font-weight:bold;font-size:15px;box-shadow:0 4px 20px rgba(21,101,192,0.6);animation:alertPulse 1.2s infinite alternate;';
        // اضافه کردن انیمیشن پالس
        const styleEl=document.createElement('style');
        styleEl.textContent='@keyframes alertPulse{from{background:linear-gradient(90deg,#1565c0,#7b1fa2,#1565c0);}to{background:linear-gradient(90deg,#0d47a1,#4a148c,#0d47a1);}}';
        document.head.appendChild(styleEl);
        document.body.appendChild(banner);
    }
    banner.innerHTML='';
    const span=document.createElement('span');
    span.textContent='🔔 '+text+'  |  '+sym+'  |  تایم‌فریم '+tf+'  🔔';
    const btn=document.createElement('button');
    btn.textContent='✅ تایید و قطع صدا';
    btn.style.cssText='background:#fff;color:#1565c0;border:none;padding:10px 24px;border-radius:8px;font-weight:bold;cursor:pointer;font-size:14px;box-shadow:0 2px 8px rgba(0,0,0,0.3);';
    btn.onclick=function(){
        stopAlertSound();
        banner.remove();
    };
    banner.appendChild(span);
    banner.appendChild(btn);
}

function checkNewMultiLayerSignal(){
    if(!multiLayerEnabled || !multiLayerResult || !multiLayerResult.markers)return;
    const sigMarkers=multiLayerResult.markers.filter(m=>(m.baseText||m.text)==='ML-BUY'||(m.baseText||m.text)==='ML-SELL');
    if(sigMarkers.length===0)return;
    const latest=sigMarkers.reduce((a,b)=>a.time>b.time?a:b);
    const key=currentSymbol+'_'+currentTimeframe;
    const lastAlertedTime=alertLastSignalKey[key]||0;
    if(latest.time>lastAlertedTime){
        alertLastSignalKey[key]=latest.time;
        try{localStorage.setItem('mlAlertLastSignal',JSON.stringify(alertLastSignalKey));}catch(e){}
        const sigType=(latest.baseText||latest.text).indexOf('BUY')!==-1?'خرید (BUY)':'فروش (SELL)';
        showSignalAlertBanner('سیگنال جدید Multi-Layer: '+sigType, currentSymbol, currentTimeframe);
        startAlertSound();
        if(window.Notification && Notification.permission==='granted'){
            try{new Notification('🚨 سیگنال جدید Multi-Layer',{body:sigType+' | '+currentSymbol+' | '+currentTimeframe});}catch(e){}
        }
    }
}
if(window.Notification && Notification.permission==='default'){
    try{Notification.requestPermission();}catch(e){}
}

function calcAlphaRibbon(d, settings){
    settings = settings || alphaSettings;
    const result={ribbonLines:[[],[],[],[],[],[]],markers:[],crossMarkers:[],barStates:[],activePosition:null,lastPosition:null,finalState:'transition',lastSignal:null,atrPercent:null};
    if(!d||d.length<100)return result;
    const lens=settings.emaLens;
    const emas=lens.map(p=>calcEMA(d,p));
    const rsi=calcRSI(d,settings.rsiLen),macd=calcMACD(d,settings.macdFast,settings.macdSlow,settings.macdSignal),atr=calcATR(d,settings.atrLen);
    const rsiMap={};rsi.forEach(x=>rsiMap[x.time]=x.value);
    const macdMap={};macd.macd.forEach(x=>macdMap[x.time]=x.value);
    const sigMap={};macd.signal.forEach(x=>sigMap[x.time]=x.value);
    const atrMap={};atr.forEach(x=>atrMap[x.time]=x.value);
    const CONFIRM_BARS=settings.confirmBars,ATR_STOP_MULT=settings.atrStopMult;
    const ATR_TARGET_MULTS=[1,2,3,4,5,6].map(i=>i*settings.atrTargetStep);
    const RSI_OB=settings.rsiOB,RSI_OS=settings.rsiOS;
    let state='transition',stateCount=0,position=null,prevMacd=null,prevSig=null,prevFast=null,prevSlow=null,prevCrossState=null;
    for(let i=0;i<d.length;i++){
        const vals=emas.map(e=>(e[i]?e[i].value:null));
        if(vals.some(v=>v===null)){result.barStates.push({time:d[i].time,state:'transition',twoColorState:'up'});continue;}
        for(let j=0;j<6;j++)result.ribbonLines[j].push({time:d[i].time,value:vals[j]});
        let newState='transition';
        if(vals[0]>vals[1]&&vals[1]>vals[2]&&vals[2]>vals[3]&&vals[3]>vals[4]&&vals[4]>vals[5])newState='up';
        else if(vals[0]<vals[1]&&vals[1]<vals[2]&&vals[2]<vals[3]&&vals[3]<vals[4]&&vals[4]<vals[5])newState='down';
        if(newState===state)stateCount++;else{state=newState;stateCount=1;}
        const t=d[i].time,rsiV=rsiMap[t],macdV=macdMap[t],sigV=sigMap[t],atrV=atrMap[t];
        const fastE=vals[0],slowE=vals[1];

        // Golden Cross / Death Cross: fastest ribbon EMA vs slowest ribbon EMA
        const crossFast=vals[0], crossSlow=vals[5];
        const curCrossState=crossFast>crossSlow?'above':'below';
        result.barStates.push({time:d[i].time,state:state,twoColorState:(curCrossState==='above'?'up':'down')});
        if(prevCrossState!==null&&curCrossState!==prevCrossState){
            if(curCrossState==='above'){
                result.crossMarkers.push({time:t,position:'belowBar',color:'#ffd700',shape:'circle',text:'GC'});
            }else{
                result.crossMarkers.push({time:t,position:'aboveBar',color:'#9c27b0',shape:'circle',text:'DC'});
            }
        }
        prevCrossState=curCrossState;

        if(stateCount===CONFIRM_BARS){
            if(state==='up'&&(!position||position.dir!=='long')){
                position={dir:'long',entry:d[i].close,entryTime:t};
                if(atrV){
                    const stopDist=ATR_STOP_MULT*atrV;
                    position.stop=d[i].low-stopDist;
                    const tCount=settings.targetCount||4;
                    const capScore=calcTargetCapacityScore(fastE,slowE,atrV,rsiV,d[i].high-d[i].low,d[i].close);
                    let unitDist;
                    if(settings.autoRR){
                        const rr=calcDynamicRR(fastE,slowE,atrV,rsiV,d[i].high-d[i].low,settings.minRR,settings.maxRR);
                        unitDist=(rr*stopDist)/tCount;
                    }else{
                        unitDist=settings.atrTargetStep*atrV;
                    }
                    position.targets=buildTargetsWithCapacity(d[i].close,unitDist,'long',tCount,capScore,tCount);
                    position.unitDist=unitDist;position.capBase=tCount;
                }
                result.markers.push({time:t,position:'belowBar',color:'#00c853',shape:'arrowUp',text:'BUY'});
                result.lastSignal={type:'BUY',time:t,price:d[i].close};
            }else if(state==='down'&&(!position||position.dir!=='short')){
                position={dir:'short',entry:d[i].close,entryTime:t};
                if(atrV){
                    const stopDist=ATR_STOP_MULT*atrV;
                    position.stop=d[i].high+stopDist;
                    const tCount=settings.targetCount||4;
                    const capScore=calcTargetCapacityScore(fastE,slowE,atrV,rsiV,d[i].high-d[i].low,d[i].close);
                    let unitDist;
                    if(settings.autoRR){
                        const rr=calcDynamicRR(fastE,slowE,atrV,rsiV,d[i].high-d[i].low,settings.minRR,settings.maxRR);
                        unitDist=(rr*stopDist)/tCount;
                    }else{
                        unitDist=settings.atrTargetStep*atrV;
                    }
                    position.targets=buildTargetsWithCapacity(d[i].close,unitDist,'short',tCount,capScore,tCount);
                    position.unitDist=unitDist;position.capBase=tCount;
                }
                result.markers.push({time:t,position:'aboveBar',color:'#ff1744',shape:'arrowDown',text:'SELL'});
                result.lastSignal={type:'SELL',time:t,price:d[i].close};
            }
        }
        if(position && settings.exitMaster){
            let rsiExit=false,macdExit=false,emaExit=false,structExit=false;
            if(settings.exitRSI && rsiV!==undefined){
                if(position.dir==='long'&&rsiV>=RSI_OB)rsiExit=true;
                if(position.dir==='short'&&rsiV<=RSI_OS)rsiExit=true;
            }
            if(settings.exitMACD && macdV!==undefined&&sigV!==undefined&&prevMacd!==null&&prevSig!==null){
                if(position.dir==='long'&&prevMacd>=prevSig&&macdV<sigV)macdExit=true;
                if(position.dir==='short'&&prevMacd<=prevSig&&macdV>sigV)macdExit=true;
            }
            if(settings.exitEMA && prevFast!==null&&prevSlow!==null){
                if(position.dir==='long'&&prevFast>=prevSlow&&fastE<slowE)emaExit=true;
                if(position.dir==='short'&&prevFast<=prevSlow&&fastE>slowE)emaExit=true;
            }
            if(settings.exitStruct && state==='transition')structExit=true;
            const momentumCount=[rsiExit,macdExit,emaExit].filter(Boolean).length;
            if(momentumCount>=2||structExit){
                result.markers.push({time:t,position:position.dir==='long'?'aboveBar':'belowBar',color:position.dir==='long'?'#00c853':'#ff1744',shape:'circle',text:'EXIT'});
                result.lastSignal={type:'EXIT',time:t,price:d[i].close,dir:position.dir};
                result.lastPosition=Object.assign({},position,{closed:true,exit:d[i].close,exitTime:t});
                position=null;
            }
        }
        if(position && position.targets && position.targets.length){
            const capScore=calcTargetCapacityScore(fastE,slowE,atrV,rsiV,d[i].high-d[i].low,d[i].close);
            const stopDistNow=ATR_STOP_MULT*atrV;
            let stepDistNow;
            if(settings.autoRR){
                const rrNow=calcDynamicRR(fastE,slowE,atrV,rsiV,d[i].high-d[i].low,settings.minRR,settings.maxRR);
                stepDistNow=(rrNow*stopDistNow)/(position.capBase||settings.targetCount||4);
            }else{
                stepDistNow=settings.atrTargetStep*atrV;
            }
            extendTargetsIfNeeded(position,d[i].close,stepDistNow,capScore);
        }
        prevMacd=(macdV!==undefined)?macdV:prevMacd;
        prevSig=(sigV!==undefined)?sigV:prevSig;
        prevFast=fastE;prevSlow=slowE;
        if(atrV!==undefined&&d[i].close){result.atrPercent=(atrV/d[i].close)*100;}
    }
    result.activePosition=position;
    if(position){result.lastPosition=Object.assign({},position,{closed:false});}
    result.finalState=state;
    return result;
}

function drawRibbon(d){
    if(!chart||!candleSeries){console.error('چارت آماده نیست');return null;}
    if(isDrawing){console.log('در حال رسم، صبر کنید...');return null;}
    isDrawing=true;
    
    try{
        removeAllRibbonSeries();
        const rb=calcAlphaRibbon(d, alphaSettings);
        if(!rb){console.error('محاسبه روبان خطا داد');isDrawing=false;return null;}
        
        const widths=[1,1,2,2,3,3];
        let drawnCount=0;
        const stateMap={};
        const useTwoColor=(alphaSettings.colorMode==='B');
        rb.barStates.forEach(b=>{stateMap[b.time]=useTwoColor?b.twoColorState:b.state;});
        const colorForState=st=>st==='up'?'#00c853':(st==='down'?'#ff1744':'#888899');

        for(let j=0;j<6;j++){
            const line=rb.ribbonLines[j];
            if(!line || line.length===0)continue;
            try{
                let segStart=0;
                for(let k=1;k<=line.length;k++){
                    const prevState=stateMap[line[k-1].time]||'transition';
                    const atEnd=(k===line.length);
                    const curState=atEnd?null:(stateMap[line[k].time]||'transition');
                    if(atEnd||curState!==prevState){
                        let segData=line.slice(segStart,k);
                        if(!atEnd)segData=segData.concat([line[k]]);
                        if(segData.length>0){
                            const s=chart.addLineSeries({
                                color:colorForState(prevState),
                                lineWidth:widths[j],
                                priceLineVisible:false,
                                lastValueVisible:false,
                                crosshairMarkerVisible:false
                            });
                            s.setData(segData);
                            ribbonSeries.push(s);
                            drawnCount++;
                        }
                        segStart=k;
                    }
                }
                console.log('خط روبان '+(j+1)+' | نقاط: '+line.length+' | رنگ‌بندی مرحله‌ای اعمال شد');
            }catch(e){console.error('خطا در خط روبان '+(j+1)+':',e);}
        }

        if(alphaSettings.ema50200){
            try{
                const e50=calcEMA(d,50), e200=calcEMA(d,200);
                if(e50.length>0){
                    const s50=chart.addLineSeries({color:'#00bcd4',lineWidth:1,priceLineVisible:false,lastValueVisible:false,crosshairMarkerVisible:false});
                    s50.setData(e50);ribbonSeries.push(s50);
                }
                if(e200.length>0){
                    const s200=chart.addLineSeries({color:'#e91e63',lineWidth:1,priceLineVisible:false,lastValueVisible:false,crosshairMarkerVisible:false});
                    s200.setData(e200);ribbonSeries.push(s200);
                }
                console.log('EMA 50/200 رسم شدند');
            }catch(e){console.error('خطا در EMA 50/200:',e);}
        }
        
        ribbonResult=rb;
        updateAllMarkers();

        if(alphaSettings.candleColor){
            try{
                const colored=d.map(c=>{
                    const st=stateMap[c.time]||'transition';
                    const col=st==='up'?'#00c853':(st==='down'?'#ff1744':'#888899');
                    return Object.assign({},c,{color:col,wickColor:col,borderColor:col});
                });
                candleSeries.setData(colored);
                console.log('کندل‌ها بر اساس وضعیت روبان رنگ‌آمیزی شدند');
            }catch(e){console.error('خطا در رنگ‌آمیزی کندل:',e);}
        }else{
            candleSeries.setData(d);
        }
        
        const rbP = rb.activePosition || rb.lastPosition;
        if(rbP && rbP.stop){
            try{
                const tag = rbP.closed ? ' (بسته)' : '';
                ribbonPriceLines.push(candleSeries.createPriceLine({price:rbP.stop,color:'#ff1744',lineWidth:2,lineStyle:2,title:'SL'+tag}));
                (rbP.targets||[]).forEach((tp,idx)=>{
                    const achievable = tp.achievable!==false;
                    const price = (tp && typeof tp==='object') ? tp.price : tp;
                    const lineColor = achievable ? '#00c853' : '#556677';
                    const lineTitle = 'TP'+(idx+1)+(achievable?tag:' ✗'+tag);
                    ribbonPriceLines.push(candleSeries.createPriceLine({price:price,color:lineColor,lineWidth:1,lineStyle:achievable?2:1,title:lineTitle}));
                });
                console.log('خطوط SL/TP رسم شدند. SL: '+rbP.stop+(rbP.closed?' (بسته)':' (باز)'));
            }catch(e){console.error('خطا در SL/TP:',e);}
        }
        
        updateDashboardPanel(rb);
        
        console.log('=== نتیجه نهایی: '+drawnCount+' خط روبان رسم شد ===');
        isDrawing=false;
        return rb;
    }catch(err){
        console.error('خطای کلی در drawRibbon:',err);
        isDrawing=false;
        return null;
    }
}

function toggleIndicator(){
    indicatorEnabled=!indicatorEnabled;
    const btn=document.getElementById('btnIndicator');
    if(indicatorEnabled){
        btn.classList.add('active');
        btn.textContent='📊 حذف اندیکاتور Alpha';
        if(currentCandles.length>0){
            setTimeout(function(){
                const rb=drawRibbon(currentCandles);
                updateStatus(rb);
                if(alphaSettings.showMTF)loadMTFPanel();
            },50);
        }else{
            updateStatus(null);
        }
    }else{
        btn.classList.remove('active');
        btn.textContent='📊 اعمال اندیکاتور Alpha';
        removeAllRibbonSeries();
        ribbonResult=null;
        updateAllMarkers();
        if(alphaSettings.candleColor&&currentCandles.length>0)candleSeries.setData(currentCandles);
        updateStatus(null);
        updateDashboardPanel(null);
    }
}

function updateStatus(rb){
    const status=document.getElementById('statusBar');
    if(!currentCandles.length){status.textContent='در حال بارگذاری...';return;}
    let stateFa='غیرفعال';
    if(indicatorEnabled){
        if(!rb){
            try{rb=calcAlphaRibbon(currentCandles,alphaSettings);}catch(e){}
        }
        stateFa=rb?(rb.finalState==='up'?'صعودی':(rb.finalState==='down'?'نزولی':'گذار')):'خطا';
    }
    const dataInfo=window._lastDataInfo||{};
    let mlFa='غیرفعال';
    if(multiLayerEnabled){
        const mr=multiLayerResult;
        mlFa=mr?(mr.finalState==='up'?'صعودی':(mr.finalState==='down'?'نزولی':'گذار')):'در حال محاسبه';
    }
    status.textContent=`✅ ${currentSymbol} | ${currentTimeframe} | منبع: ${dataInfo.exchange||'-'} | ${currentCandles.length} کندل | اندیکاتور: ${indicatorEnabled?'فعال':'غیرفعال'} | وضعیت روبان: ${stateFa} | خطوط: ${ribbonSeries.length} | Multi-Layer: ${mlFa}`;
}

let _prevLoadCtx={symbol:null,timeframe:null,limit:null};
let loadChartBusy=false;
async function loadChart(){
    const status=document.getElementById('statusBar');
    if(!chart||!candleSeries){
        status.textContent='❌ نمودار هنوز آماده نیست - صفحه را رفرش کن';
        return;
    }
    // جلوگیری از همپوشانی درخواست‌ها (رفرش ۵ ثانیه‌ای و کلیک کاربر)
    if(loadChartBusy)return;
    loadChartBusy=true;
    status.textContent='⏳ در حال دریافت دیتا...';
    currentSymbol=symSel.value;
    const limit=document.getElementById('limitSelect').value;
    const reqSymbol=currentSymbol, reqTf=currentTimeframe;
    // اگر نماد/تایم‌فریم/تعداد کندل عوض نشده باشد یعنی این یک رفرش خودکار دیتاست، پس زوم/موقعیت فعلی چارت را حفظ کن
    const sameContext=(_prevLoadCtx.symbol===currentSymbol && _prevLoadCtx.timeframe===currentTimeframe && _prevLoadCtx.limit===limit);
    try{
        const res=await fetch(`/api/candles?symbol=${reqSymbol}&timeframe=${reqTf}&limit=${limit}`);
        const data=await res.json();
        // پاسخ قدیمی (مثلاً ۱d که دیرتر رسیده) نباید جای تایم‌فریم/نماد جدید را بگیرد
        if(reqSymbol!==currentSymbol||reqTf!==currentTimeframe)return;
        if(!data.success){
            status.textContent='❌ خطا: '+(data.error||'دریافت دیتا ناموفق بود');
            return;
        }
        const d=data.data;
        // زوم: درست قبل از جایگزینی دیتا گرفته می‌شود و بر اساس «زمان» به دیتای جدید نگاشت می‌شود (کندل جدید، زوم را جابه‌جا نمی‌کند)
        let zoomRec=null;
        if(sameContext){ zoomRec=zoomCapture(currentCandles); }
        else if(_prevLoadCtx.symbol===null){ zoomRec=zoomReadStored(currentSymbol,currentTimeframe); }
        currentCandles=d;
        window._lastDataInfo={exchange:data.exchange};
        applyDynamicPricePrecision(d);
        candleSeries.setData(d);
        if(!zoomApply(zoomRec,d)){
            chart.timeScale().fitContent();
        }
        if(!window._zoomSubscribed){
            window._zoomSubscribed=true;
            try{ chart.timeScale().subscribeVisibleLogicalRangeChange(zoomScheduleSave); }catch(e){}
        }
        sessionSave(limit);
        _prevLoadCtx={symbol:currentSymbol,timeframe:currentTimeframe,limit:limit};
        
        if(indicatorEnabled){
            setTimeout(function(){
                const rb=drawRibbon(d);
                updateStatus(rb);
                if(alphaSettings.showMTF)loadMTFPanel();
            },100);
        }else{
            removeAllRibbonSeries();
            ribbonResult=null;
            updateAllMarkers();
            updateStatus(null);
            updateDashboardPanel(null);
        }

        if(multiLayerEnabled){
            setTimeout(function(){
                drawMultiLayer(d);
                setTimeout(function(){
                    if(signalFilterEnabled)drawSignalFilter(d);
                    checkNewMultiLayerSignal();
                },50);
            },120);
        }else{
            multiLayerResult=null;
            removeMultiLayerPriceLines();
            updateAllMarkers();
        }

        if(zonesEnabled){
            setTimeout(function(){ drawZonesIndicator(d); },140);
        }else{
            zonesResult=null;
            removeZonesSeries();
            updateAllMarkers();
        }

        if(structureEnabled){
            setTimeout(function(){ drawMarketStructure(d); },180);
        }else{
            structureResult=null;
            removeMarketStructureSeries();
            updateAllMarkers();
        }

        if(signalFilterEnabled && !multiLayerEnabled){
            setTimeout(function(){ drawSignalFilter(d); },160);
        }else if(!signalFilterEnabled){
            removeSignalFilterLine();
        }

        if(fanEnabled){
            setTimeout(function(){ drawFanProjection(d); },200);
        }else{
            fanResult=null;
            removeFanProjectionSeries();
            updateAllMarkers();
        }

        if(aiPathEnabled){
            setTimeout(function(){ drawAiPricePath(d); },220);
        }else{
            aiPathResult=null;
            removeAiPricePathSeries();
            updateAllMarkers();
            hideAiTradeCard();
        }


        if(ihEnabled){
            setTimeout(function(){ drawImpulseHM(d); },230);
        }else if(ihPrimitive){
            ihRemove();
        }

        if(brEnabled){
            setTimeout(function(){ drawBrCh(d); },220);
        }else if(brPrimitive){
            brRemove();
        }

        if(mlstEnabled){
            setTimeout(function(){ drawMlSt(d); },210);
        }else if(mlstPrimitive){
            mlstRemove();
        }

        if(fvgEnabled){
            setTimeout(function(){ drawFvgOB(d); },200);
        }else if(fvgPrimitive){
            fvgRemove();
            updateAllMarkers();
        }

        if(pfEnabled){
            setTimeout(function(){ drawProF(d); },240);
        }else{
            pfResult=null;
            pfRemoveSeries();
            pfHideCard();
            updateAllMarkers();
        }

        if(sxEnabled){
            setTimeout(function(){ drawSwiftAlgo(d); },280);
        }else if(sxResult){
            sxResult=null;removeSwiftSeries();updateAllMarkers();
        }
        if(lzAllEnabled){
            setTimeout(function(){ lzAllRedraw(false); },300);
        }
        if(psEnabled){
            setTimeout(function(){ drawProScalper(d); },270);
        }else if(psResult){
            psResult=null;removeProScalperSeries();lzVotes[5]=null;updateAllMarkers();
        }
        if(mbEnabled){
            setTimeout(function(){ drawMyBot(d); },260);
        }else if(mbResult){
            mbResult=null;
            removeMyBotSeries();
            updateAllMarkers();
        }
    }catch(e){
        status.textContent='❌ خطا: '+e.message;
    }finally{
        loadChartBusy=false;
    }
}

symSel.addEventListener('change',function(){
    currentSymbol=this.value;
    loadChart();
});
document.getElementById('limitSelect').addEventListener('change',loadChart);
document.querySelectorAll('.tf-btn').forEach(btn=>{
    btn.addEventListener('click',function(){
        document.querySelectorAll('.tf-btn').forEach(b=>b.classList.remove('active'));
        this.classList.add('active');
        currentTimeframe=this.dataset.tf;
        loadChart();
    });
});

function boot(attempt){
    if(typeof LightweightCharts!=='undefined'){
        if(initChart()){
            // ابتدا لیست ارزها رو از Worker بگیر، بعد چارت رو لود کن
            loadSymbols().then(()=>{
                setupSymbolSearch();
                loadChart();
                setInterval(loadChart, 5000);
            });
        }
    }else if(attempt<60){
        document.getElementById('statusBar').textContent='⏳ در حال بارگذاری کتابخانه نمودار...';
        setTimeout(()=>boot(attempt+1),500);
    }else{
        document.getElementById('statusBar').innerHTML='❌ کتابخانه نمودار بارگذاری نشد - اتصال اینترنت را چک کن و <a href="#" onclick="location.reload();return false;" style="color:#00c853;">صفحه را رفرش کن</a>';
    }
}
// ذخیره‌ی زوم هنگام بستن/رفرش صفحه تا بعد از رفرش همان بازه‌ی قبلی باقی بماند
window.addEventListener('beforeunload',function(){
    try{
        const rec=zoomCapture(currentCandles);
        if(rec&&isFinite(rec.fromT)&&isFinite(rec.toT))localStorage.setItem(zoomKey(currentSymbol,currentTimeframe),JSON.stringify(rec));
    }catch(e){}
});
try{lzRestoreTuned();}catch(e){console.error(e);}
boot(0);

// ==================== سیستم تأیید متقابل (Cross-Confirmation) ====================
// وقتی فعال باشه، فقط سیگنال‌هایی نشون داده می‌شن که حداقل N اندیکاتور هم‌جهت باشن
// این کار تعداد سیگنال‌ها رو کم می‌کنه ولی دقت رو بالا می‌بره
let crossConfirmEnabled = false;
let crossConfirmMinIndicators = 2;  // حداقل تعداد اندیکاتور برای تأیید
let crossConfirmResult = null;

function calcCrossConfirm(d) {
    const n = d.length;
    const result = { markers: [], signals: [], stats: { total: 0, long: 0, short: 0 } };

    if (!d || d.length < 50) return result;

    // جمع‌آوری وضعیت هر اندیکاتور در هر کندل
    const indicatorStates = [];

    // P1: FVG
    try {
        const fvg = calcFvgOB(d, fvgReadSettings());
        const states = new Int8Array(n);
        let lastSignal = 0, lastIdx = -100;
        fvg.signals.forEach(s => {
            for (let i = lastIdx + 1; i <= s.idx; i++) states[i] = lastSignal;
            lastSignal = s.dir;
            lastIdx = s.idx;
        });
        for (let i = lastIdx + 1; i < n; i++) states[i] = lastSignal;
        indicatorStates.push({ name: 'P1', states: states, weight: 1 });
    } catch(e) {}

    // P2: Impulse Heatmap
    try {
        const ih = calcImpulseHM(d, ihReadSettings());
        const states = new Int8Array(n);
        let lastSignal = 0, lastIdx = -100;
        ih.signals.forEach(s => {
            for (let i = lastIdx + 1; i <= s.idx; i++) states[i] = lastSignal;
            lastSignal = s.dir;
            lastIdx = s.idx;
        });
        for (let i = lastIdx + 1; i < n; i++) states[i] = lastSignal;
        indicatorStates.push({ name: 'P2', states: states, weight: 1 });
    } catch(e) {}

    // P3: ML SuperTrend
    try {
        const mlst = calcMlSt(d, mlstReadSettings());
        const states = new Int8Array(n);
        let lastDir = 0;
        mlst.dir.forEach((dir, i) => {
            if (!isNaN(dir)) lastDir = dir < 0 ? 1 : -1;  // dir<0 صعودی
            states[i] = lastDir;
        });
        indicatorStates.push({ name: 'P3', states: states, weight: 1.5 });  // ML وزن بیشتر
    } catch(e) {}

    // P4: Lorentzian
    try {
        const s = Object.assign({}, pfSettings, { tf: currentTimeframe });
        const ldc = calcProF(pfEngineData(d, currentTimeframe, s), s, null);
        const states = new Int8Array(n);
        let lastDir = 0, lastIdx = -100;
        ldc.trades.forEach(t => {
            const dir = t.dir === 'long' ? 1 : -1;
            for (let i = lastIdx + 1; i <= t.entryIdx; i++) states[i] = lastDir;
            lastDir = dir;
            lastIdx = t.entryIdx;
        });
        for (let i = lastIdx + 1; i < n; i++) states[i] = lastDir;
        indicatorStates.push({ name: 'P4', states: states, weight: 1.5 });  // ML وزن بیشتر
    } catch(e) {}

    // P5: Pro Scalper
    try {
        const ps = calcProScalper(d, psReadSettings());
        const states = new Int8Array(n);
        let lastDir = 0;
        ps.sigs.forEach(s => {
            lastDir = s.dir;
            for (let i = 0; i < n; i++) {
                if (i >= s.idx) states[i] = lastDir;
            }
        });
        indicatorStates.push({ name: 'P5', states: states, weight: 1 });
    } catch(e) {}

    // P6: Breakout Channels
    try {
        const br = calcBrCh(d, brReadSettings());
        const states = new Int8Array(n);
        let lastDir = 0, lastIdx = -100;
        br.shapes.forEach(s => {
            for (let i = lastIdx + 1; i <= s.idx; i++) states[i] = lastDir;
            lastDir = s.dir;
            lastIdx = s.idx;
        });
        for (let i = lastIdx + 1; i < n; i++) states[i] = lastDir;
        indicatorStates.push({ name: 'P6', states: states, weight: 1 });
    } catch(e) {}

    // P7: Swift Algo X
    try {
        const sx = calcSwiftAlgoX(d, sxReadSettings());
        const states = new Int8Array(n);
        let lastDir = 0, lastIdx = -100;
        sx.sigs.forEach(s => {
            for (let i = lastIdx + 1; i <= s.idx; i++) states[i] = lastDir;
            lastDir = s.dir;
            lastIdx = s.idx;
        });
        for (let i = lastIdx + 1; i < n; i++) states[i] = lastDir;
        indicatorStates.push({ name: 'P7', states: states, weight: 1 });
    } catch(e) {}

    // محاسبه امتیاز هر کندل
    const longScore = new Float64Array(n);
    const shortScore = new Float64Array(n);

    indicatorStates.forEach(ind => {
        for (let i = 0; i < n; i++) {
            if (ind.states[i] > 0) longScore[i] += ind.weight;
            else if (ind.states[i] < 0) shortScore[i] += ind.weight;
        }
    });

    // تولید سیگنال وقتی امتیاز از آستانه عبور کنه
    let prevLong = false, prevShort = false;
    for (let i = 0; i < n; i++) {
        const isLong = longScore[i] >= crossConfirmMinIndicators && longScore[i] > shortScore[i];
        const isShort = shortScore[i] >= crossConfirmMinIndicators && shortScore[i] > longScore[i];

        if (isLong && !prevLong) {
            result.signals.push({ idx: i, dir: 1, score: longScore[i] });
            result.markers.push({
                time: d[i].time,
                position: 'belowBar',
                color: '#00e676',
                shape: 'arrowUp',
                text: '✓✓ LONG ' + longScore[i].toFixed(1)
            });
            result.stats.long++;
        } else if (isShort && !prevShort) {
            result.signals.push({ idx: i, dir: -1, score: shortScore[i] });
            result.markers.push({
                time: d[i].time,
                position: 'aboveBar',
                color: '#ff1744',
                shape: 'arrowDown',
                text: '✓✓ SHORT ' + shortScore[i].toFixed(1)
            });
            result.stats.short++;
        }
        prevLong = isLong;
        prevShort = isShort;
    }

    result.stats.total = result.signals.length;
    return result;
}

function toggleCrossConfirm() {
    crossConfirmEnabled = !crossConfirmEnabled;
    const btn = document.getElementById('btnCrossConfirm');

    if (crossConfirmEnabled) {
        btn.classList.add('active');
        btn.textContent = '🔗 حذف تأیید متقابل';
        if (currentCandles.length > 0) {
            setTimeout(function() {
                crossConfirmResult = calcCrossConfirm(currentCandles);
                updateAllMarkers();

                // نمایش آمار
                const info = document.getElementById('symbolInfo');
                if (info && crossConfirmResult) {
                    info.textContent = '🔗 تأیید متقابل: ' + crossConfirmResult.stats.total + ' سیگنال (' + 
                        crossConfirmResult.stats.long + ' لانگ, ' + crossConfirmResult.stats.short + ' شورت)';
                }
            }, 100);
        }
    } else {
        btn.classList.remove('active');
        btn.textContent = '🔗 اعمال تأیید متقابل';
        crossConfirmResult = null;
        updateAllMarkers();
    }
}

// اضافه کردن به updateAllMarkers
const originalUpdateAllMarkers = updateAllMarkers;
updateAllMarkers = function() {
    originalUpdateAllMarkers();
    if (crossConfirmEnabled && crossConfirmResult && candleSeries) {
        let markers = [];
        try {
            markers = candleSeries.markers() || [];
        } catch(e) {
            markers = [];
        }
        markers = markers.concat(crossConfirmResult.markers);
        markers.sort((a, b) => a.time - b.time);
        try { candleSeries.setMarkers(markers); } catch(e) {}
    }
};

</script>
</body>
</html>
"""

# ==================== اجرا روی اندروید (توسط main.py صدا زده می‌شود) ====================
def start_server():
    import threading
    t = threading.Thread(
        target=lambda: app.run(host=HOST, port=PORT, debug=False, threaded=True, use_reloader=False),
        daemon=True)
    t.start()
    return t
