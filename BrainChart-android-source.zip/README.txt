BrainChart - سورس اندروید (Chaquopy + WebView)

ساخت APK:
1) Android Studio را باز کن و پوشه‌ی BrainChart را انتخاب کن (Open).
2) اگر پرسید Gradle Wrapper بسازد، قبول کن. Sync را تا آخر صبر کن
   (اولین بار Python و پکیج‌های flask/requests دانلود می‌شوند و طول می‌کشد).
3) منوی Build > Build Bundle(s) / APK(s) > Build APK(s) را بزن.
4) فایل APK در مسیر app/build/outputs/apk/debug/ ساخته می‌شود.

نکات:
- فایل اصلی برنامه‌ی پایتون: app/src/main/python/bi2_app.py (همان نسخه‌ی v5 با بخش اجرای روی اندروید).
- ورود برنامه از app/src/main/python/main.py است؛ MainActivity سرور را start می‌کند و صفحه را در WebView باز می‌کند.
- نسخه‌های Chaquopy و AGP ممکن است با زمان تغییر کنند؛ اگر Sync خطای نسخه داد، شماره‌ی
  com.chaquo.python در build.gradle.kts (ریشه) و version = "3.11" را با نسخه‌ی جدید مستندات Chaquopy هماهنگ کن.
- این پروژه روی یک محیط بدون Android SDK ساخته شده و کامپایل نشده است؛ اولین Build ممکن است نیاز به یک اصلاح کوچک داشته باشد.
